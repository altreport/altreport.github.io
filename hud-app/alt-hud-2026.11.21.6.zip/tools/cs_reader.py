"""관전 화면(1920x1080) 하단표의 CS(노란 숫자)를 읽는다. 골드 모드/아이템 모드 모두 같은 자리.

gold_reader와 같은 숫자 대조 방식. 노란 글자라 초록 채널(G)로 글자를 걸러낸다
(어두운 배경과 빨간 사망 배경은 G가 낮음).

  python cs_reader.py build <정답 캡처.png> "<블루5,레드5 CS 쉼표 구분>" [추가 캡처 "정답"...]
  python cs_reader.py read <캡처.png> [...]
"""
import sys
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gold_reader as gr  # noqa: E402

TEMPLATE_FILE = gr.ROOT / "tools" / "cs_templates_1080.npz"
BLUE_X = (870, 921)
RED_X = (1012, 1062)
MAX_GAP = 6  # 숫자 사이 간격보다 멀리 떨어진 노란 조각(+골드 알림 동전 등)은 버림
ROW_Y = gr.ROW_Y
HALF_H = 12


def cells(img):
    out = []
    for team, (x1, x2) in (("blue", BLUE_X), ("red", RED_X)):
        for r, yc in enumerate(ROW_Y):
            out.append((team, r, img[yc - HALF_H: yc + HALF_H, x1:x2]))
    return out


def text_mask(cell):
    g = cell[:, :, 1].astype(np.float32)
    return np.clip((g - 70) / (200 - 70), 0, 1)


def main_cluster(glyphs):
    """가로 간격이 MAX_GAP 이하로 붙어 있는 글자 무리 중 가장 큰 것만 남긴다."""
    if not glyphs:
        return glyphs
    groups, cur = [], [glyphs[0]]
    for g in glyphs[1:]:
        if g[0] - cur[-1][1] > MAX_GAP:
            groups.append(cur); cur = [g]
        else:
            cur.append(g)
    groups.append(cur)
    return max(groups, key=len)


def read_cell(cell, templates):
    glyphs = main_cluster(gr.segment(text_mask(cell)))
    text, conf = "", 1.0
    for gl in glyphs:
        c, s = gr.classify(gl, templates)
        text += c
        conf = min(conf, s)
    ok = text.isdigit() and 0 < len(text) <= 4
    return {"raw": text, "ok": ok, "conf": round(conf, 3), "cs": int(text) if ok else None}


def load_templates():
    d = np.load(TEMPLATE_FILE, allow_pickle=True)
    return list(d["chars"]), d["vecs"], d["dims"]


def read_image(img, templates=None):
    templates = templates or load_templates()
    if not isinstance(img, np.ndarray):
        img = np.asarray(Image.open(img).convert("RGB"))
    res = {"blue": [], "red": []}
    for team, r, cell in cells(img):
        res[team].append(read_cell(cell, templates))
    return res


def build(pairs):
    chars, vecs, dims = [], [], []
    for img_path, truth_csv in pairs:
        truths = [t.strip() for t in truth_csv.split(",")]
        img = np.asarray(Image.open(img_path).convert("RGB"))
        for (team, r, cell), truth in zip(cells(img), truths):
            glyphs = main_cluster(gr.segment(text_mask(cell)))
            if len(glyphs) != len(truth):
                print(f"[경고] {Path(img_path).parent.name} {team}{r + 1}: 글자 {len(glyphs)}개 vs 정답 '{truth}' -> 건너뜀")
                continue
            for gl, ch in zip(glyphs, truth):
                v, w, h = gr.glyph_features(gl)
                chars.append(ch); vecs.append(v); dims.append((w, h))
    np.savez(TEMPLATE_FILE, chars=np.array(chars), vecs=np.array(vecs), dims=np.array(dims, dtype=np.float32))
    print(f"CS 견본 {len(chars)}개 저장 ({''.join(sorted(set(chars)))})")


if __name__ == "__main__":
    if sys.argv[1] == "build":
        args = sys.argv[2:]
        build(list(zip(args[0::2], args[1::2])))
    else:
        t = load_templates()
        for p in sys.argv[2:]:
            res = read_image(p, t)
            print(f"{Path(p).parent.name}/{Path(p).name}: 블루 " + " ".join(f"{c['raw'] or '?':>4}" for c in res["blue"])
                  + " | 레드 " + " ".join(f"{c['raw'] or '?':>4}" for c in res["red"]))
