"""관전 화면(1920x1080, 하단표 X 골드 모드)에서 선수별 골드를 읽는다.

방식: 범용 OCR 대신 고정 폰트 숫자 대조(템플릿 매칭).
  1) 골드 칸 10개를 잘라낸다
  2) 밝은 글자 픽셀만 남기고(빨간 사망 배경 제거) 글자 단위로 자른다
  3) 각 글자를 미리 저장한 0-9, (, ) 견본과 비교해 가장 닮은 글자로 읽는다
  4) "현재(누적)" 형식인지 검사한다

사용:
  python gold_reader.py build <정답 캡처.png> "<10칸 정답, 쉼표 구분>"   # 견본 만들기
  python gold_reader.py read <캡처.png> [...]                           # 읽기
"""
import json
import re
import sys
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
TEMPLATE_FILE = ROOT / "tools" / "gold_templates_1080.npz"

# 1920x1080 기준 골드 칸 (x1, x2), 행 중심 y
LEFT_X = (640, 790)
RIGHT_X = (1150, 1295)
ROW_Y = [873, 917, 961, 1005, 1049]
HALF_H = 12
GLYPH_SIZE = (10, 16)  # 비교용 정규화 크기 (w, h)
TEXT_MIN = 95          # min(R,G,B)가 이 값 이상이면 글자 픽셀 (회색/흰 글자)
FORMAT = re.compile(r"^(\d+)\((\d+)\)$")


def cells(img: np.ndarray):
    """10칸을 (팀, 행, 잘라낸 배열) 순서로. 블루 0-4, 레드 5-9."""
    out = []
    for team, (x1, x2) in (("blue", LEFT_X), ("red", RIGHT_X)):
        for r, yc in enumerate(ROW_Y):
            out.append((team, r, img[yc - HALF_H: yc + HALF_H, x1:x2]))
    return out


def text_mask(cell: np.ndarray) -> np.ndarray:
    m = cell.min(axis=2).astype(np.float32)
    return np.clip((m - TEXT_MIN) / (200 - TEXT_MIN), 0, 1)


def segment(mask: np.ndarray):
    """세로로 비어 있는 열을 기준으로 글자를 나눈다. (x1, x2, glyph) 목록."""
    on = mask.max(axis=0) > 0.35
    segs, x = [], 0
    w = len(on)
    while x < w:
        if on[x]:
            s = x
            while x < w and on[x]:
                x += 1
            segs.append((s, x))
        else:
            x += 1
    glyphs = []
    for s, e in segs:
        g = mask[:, s:e]
        rows = np.where(g.max(axis=1) > 0.35)[0]
        if len(rows) == 0 or (e - s) * len(rows) < 6:  # 점 같은 잡티 무시
            continue
        g = g[rows.min(): rows.max() + 1]
        glyphs.append((s, e, rows.min(), rows.max(), g))
    return glyphs


def normalize(g: np.ndarray) -> np.ndarray:
    im = Image.fromarray((g * 255).astype(np.uint8)).resize(GLYPH_SIZE, Image.BILINEAR)
    v = np.asarray(im, dtype=np.float32).ravel()
    v -= v.mean()
    n = np.linalg.norm(v)
    return v / n if n else v


def glyph_features(glyph):
    s, e, top, bottom, g = glyph
    return normalize(g), (e - s), (bottom - top + 1)


def load_templates():
    d = np.load(TEMPLATE_FILE, allow_pickle=True)
    return list(d["chars"]), d["vecs"], d["dims"]


def classify(glyph, templates):
    chars, vecs, dims = templates
    v, w, h = glyph_features(glyph)
    sims = vecs @ v
    # 폭/높이가 많이 다른 견본은 감점 (1과 ( 구분 등)
    penalty = np.abs(dims[:, 0] - w) * 0.04 + np.abs(dims[:, 1] - h) * 0.04
    score = sims - penalty
    i = int(np.argmax(score))
    return chars[i], float(score[i])


def read_cell(cell, templates):
    glyphs = segment(text_mask(cell))
    text, conf = "", 1.0
    for gl in glyphs:
        c, s = classify(gl, templates)
        text += c
        conf = min(conf, s)
    m = FORMAT.match(text)
    if not m:
        return {"raw": text, "ok": False, "conf": round(conf, 3)}
    cur, tot = int(m.group(1)), int(m.group(2))
    ok = tot >= cur
    return {"raw": text, "ok": ok, "conf": round(conf, 3), "current": cur, "total": tot}


def read_image(path_or_array, templates=None):
    templates = templates or load_templates()
    img = path_or_array if isinstance(path_or_array, np.ndarray) else np.asarray(Image.open(path_or_array).convert("RGB"))
    assert img.shape[:2] == (1080, 1920), f"1920x1080만 지원: {img.shape}"
    res = {"blue": [], "red": []}
    for team, r, cell in cells(img):
        res[team].append(read_cell(cell, templates))
    return res


def lane_diffs(res):
    """맞라인 누적 골드 차이 (블루 - 레드). 읽기 실패한 칸은 None."""
    lanes = ["TOP", "JUNGLE", "MID", "ADC", "SUPPORT"]
    out = []
    for i, lane in enumerate(lanes):
        b, r = res["blue"][i], res["red"][i]
        diff = b["total"] - r["total"] if b["ok"] and r["ok"] else None
        out.append((lane, b.get("total"), r.get("total"), diff))
    return out


def build(img_path, truth_csv):
    truths = [t.strip() for t in truth_csv.split(",")]
    assert len(truths) == 10, "정답은 블루 5칸 + 레드 5칸 = 10개"
    img = np.asarray(Image.open(img_path).convert("RGB"))
    chars, vecs, dims = [], [], []
    for (team, r, cell), truth in zip(cells(img), truths):
        glyphs = segment(text_mask(cell))
        if len(glyphs) != len(truth):
            print(f"[경고] {team}{r + 1}: 글자 {len(glyphs)}개 vs 정답 '{truth}' {len(truth)}자 -> 건너뜀")
            continue
        for gl, ch in zip(glyphs, truth):
            v, w, h = glyph_features(gl)
            chars.append(ch); vecs.append(v); dims.append((w, h))
    np.savez(TEMPLATE_FILE, chars=np.array(chars), vecs=np.array(vecs), dims=np.array(dims, dtype=np.float32))
    print(f"견본 {len(chars)}개 저장 ({''.join(sorted(set(chars)))}) -> {TEMPLATE_FILE.name}")


if __name__ == "__main__":
    if sys.argv[1] == "build":
        build(sys.argv[2], sys.argv[3])
    elif sys.argv[1] == "read":
        t = load_templates()
        for p in sys.argv[2:]:
            res = read_image(p, t)
            print(f"== {Path(p).parent.name}/{Path(p).name}")
            for team in ("blue", "red"):
                print(f"  {team:4}: " + "  ".join(f"{c['raw']:>12}{'' if c['ok'] else '(X)'}" for c in res[team]))
            print("  맞라인 누적골드 차이(블루-레드): " + ", ".join(f"{l} {d:+d}" if d is not None else f"{l} ?" for l, _, _, d in lane_diffs(res)))


# ── 판독 실패 장면 저장 제한 (견본 보충용) ──
# 실패할 때마다 매초 저장하면 중계 한 번에 수천 장이 쌓임 → 칸마다 1분에 1장, 폴더당 최대 300장
_last_save = {}


def may_save(key, folder, every=60, cap=300):
    import time as _t
    now = _t.time()
    if now - _last_save.get(key, 0) < every:
        return False
    try:
        if folder.exists() and sum(1 for _ in folder.iterdir()) >= cap:
            return False
    except Exception:
        return False
    _last_save[key] = now
    return True
