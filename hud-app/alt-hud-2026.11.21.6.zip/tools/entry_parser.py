"""카톡 공지방의 당일 엔트리 글을 세트별 명단으로 나눈다.

예시 (공지 형식):
    ALT S10 R10 10월 10일 8시30분 ZRN vs GNS
    Home Team : 레드

    1set 지하 70
    ZRN
    Sungsin 20
    Dalkom 19
    Dosifafa 1
    ChoA 20
    Sunny 9
    vs
    GNS
    ...
    2set ...

규칙
- 선수 줄은 [닉네임 (공백 포함 가능)] [숫자=리그 점수(없어도 됨)], 순서는 탑→정글→미드→원딜→서폿.
- "Home Team : 레드/블루" → 제목줄의 첫 팀(홈)이 그 진영. 세트마다 "Home Team" 줄이 있으면 그 세트만 덮어씀.
- 인식이 애매하면 경고 목록에 남김 (컨트롤 페이지에서 좌우 바꾸기로 보정).
"""
import re

SET_RE = re.compile(r"^\s*(\d+)\s*(?:set|세트)\b\s*(.*)$", re.I)
HEAD_RE = re.compile(r"\bS(\d+)\s*(R\s*\d+|Play\s*-?\s*off(?:\s*-?\s*Final)?|PO(?:\s*-?\s*Final)?|Semi\s*-?\s*Final|Final|플레이오프|준결승|결승)", re.I)
DATE_RE = re.compile(r"(\d{1,2})\s*월\s*(\d{1,2})\s*일")
VS_LINE_RE = re.compile(r"^\s*vs\s*$", re.I)
TEAMS_RE = re.compile(r"(\S+)\s+vs\s+(\S+)\s*$", re.I)
HOME_RE = re.compile(r"home\s*team\s*[:：]\s*(레드|블루|red|blue)", re.I)
PLAYER_RE = re.compile(r"^(.+?)\s+(\d{1,3})\s*$")            # "Sungsin 20"
PTS_FIRST_RE = re.compile(r"^(\d{1,3})\s+(.+)$")              # "12 Praty"
# 긴 표기를 먼저 (JG보다 JGL, AD보다 ADC — 아니면 "JGL: Tiki"가 "L: Tiki"로 읽힘)
POS_RE = re.compile(r"^(TOP|탑|JUNGLE|JGL|JG|정글|MIDDLE|MID|미드|ADC|AD|BOTTOM|BOT|원딜|SUPPORT|SUPP|SUP|SPT|서폿)(?:\s*[:：.\-]\s*|\s+)(.*)$", re.I)   # 뒤에 ":" 나 띄어쓰기 필수 ("Midir 31" 같은 닉 보호)
POS_INDEX = {"top": 0, "탑": 0, "jg": 1, "jgl": 1, "jungle": 1, "정글": 1, "mid": 2, "middle": 2, "미드": 2,
             "ad": 3, "adc": 3, "bot": 3, "bottom": 3, "원딜": 3, "sup": 4, "supp": 4, "spt": 4, "support": 4, "서폿": 4}


NOTE_RE = re.compile(r"[\[\(（【]([^\]\)）】]*)[\]\)）】]")   # "[온라인]" 같은 괄호 메모


def parse_player(line):
    """선수 줄 → (닉네임, 점수, 포지션 번호 또는 None, 메모). 'Sungsin 20' / 'TOP: 12 Praty' / '12 Praty' /
    'Vin 3 [온라인]' / 'Haze 41[온라인]' 모두 지원 — 괄호 메모는 따로 떼어 둔다."""
    notes = [n.strip() for n in NOTE_RE.findall(line) if n.strip()]
    line = NOTE_RE.sub(" ", line).strip()
    name, pts, pos = _parse_core(line)
    return name, pts, pos, " ".join(notes) or None


def _parse_core(line):
    pos = None
    m = POS_RE.match(line)
    if m and m.group(2):
        pos, line = POS_INDEX[m.group(1).lower()], m.group(2).strip()
    m = PTS_FIRST_RE.match(line)
    if m:
        return m.group(2).strip(), int(m.group(1)), pos
    m = PLAYER_RE.match(line)
    if m:
        return m.group(1).strip(), int(m.group(2)), pos
    return line, None, pos


def stage_of(word):
    """제목줄 라운드 표기 → (라운드 번호, 화면 표기). 리그리포트와 같게 PO=13, 결승=14."""
    w = re.sub(r"\s+", "", word).lower()
    m = re.match(r"r(\d+)$", w)
    if m:
        return int(m.group(1)), f"R{int(m.group(1))}"
    if "semi" in w or "준결승" in w:
        return 13, "PO 준결승"
    if "final" in w or "결승" in w:
        return 14, "PO 결승" if ("play" in w or w.startswith("po") or "플레이오프" in w) else "결승"
    return 13, "PO"


def _dist(a, b):
    """편집 거리 (짧은 팀 이름 오타 판별용)"""
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def side_of(word):
    return "red" if word.lower() in ("레드", "red") else "blue"


def parse(text):
    lines = [l.rstrip() for l in text.replace("\r", "").split("\n")]
    out = {"season": None, "round": None, "label": None, "date": None, "teams": [], "home_side": None, "sets": [], "warnings": []}
    cur = None
    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        m = HEAD_RE.search(line)
        if m and not out["sets"] and out["round"] is None:
            out["season"] = int(m.group(1))
            out["round"], out["label"] = stage_of(m.group(2))
            d = DATE_RE.search(line)
            if d:
                out["date"] = f"{int(d.group(1))}월 {int(d.group(2))}일"
            t = TEAMS_RE.search(line)
            if t:
                out["teams"] = [t.group(1), t.group(2)]
            continue
        m = HOME_RE.search(line)
        if m:
            if cur:
                cur["home_side"] = side_of(m.group(1))
            else:
                out["home_side"] = side_of(m.group(1))
            continue
        m = SET_RE.match(line)
        if m:
            cur = {"no": int(m.group(1)), "stage": m.group(2).strip(), "home_side": None, "teams": []}
            out["sets"].append(cur)
            continue
        if cur is None:
            continue
        if VS_LINE_RE.match(line):
            continue
        # 팀 이름 줄: 제목줄의 팀명과 같거나, 숫자·포지션 없는 한 단어 줄
        if line in out["teams"] or (not PLAYER_RE.match(line) and not POS_RE.match(line) and " " not in line
                                    and len(cur["teams"]) < 2 and (not cur["teams"] or len(cur["teams"][-1]["players"]) >= 5)):
            cur["teams"].append({"name": line, "players": []})
            continue
        if not cur["teams"]:
            cur["teams"].append({"name": "?", "players": []})
        name, pts, pos, note = parse_player(line)
        cur["teams"][-1]["players"].append({"name": name, "pts": pts, "pos": pos, "note": note})

    # 세트 팀 이름 오타 (예: ZRN 을 ZEN 으로) → 제목줄 팀 중 한 글자 차이면 그 팀으로
    if len(out["teams"]) == 2:
        for s in out["sets"]:
            for t in s["teams"]:
                if t["name"] in out["teams"]:
                    continue
                near = [h for h in out["teams"] if _dist(t["name"].lower(), h.lower()) <= 1]
                if len(near) == 1:
                    out["warnings"].append(f"{s['no']}세트 팀 이름 '{t['name']}' → {near[0]}(으)로 봤어요")
                    t["name"] = near[0]

    # 포지션이 적힌 팀은 포지션 기준으로 탑→서폿 순서 정렬 (안 적힌 팀은 적힌 순서 그대로)
    for s in out["sets"]:
        for t in s["teams"]:
            ps = t["players"]
            if ps and all(p["pos"] is not None for p in ps):
                ps.sort(key=lambda p: p["pos"])
            elif any(p["pos"] is not None for p in ps):
                out["warnings"].append(f"{s['no']}세트 {t['name']}: 포지션이 일부만 적혀 있어 적힌 순서대로 배치")
            for p in ps:
                p.pop("pos", None)

    for s in out["sets"]:
        for t in s["teams"]:
            if len(t["players"]) != 5:
                out["warnings"].append(f"{s['no']}세트 {t['name']}: 선수 {len(t['players'])}명 (5명이 아님)")
        if len(s["teams"]) != 2:
            out["warnings"].append(f"{s['no']}세트: 팀 {len(s['teams'])}개 (2개가 아님)")
    if not out["sets"]:
        out["warnings"].append("'1set' 같은 세트 줄을 찾지 못했어요")
    return out


def lineup(parsed, set_index, swap=False):
    """선택한 세트를 {blue: 팀, red: 팀}으로. 홈팀(제목줄 첫 팀)이 Home Team 진영."""
    s = parsed["sets"][set_index]
    teams = s["teams"]
    if len(teams) != 2:
        return None
    home_name = parsed["teams"][0] if parsed["teams"] else teams[0]["name"]
    home_side = s["home_side"] or parsed["home_side"] or "blue"
    home = next((t for t in teams if t["name"] == home_name), teams[0])
    away = teams[1] if home is teams[0] else teams[0]
    blue, red = (home, away) if home_side == "blue" else (away, home)
    if swap:
        blue, red = red, blue
    return {"set": s["no"], "stage": s["stage"], "blue": blue, "red": red}


if __name__ == "__main__":
    import json
    import sys
    p = parse(open(sys.argv[1], encoding="utf-8").read())
    print(json.dumps(p, ensure_ascii=False, indent=1))
    for i in range(len(p["sets"])):
        print(json.dumps(lineup(p, i), ensure_ascii=False))
