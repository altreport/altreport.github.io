"""실시간 테스트: 관전 창을 1초마다 캡처해서 맞라인 골드 차이를 출력한다.

python live_gold.py [초=30] [간격=1.0]
게임 창이 다른 창에 가려져 있어도 동작한다 (PrintWindow).
"""
import ctypes
import ctypes.wintypes as wt
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gold_reader as gr  # noqa: E402

user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32
user32.SetProcessDPIAware()


GAME_TITLE = "League of Legends (TM) Client"


def find_game_window():
    """이름이 같은 창이 여럿일 수 있음(보이지 않는 창 등) → 보이는 창 중 화면이 가장 큰 것.
    최소화돼 있으면 그렇게 알려 줌 (최소화된 창은 크기가 0이라 못 읽음)."""
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, wt.HWND, wt.LPARAM)
    def each(h, _):
        n = user32.GetWindowTextLengthW(h)
        if n == len(GAME_TITLE):
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(h, buf, n + 1)
            if buf.value == GAME_TITLE and user32.IsWindowVisible(h):
                rc = wt.RECT()
                user32.GetClientRect(h, ctypes.byref(rc))
                found.append((rc.right * rc.bottom, bool(user32.IsIconic(h)), h))
        return True

    user32.EnumWindows(each, 0)
    if not found:
        raise SystemExit(f"관전 창({GAME_TITLE})을 찾지 못했어요")
    area, iconic, h = max(found)
    if area == 0:
        raise SystemExit("롤 관전 창이 최소화돼 있어요 — 롤 창을 한 번 눌러 열어 두세요 (전체 창 모드면 알트탭해도 최소화되지 않아요)"
                         if iconic else "롤 관전 창 크기가 0이에요 — 관전 화면이 다 뜰 때까지 잠시 기다려 주세요")
    return h


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [("biSize", wt.DWORD), ("biWidth", wt.LONG), ("biHeight", wt.LONG), ("biPlanes", wt.WORD),
                ("biBitCount", wt.WORD), ("biCompression", wt.DWORD), ("biSizeImage", wt.DWORD),
                ("biXPelsPerMeter", wt.LONG), ("biYPelsPerMeter", wt.LONG), ("biClrUsed", wt.DWORD),
                ("biClrImportant", wt.DWORD)]


def grab(hwnd):
    rc = wt.RECT()
    user32.GetClientRect(hwnd, ctypes.byref(rc))
    w, h = rc.right, rc.bottom
    hdc = user32.GetDC(hwnd)
    mdc = gdi32.CreateCompatibleDC(hdc)
    bmp = gdi32.CreateCompatibleBitmap(hdc, w, h)
    gdi32.SelectObject(mdc, bmp)
    user32.PrintWindow(hwnd, mdc, 2)  # PW_RENDERFULLCONTENT
    bi = BITMAPINFOHEADER(ctypes.sizeof(BITMAPINFOHEADER), w, -h, 1, 32, 0, 0, 0, 0, 0, 0)
    buf = ctypes.create_string_buffer(w * h * 4)
    gdi32.GetDIBits(mdc, bmp, 0, h, buf, ctypes.byref(bi), 0)
    gdi32.DeleteObject(bmp); gdi32.DeleteDC(mdc); user32.ReleaseDC(hwnd, hdc)
    a = np.frombuffer(buf, dtype=np.uint8).reshape(h, w, 4)
    return a[:, :, 2::-1].copy()  # BGRA -> RGB


def main(seconds=30, interval=1.0):
    hwnd = find_game_window()
    templates = gr.load_templates()
    log = []
    t_end = time.time() + seconds
    print("시각      | TOP     JUNGLE  MID     ADC     SUP     | 처리시간")
    while time.time() < t_end:
        t0 = time.perf_counter()
        img = grab(hwnd)
        t_cap = time.perf_counter()
        res = gr.read_image(img, templates)
        t_read = time.perf_counter()
        diffs = gr.lane_diffs(res)
        cells_ok = sum(c["ok"] for t in ("blue", "red") for c in res[t])
        row = "  ".join(f"{d:+6d}" if d is not None else "     ?" for _, _, _, d in diffs)
        print(f"{time.strftime('%H:%M:%S')}  | {row} | 캡처 {1000*(t_cap-t0):.0f}ms + 읽기 {1000*(t_read-t_cap):.0f}ms  ({cells_ok}/10칸)")
        log.append({"t": time.time(), "res": res, "capture_ms": 1000 * (t_cap - t0), "read_ms": 1000 * (t_read - t_cap)})
        time.sleep(max(0, interval - (time.perf_counter() - t0)))
    out = gr.ROOT / "captures" / f"live-gold-{time.strftime('%H%M%S')}.json"
    out.write_text(json.dumps(log, ensure_ascii=False), encoding="utf-8")
    print(f"기록 저장: {out}")


if __name__ == "__main__":
    main(float(sys.argv[1]) if len(sys.argv) > 1 else 30, float(sys.argv[2]) if len(sys.argv) > 2 else 1.0)
