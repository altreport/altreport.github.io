"""관전 하단표 KDA 위에 뜨는 현상금("🪙250골드")을 읽는다. 골드 모드/아이템 모드 공통.

글자가 가늘어 글자 단위로 자르면 깨지므로, 규칙으로 숫자 칸을 자른다:
  [동전 아이콘][숫자 칸 8px × n][골][드]  — 숫자 칸은 '골' 바로 앞에서 끝난다.
각 8px 칸을 견본과 비교해 읽는다. 처음 보는 숫자(견본 없음)나 자신 없는 값은 None으로 두고,
그 장면을 captures/bounty-unknown/ 에 저장해 나중에 견본으로 추가한다.

  python bounty_reader.py build <캡처> "<팀:줄:값,...>" [<캡처> "<...>" ...]
  python bounty_reader.py read <캡처> [...]
"""
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gold_reader as gr  # noqa: E402

TEMPLATE_FILE = gr.ROOT / "tools" / "bounty_templates_1080.npz"
UNKNOWN_DIR = gr.ROOT / "captures" / "bounty-unknown"
BAND_X = {"blue": (790, 890), "red": (1045, 1145)}
TOP, BOTTOM = 21, 6        # 줄 중심 y 기준 위로 21px ~ 6px
CELL = 8                   # 숫자 한 칸 폭
COIN_W = 10                # 동전 아이콘 폭(대략)
MIN_SCORE = 0.80           # 견본 닮음 정도 최소값
MAX_BOUNTY = 700           # 현상금 최대 +700골드 (기획자 확인). 50 단위 -> 가능한 숫자는 첫 자리 1~7, 나머지 0/5


def band(img, team, r):
    x1, x2 = BAND_X[team]
    y = gr.ROW_Y[r]
    return img[y - TOP: y - BOTTOM, x1:x2], x1


def mask(c):
    c = c.astype(np.float32)
    R, G, B = c[..., 0], c[..., 1], c[..., 2]
    # 황토색 글자: G가 어느 정도 밝고 R이 B보다 확실히 큼 (흰 KDA, 어두운/빨간 배경 제외)
    return np.minimum(np.clip((G - 90) / 80, 0, 1), np.clip((R - B - 40) / 50, 0, 1))


def digit_cells(m):
    """마스크에서 숫자 칸들의 x 범위 목록. 현상금이 없으면 []."""
    if m.sum() < 15:
        return []
    segs = gr.segment(m)
    if len(segs) < 3:
        return []
    coin = segs[0][0]
    gol = next((s for s, e, *_ in segs if e - s >= 11 and s > coin + 12), None)
    if gol is None:
        return []
    n = int(round((gol - coin - COIN_W) / CELL))
    if not 2 <= n <= 3:  # 50 ~ 700
        return []
    return [(gol - CELL * (n - i), gol - CELL * (n - i) + CELL) for i in range(n)]


def cell_vec(m, x1, x2):
    v = m[:, x1:x2].astype(np.float32).ravel()
    v = v - v.mean()
    nrm = np.linalg.norm(v)
    return v / nrm if nrm else v


SAMPLE_DIR = Path(__file__).resolve().parent / "bounty_samples"   # 방송 중 못 읽은 현상금 줄에 정답을 붙인 견본 (팀_값_시각.png)


def sample_cells():
    """견본 그림(현상금 줄만 잘린 것)에서 (글자, 칸 벡터) 목록."""
    out = []
    for f in sorted(SAMPLE_DIR.glob("*.png")):
        val = f.stem.split("_")[1]
        m = mask(np.asarray(Image.open(f).convert("RGB")))
        cells = digit_cells(m)
        if len(cells) == len(val):
            out += [(ch, cell_vec(m, x1, x2)) for (x1, x2), ch in zip(cells, val)]
    return out


def load_templates():
    d = np.load(TEMPLATE_FILE, allow_pickle=True)
    chars, vecs = list(d["chars"]), d["vecs"]
    extra = [(c, v) for c, v in sample_cells() if v.shape[0] == vecs.shape[1]]
    if extra:   # 7 · 6 등 원래 견본에 없던 숫자 (에일형 PC "700골드")
        chars += [c for c, _ in extra]
        vecs = np.vstack([vecs, np.array([v for _, v in extra])])
    return chars, vecs


def read_band(c, templates):
    m = mask(c)
    cells = digit_cells(m)
    if not cells:
        return None  # 현상금 없음
    chars, vecs = templates
    text, worst = "", 1.0
    for x1, x2 in cells:
        v = cell_vec(m, x1, x2)
        if v.shape[0] != vecs.shape[1]:
            return {"bounty": None, "raw": "", "score": 0.0}
        s = vecs @ v
        i = int(np.argmax(s))
        text += chars[i]
        worst = min(worst, float(s[i]))
    val = int(text)
    ok = worst >= MIN_SCORE and val % 50 == 0 and 50 <= val <= MAX_BOUNTY
    return {"bounty": val if ok else None, "raw": text, "score": round(worst, 3)}


def read_image(img, templates=None, save_unknown=False):
    templates = templates or load_templates()
    if not isinstance(img, np.ndarray):
        img = np.asarray(Image.open(img).convert("RGB"))
    res = {"blue": [], "red": []}
    for team in ("blue", "red"):
        for r in range(5):
            c, _ = band(img, team, r)
            b = read_band(c, templates)
            if save_unknown and b and b["bounty"] is None and gr.may_save(("bty", team, r), UNKNOWN_DIR):
                UNKNOWN_DIR.mkdir(parents=True, exist_ok=True)
                Image.fromarray(c).save(UNKNOWN_DIR / f"{int(time.time())}_{team}{r + 1}_{b['raw']}.png")
            res[team].append(b)
    return res


def build(pairs):
    chars, vecs = [], []
    for path, spec in pairs:
        img = np.asarray(Image.open(path).convert("RGB"))
        for item in spec.split(","):
            team, row, val = item.strip().split(":")
            c, _ = band(img, team, int(row) - 1)
            m = mask(c)
            cells = digit_cells(m)
            if len(cells) != len(val):
                print(f"[경고] {Path(path).parent.name} {team}{row}: 칸 {len(cells)}개 vs '{val}' -> 건너뜀")
                continue
            for (x1, x2), ch in zip(cells, val):
                chars.append(ch); vecs.append(cell_vec(m, x1, x2))
    np.savez(TEMPLATE_FILE, chars=np.array(chars), vecs=np.array(vecs))
    print(f"현상금 숫자 견본 {len(chars)}개 ({''.join(sorted(set(chars)))})")


if __name__ == "__main__":
    if sys.argv[1] == "build":
        a = sys.argv[2:]
        build(list(zip(a[0::2], a[1::2])))
    else:
        t = load_templates()
        for p in sys.argv[2:]:
            res = read_image(p, t)
            fmt = lambda b: "-" if b is None else (str(b["bounty"]) if b["bounty"] else f"?({b['raw']},{b['score']})")
            print(f"{Path(p).parent.name}/{Path(p).name}: 블루 {[fmt(b) for b in res['blue']]} | 레드 {[fmt(b) for b in res['red']]}")
