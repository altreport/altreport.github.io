"""자체 점검: 실제 경기 없이 가짜 경기를 만들어 서버 로직을 끝까지 돌려 봄 (디버깅용).

  python tools/selftest.py

확인하는 것: 골드 흐름 · 오브젝트 감지(2번 연속 확인) · 바론 버프(보유자 · 사망 · 종료 → 파워 플레이)
· 한타(사망 · 킬) · 경기 기록 · 최근 3분 · 되감기 · 서버 재시작 후 복원 · 라인업 해석 · 챔피언 기록 · 점검표.
기록 파일은 임시 폴더에 쓰고 지움.
"""
import json
import shutil
import sys
import tempfile
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import game_logic as gl  # noqa: E402

TMP = Path(tempfile.mkdtemp())
gl.LOG_DIR = TMP
FAIL = []


def check(name, cond, info=""):
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  ({info})" if info and not cond else ""))
    if not cond:
        FAIL.append(name)


NAMES = [f"B{i}" for i in range(5)] + [f"R{i}" for i in range(5)]
PLAYERS = [{"name": n, "champion": f"C{i}", "team": "ORDER" if i < 5 else "CHAOS", "position": ""} for i, n in enumerate(NAMES)]


def view(gold, dead=None):
    return [{"name": n, "gold_total": g, "gold_current": 300, "cs": 10, "k": 0, "d": 0, "a": 0, "level": 1, "bounty": None,
             "dead": bool(dead and dead[i])} for i, (n, g) in enumerate(zip(NAMES, gold))]


def top(bd=0, rd=0, bo=0, ro=0, kind="baron"):
    return {"blue": {"dragons": bd, "dragon_types": ["infernal"] * bd, "grubs": 0, "obj2": bo, "obj2_kind": kind, "towers": 0},
            "red": {"dragons": rd, "dragon_types": ["ocean"] * rd, "grubs": 0, "obj2": ro, "obj2_kind": kind, "towers": 0}}


def run():
    print("■ 경기 로직")
    g = gl.Game("TEST", PLAYERS)
    gold = [500] * 10
    t = 0.0
    # 0~20분 진행: 블루가 조금씩 앞섬
    for step in range(0, 1200, 1):
        t = float(step)
        gold = [500 + step * (7 if i < 5 else 6) for i in range(10)]
        g.update(t, view(gold[:5]), view(gold[5:]) if False else None, [], top()) if False else None
        bl, rd = view(gold)[:5], view(gold)[5:]
        g.update(t, bl, rd, [], top())
    check("골드 흐름이 0:00부터 쌓임", g.history and g.history[0][0] == 0.0, g.history[:2])
    check("골드 흐름 5초 간격", len(g.history) >= 230, len(g.history))

    # 드래곤: 상단바 숫자가 2번 연속 같아야 인정
    g.update(1201, bl, rd, [], top(bd=1))
    check("드래곤 1번 읽힘 → 아직 알림 없음", not any(a["kind"] == "dragon" for a in g.alerts))
    g.update(1202, bl, rd, [], top(bd=1))
    check("드래곤 2번 연속 → 알림", any(a["kind"] == "dragon" for a in g.alerts))

    # 바론: 레드 R0 죽어 있음 → 보유자 4명
    dead = [False] * 5 + [True, False, False, False, False]
    bl, rd = view(gold, dead)[:5], view(gold, dead)[5:]
    g.update(1203, bl, rd, [], top(bd=1, ro=1))
    g.update(1204, bl, rd, [], top(bd=1, ro=1))
    b = g.buffs["red"]
    check("바론 감지 → 레드 버프", b and b["type"] == "baron")
    check("버프 보유자 = 그때 살아 있던 4명", b and b["holders"] == [6, 7, 8, 9], b and b["holders"])
    check("파워 플레이 +850에서 시작", g.power_gain("red") == 850, g.power_gain("red"))
    # R1 사망 → 보유자에서 빠짐
    dead2 = [False] * 5 + [True, True, False, False, False]
    bl, rd = view(gold, dead2)[:5], view(gold, dead2)[5:]
    g.update(1210, bl, rd, [], top(bd=1, ro=1))
    check("버프 중 죽으면 테두리 빠짐", g.buffs["red"]["holders"] == [7, 8, 9], g.buffs["red"]["holders"])
    # 버프 종료 → 파워 플레이 결과 알림
    for s in range(1211, 1390):
        g.update(float(s), bl, rd, [], top(bd=1, ro=1))
    check("버프 끝나면 파워 플레이 결과 알림", any(a["kind"] == "powerplay" for a in g.alerts) or any(e["kind"] == "powerplay" for e in g.timeline))
    check("버프 끝나면 버프 없음", g.buffs["red"] is None)

    # 한타: 킬 3개 이상 + 8초 조용 → 버튼용 대기
    evs = [{"EventID": 900 + i, "EventName": "ChampionKill", "EventTime": 1390 + i * 2, "KillerName": k, "VictimName": v}
           for i, (k, v) in enumerate([("B0", "R0"), ("B1", "R1"), ("R2", "B2")])]
    g.update(1395, bl, rd, evs, top(bd=1, ro=1))
    for s in range(1396, 1410):
        g.update(float(s), bl, rd, [], top(bd=1, ro=1))
    f = g.recent.get("fight")
    check("한타 결과 대기 (자동으로 안 뜸)", f is not None and not any(a["kind"] == "fight" for a in g.active_alerts()))
    check("한타 킬 2:1", f and f["kills"] == [2, 1], f and f.get("kills"))
    check("한타 사망자 기록", f and f["deaths"][5] == 1 and f["deaths"][6] == 1 and f["deaths"][2] == 1, f and f.get("deaths"))
    check("한타 킬 수 기록", f and f["fkills"][0] == 1 and f["fkills"][7] == 1, f and f.get("fkills"))
    check("버튼 → 띄우기", g.show("fight") and any(a["kind"] == "fight" for a in g.active_alerts()))
    check("버튼 다시 → 내리기", g.hide("fight") and not any(a["kind"] == "fight" for a in g.active_alerts()))
    check("경기 기록에 드래곤·바론·한타", {"dragon", "baron", "fight"} <= {e["kind"] for e in g.timeline}, [e["kind"] for e in g.timeline])
    rg = g.recent_gains(1199)
    check("최근 3분 번 골드 계산", rg and rg["window"] >= 170 and rg["blue"] > 0, rg)

    # 서버 재시작: 같은 경기 기록 파일에서 복원
    g.close()
    g2 = gl.Game("TEST", PLAYERS)
    check("재시작 후 골드 흐름 복원", len(g2.history) > 100, len(g2.history))
    check("재시작 후 경기 기록 복원", {"dragon", "baron", "fight"} <= {e["kind"] for e in g2.timeline}, [e["kind"] for e in g2.timeline])
    check("재시작 후 대기 중 한타 결과 복원", g2.recent.get("fight") and g2.recent["fight"].get("kills") == [2, 1])
    g2.update(1250.0, view([500] * 10)[:5], view([500] * 10)[5:], [], top(bd=1, ro=1))
    check("재시작 후 진행 중 바론 버프 복원", g2.buffs["red"] and g2.buffs["red"]["type"] == "baron" and g2.buffs["red"]["holders"] == [7, 8, 9],
          g2.buffs["red"])
    # 되감기: 10분으로
    g2.update(600.0, bl, rd, [], top())
    check("되감기 → 이후 그래프 잘림", g2.history[-1][0] <= 600, g2.history[-1])
    check("되감기 → 버프 초기화", g2.buffs["red"] is None and g2.buffs["blue"] is None)
    check("되감기 → 이후 경기 기록 잘림", all(e["t"] <= 600 for e in g2.timeline), [e["t"] for e in g2.timeline])
    check("되감기 → 이후 킬 기록 잘림", all(x[0] <= 600 for x in getattr(g2, "kill_log", [])), getattr(g2, "kill_log", None))
    g2.close()
    # 되감은 뒤 다시 켜기: 기록 파일 안의 되감기 뒤 시점은 버림 (장로 · 킬 관여 오류 방지)
    g3 = gl.Game("TEST", PLAYERS)
    check("되감은 뒤 재시작 → 그 뒤 경기 기록 없음", all(e["t"] <= 600 for e in g3.timeline), [e["t"] for e in g3.timeline])
    check("되감은 뒤 재시작 → 그 뒤 킬 기록 없음", all(x[0] <= 600 for x in getattr(g3, "kill_log", [])))
    g3.close()

    # 공허 유충 3마리를 4초 간격으로 → 마지막 뒤 8초 지나서 "+3" 한 번 (새 경기로 따로)
    gg = gl.Game("TESTG", PLAYERS)
    vv = view([500] * 10)
    def topg(n):
        x = top(); x["blue"]["grubs"] = n; return x
    for tt, n in [(500, 0), (501, 0), (502, 1), (503, 1), (506, 2), (507, 2), (510, 3), (511, 3)]:
        gg.update(float(tt), vv[:5], vv[5:], [], topg(n))
    early = [a for a in gg.alerts if a["kind"] == "grubs"]
    for tt in (518, 527):   # 마지막(511) 뒤 15초 넘게 조용
        gg.update(float(tt), vv[:5], vv[5:], [], topg(3))
    gr = [a for a in gg.alerts if a["kind"] == "grubs"]
    check("유충 3마리 → 알림 한 번 '+3'", not early and len(gr) == 1 and "+3" in gr[0]["title"], [a["title"] for a in gr])
    gg.close()

    # 용 종류가 늦게 읽힘: 3번째 용은 3초 뒤 마법공학으로 읽힘 → 그 종류로 + 영혼 포인트 / 4번째는 끝까지 모름 → 협곡 속성(마법공학)으로 영혼
    gd = gl.Game("TESTD", PLAYERS)
    vv = view([500] * 10)
    def topd(n, types):
        x = top(); x["red"]["dragons"] = n; x["red"]["dragon_types"] = types; return x
    seq = [(700, 2, ["ocean", "hextech"]), (701, 2, ["ocean", "hextech"]), (702, 3, ["ocean", "hextech", "unknown"]),
           (703, 3, ["ocean", "hextech", "unknown"]), (706, 3, ["ocean", "hextech", "hextech"]),
           (900, 4, ["ocean", "hextech", "hextech", "unknown"]), (901, 4, ["ocean", "hextech", "hextech", "unknown"])]
    for tt, n, ty in seq:
        gd.update(float(tt), vv[:5], vv[5:], [], topd(n, ty))
    for tt in range(902, 912):
        gd.update(float(tt), vv[:5], vv[5:], [], topd(4, ["ocean", "hextech", "hextech", "unknown"]))
    d3 = [a for a in gd.alerts if a["kind"] == "dragon"]
    sl = [a for a in gd.alerts if a["kind"] == "soul"]
    check("3번째 용: 종류 읽힐 때까지 기다렸다 '마법공학 · 영혼 포인트'", d3 and d3[-1]["title"].startswith("마법공학") and "영혼 포인트" in d3[-1]["sub"],
          [(a["title"], a["sub"]) for a in d3])
    check("영혼: 끝까지 모르면 협곡 속성으로 '마법공학 드래곤의 영혼'", sl and sl[0]["title"].startswith("마법공학"), [a["title"] for a in sl])
    gd.close()

    # 빈 값: 골드를 못 읽은 선수(None)가 있어도 죽지 않음
    g3 = gl.Game("TEST2", PLAYERS)
    v = view([None] + [500] * 9)
    try:
        g3.update(100, v[:5], v[5:], [], None)
        g3.update(101, v[:5], v[5:], [{"EventID": 1, "EventName": "ChampionKill", "EventTime": 101, "KillerName": "?", "VictimName": "B0"}], {})
        ok = True
    except Exception:
        traceback.print_exc()
        ok = False
    check("골드 None · 상단바 없음 · 모르는 이름 이벤트에도 안 죽음", ok)
    g3.close()

    print("■ 라인업 해석")
    import entry_parser as ep
    p = ep.parse("ALT S11 R3 11월 21일 FB vs GST\nHome Team : 블루\n1set 지하 70\nFB\nTOP: 10 a\nJGL: 11 b\nMID: 12 c\nADC: 13 d\nSPT: 14 e\nvs\nGST\nf 1\ng 2\nh 3\ni 4\nj 5")
    check("시즌·라운드·날짜", (p["season"], p["round"], p["label"], p["date"]) == (11, 3, "R3", "11월 21일"), (p["season"], p["round"], p["label"], p["date"]))
    check("포지션 표기 이름", [x["name"] for x in p["sets"][0]["teams"][0]["players"]] == list("abcde"))
    check("빈 글", ep.parse("")["sets"] == [] and ep.parse("")["warnings"])

    print("■ 챔피언 기록")
    import champ_facts as cf
    check("리그 데이터 없음 → 빈 목록", cf.build(None, []) == [] and cf.build({}, []) == [])
    feed = json.loads((Path(__file__).resolve().parent.parent / "captures" / "league_feed.json").read_text(encoding="utf-8"))
    try:
        r = cf.build(feed, [{"champ": "없는챔프", "img": "X", "who": "누군가", "side": "blue", "team": None}])
        check("모르는 챔피언 · 팀 없음", r == [])
    except Exception:
        traceback.print_exc()
        check("모르는 챔피언 · 팀 없음", False)

    print("■ 서버 함수")
    import hud_server as hs
    try:
        hs.health_checks({"ok": False, "message": "관전 창 없음"})
        hs.health_checks({"ok": True, "goldRead": 3, "csRead": 2, "topbarReader": False, "timers": {}, "gameTime": 500})
        check("점검표: 관전 없음 · 일부만 읽힘", True)
    except Exception:
        traceback.print_exc()
        check("점검표: 관전 없음 · 일부만 읽힘", False)
    try:
        saved = dict(hs.ENTRY)
        hs.ENTRY.clear(); hs.ENTRY.update({"parsed": None, "set": None, "swap": False})
        hs.auto_pick_set("x", [], [])
        hs.entry_view()
        hs.with_ui({"ok": False, "message": ""})
        hs.ENTRY.clear(); hs.ENTRY.update(saved)
        check("라인업 없을 때 자동 선택 · 상태", True)
    except Exception:
        traceback.print_exc()
        check("라인업 없을 때 자동 선택 · 상태", False)
    # 첫 코어 아이템: 들어올 때 이미 가진 건 무시, 그 뒤 처음 완성한 전설템만 기록
    try:
        hs.ITEMS.clear(); hs.ITEMS.update({1001: {"name": "장화", "core": False}, 3031: {"name": "무한의 대검", "core": True}, 3046: {"name": "유령 무희", "core": True}})
        hs.game = gl.Game("TESTI", PLAYERS)
        pl = [{"name": n, "champion": f"C{i}", "championName": f"챔{i}", "items": []} for i, n in enumerate(NAMES)]
        pl[3]["items"] = [{"id": 3046}]                       # 처음부터 코어 보유
        hs.check_items("I", pl, 600)
        pl[0]["items"] = [{"id": 1001}]; hs.check_items("I", pl, 610)
        pl[0]["items"] = [{"id": 1001}, {"id": 3031}]; hs.check_items("I", pl, 620)
        pl[0]["items"] += [{"id": 3046}]; hs.check_items("I", pl, 700)   # 두 번째 코어는 기록 안 함
        pl[3]["items"] += [{"id": 3031}]; hs.check_items("I", pl, 710)   # 처음부터 코어 있던 선수도 기록 안 함
        it = hs.game.core_items
        check("첫 코어 아이템만 따로 기록 (1건, 경기 기록 칸은 안 씀)", len(it) == 1 and it[0]["item"] == 3031 and it[0]["text"] == "챔0 무한의 대검", it)
        check("첫 코어는 자동으로 화면에 안 뜸", not any(a["kind"] == "item" for a in hs.game.active_alerts()))
        hs.game.close(); hs.game = None
    except Exception:
        traceback.print_exc()
        check("라인업 없을 때 자동 선택 · 상태", False)


try:
    run()
finally:
    shutil.rmtree(TMP, ignore_errors=True)
print(f"\n결과: 실패 {len(FAIL)}개" + (" — " + ", ".join(FAIL) if FAIL else " (전부 통과)"))
sys.exit(1 if FAIL else 0)
