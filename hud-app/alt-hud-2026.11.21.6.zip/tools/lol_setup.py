"""롤 관전 설정 자동 맞춤 — 'ALT HUD.exe'를 켜면 HUD 서버가 부름.

관전에만 쓰이는 설정만 바꿈 (평소 게임에는 영향 없음):
  [General] EnableReplayApi=1          리플레이 기능 (선택 선수 · 오브젝트 타이머 창 · 타임라인 숨김)
  [HUD]     MinimapScaleSpectator=1.55 관전 미니맵 크기 31 (HUD 오른쪽 아래 배치 기준)
  [Replay]  EnableDirectedCamera=1     관전 자동 카메라
  [General] Width=1920 Height=1080 + 창 모드  — 화면 읽기가 1920x1080 기준이라 필요 (평소 게임 화면도 이 크기가 됨)
            모니터가 1920x1080이면 전체 창 모드(테두리 없음), 더 크면 창 모드, 더 작으면 못 맞춤(점검표 경고)
인터페이스 크기는 바꾸지 않음.

- 게임(관전) 창이 떠 있는 동안은 안 건드림 (그 판엔 적용도 안 되므로). 다음 관전부터 적용.
- 처음 바꿀 때 원래 파일을 game.cfg.alt-backup / PersistedSettings.json.alt-backup 으로 한 번만 백업.
- 되돌리기: ALT HUD.exe --restore-lol
"""
import json
import os
import shutil
import subprocess
from pathlib import Path

WANT = [("General", "EnableReplayApi", "1"),
        ("HUD", "MinimapScaleSpectator", "1.5500"),
        ("Replay", "EnableDirectedCamera", "1")]
LABEL = {"EnableReplayApi": "리플레이 기능", "MinimapScaleSpectator": "관전 미니맵 31", "EnableDirectedCamera": "관전 자동 카메라",
         "Width": "해상도 1920x1080", "Height": "해상도 1920x1080", "WindowMode": "창 모드"}


def screen_size():
    """주 모니터 실제 픽셀 크기 (윈도우 배율 영향 없이)."""
    try:
        import ctypes
        u = ctypes.windll.user32
        try:
            u.SetProcessDPIAware()
        except Exception:
            pass
        return u.GetSystemMetrics(0), u.GetSystemMetrics(1)
    except Exception:
        return None


def wanted():
    """맞출 값 목록 + 모니터가 작아 해상도를 못 맞추면 small=True."""
    w = list(WANT)
    sz = screen_size()
    if not sz:
        return w, False
    if sz[0] < 1920 or sz[1] < 1080:
        return w, True
    mode = "2" if sz == (1920, 1080) else "1"   # 2 = 전체 창 모드, 1 = 창 모드
    return w + [("General", "Width", "1920"), ("General", "Height", "1080"), ("General", "WindowMode", mode)], False


def config_dirs():
    """롤 설치 위치의 Config 폴더들 (Riot 설치 기록 → 흔한 위치 순)."""
    found = []
    try:
        d = json.loads(Path(os.environ.get("ProgramData", r"C:\ProgramData"), "Riot Games", "RiotClientInstalls.json").read_text(encoding="utf-8"))
        found += [Path(p) / "Config" for p in (d.get("associated_client") or {})]
    except Exception:
        pass
    for drv in "CDEFG":
        found.append(Path(f"{drv}:/Riot Games/League of Legends/Config"))
    out = []
    for p in found:
        try:
            if (p / "game.cfg").is_file() and p.resolve() not in [x.resolve() for x in out]:
                out.append(p)
        except OSError:
            pass
    return out


def game_running():
    try:
        r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq League of Legends.exe", "/NH"], capture_output=True, text=True,
                           encoding="mbcs", errors="replace", timeout=10, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return "League of Legends.exe" in r.stdout
    except Exception:
        return False


def _set_ini(text, section, key, value):
    """줄 단위로 [section] 안의 key=value 를 바꾸거나 넣음 (나머지 줄 · 줄바꿈 그대로)."""
    nl = "\r\n" if "\r\n" in text else "\n"
    lines = text.split(nl)
    sec_at, end_at = None, len(lines)
    for i, ln in enumerate(lines):
        s = ln.strip()
        if s.startswith("[") and s.endswith("]"):
            if sec_at is not None:
                end_at = i
                break
            if s[1:-1] == section:
                sec_at = i
    if sec_at is None:
        lines += [f"[{section}]", f"{key}={value}"]
        return nl.join(lines), True
    for i in range(sec_at + 1, end_at):
        if lines[i].split("=", 1)[0].strip() == key:
            if lines[i].split("=", 1)[1].strip() == value:
                return text, False
            lines[i] = f"{key}={value}"
            return nl.join(lines), True
    lines.insert(sec_at + 1, f"{key}={value}")
    return nl.join(lines), True


def _backup(f):
    b = f.with_name(f.name + ".alt-backup")
    if not b.exists():
        shutil.copy2(f, b)


def apply():
    """맞춰야 할 설정을 맞춤. 돌려줌: {"status": ok|changed|later|nolol, "changed": [...], "dirs": n}"""
    dirs = config_dirs()
    if not dirs:
        return {"status": "nolol", "changed": [], "dirs": 0}
    if game_running():
        return {"status": "later", "changed": [], "dirs": len(dirs)}
    changed = []
    want, small = wanted()
    for d in dirs:
        f = d / "game.cfg"
        try:
            raw = f.read_bytes()
            text = raw.decode("utf-8-sig")
            new = text
            for sec, key, val in want:
                new, ch = _set_ini(new, sec, key, val)
                if ch and LABEL[key] not in changed:
                    changed.append(LABEL[key])
            if new != text:
                _backup(f)
                f.write_bytes(new.encode("utf-8"))
            # 롤 클라이언트가 함께 기억하는 값(관전 미니맵)은 PersistedSettings.json 에도 맞춰야 되돌아가지 않음
            ps = d / "PersistedSettings.json"
            if ps.is_file():
                pd = json.loads(ps.read_text(encoding="utf-8-sig"))
                hit = False
                for fl in pd.get("files", []):
                    for sec in fl.get("sections", []):
                        for s in sec.get("settings", []):
                            if s.get("name") == "MinimapScaleSpectator" and s.get("value") != "1.5500":
                                s["value"] = "1.5500"
                                hit = True
                if hit:
                    _backup(ps)
                    ps.write_text(json.dumps(pd, ensure_ascii=False, indent=4), encoding="utf-8")
                    if LABEL["MinimapScaleSpectator"] not in changed:
                        changed.append(LABEL["MinimapScaleSpectator"])
        except Exception:
            continue
    return {"status": "changed" if changed else "ok", "changed": changed, "dirs": len(dirs), "small": small}


def restore():
    """백업해 둔 원래 설정으로 되돌림."""
    n = 0
    for d in config_dirs():
        for name in ("game.cfg", "PersistedSettings.json"):
            b = d / (name + ".alt-backup")
            if b.exists():
                shutil.copy2(b, d / name)
                n += 1
    return n


if __name__ == "__main__":
    import sys
    print(restore() if "--restore" in sys.argv else apply())
