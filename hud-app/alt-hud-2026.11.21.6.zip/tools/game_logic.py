"""경기 로직: 자동 기록 저장, 골드 흐름(0분부터), 한타·역전·대형 오브젝트 감지, 바론/장로 버프 타이머.

hud_server가 매초 update()를 부른다. 무거운 계산 없음 (1초에 한 번, 리스트 몇 개).

기록 파일: captures/logs/<시작시각>_<블루챔프들>_vs_<레드챔프들>.jsonl
  1줄째  {"type":"meta", players:[...], startedAt}
  이후   {"type":"tick", t, gold:[10], cur:[10], cs:[10], kda:[[k,d,a]x10], lvl:[10], bounty:[10], top:{...}}
         {"type":"event", ...라이엇 이벤트 원본}
         {"type":"alert", ...HUD에 띄운 알림}
리그리포트는 이 파일만 있으면 경기 전체를 1초 단위로 다시 계산할 수 있다.
"""
import json
import time
from pathlib import Path

LOG_DIR = Path(__file__).resolve().parent.parent / "captures" / "logs"
HIST_STEP = 5          # 골드 흐름 그래프 간격(초)
MINION_SPAWN = 65      # 첫 미니언 등장(1:05) 전에는 패시브 골드 없음
FIGHT_GAP = 12         # 킬 사이 간격이 이보다 짧으면 같은 한타
FIGHT_SETTLE = 8       # 마지막 킬 후 이만큼 조용하면 한타 종료로 판정
FIGHT_MIN_KILLS = 3
REVERSAL_MIN = 500     # 역전 판정: 반대쪽으로 이만큼 이상 앞서던 상태에서 뒤집혀야 함
DRAGON_WAIT = 6        # 용 알림: 종류가 읽힐 때까지 최대 이만큼 기다림
GRUB_WAIT = 15         # 공허 유충: 마지막 처치 후 이만큼 조용하면 묶어서 한 번 알림 (실전에서 9초 간격으로 잡힘)
ALERT_SEC = 7          # 알림 표시 시간(실제 초)
BARON_BUFF = 180
ELDER_BUFF = 150
# 바론 처치 골드: 팀 전원 150 × 5 + 막타 100 = 850 (26.1 패치 기준, 기획자 확인).
# 감지 시점의 팀 골드차에는 이미 이 골드가 들어가 있으므로, 파워플레이는 +850에서 시작해 이후 변화를 더한다.
BARON_GOLD = 850

# 자동으로 방송에 띄우는 알림 (기획자 결정). 나머지(한타 결과·에이스·첫 포탑·억제기)는
# 계산·기록만 해 두고 중계자가 컨트롤 페이지 버튼을 눌렀을 때 띄운다.
AUTO_KINDS = {"dragon", "soul", "elder", "baron", "herald", "grubs", "powerplay", "reversal", "comeback"}

DRAGON_KO = {"chemtech": "화학공학", "ocean": "바다", "hextech": "마법공학", "infernal": "화염",
             "mountain": "대지", "cloud": "바람", "elder": "장로", "unknown": ""}


class Game:
    def __init__(self, sig, players):
        self.sig = sig
        self.players = players            # [{name, champion, team, position}]
        self.team_of = {p["name"]: p["team"] for p in players}
        self.idx_of = {p["name"]: i for i, p in enumerate(players)}   # 블루 0~4, 레드 5~9
        self.history = []                 # [(t, 팀 골드차)]
        self.player_hist = {}             # name -> [(t, 누적 골드)]
        self.seen_events = set()
        self.event_t = {}                 # 이벤트 번호 -> 게임 시각 (되감기 때 그 뒤 이벤트를 다시 받으려고)
        self.kills = []                   # [(t, 킬한 팀)]
        self.fight = None                 # 진행 중 한타 {start, last, blue, red, diff0}
        self.alerts = []                  # [{id, kind, team, title, sub, t, until}] 방송에 뜬 알림
        self.recent = {}                  # kind -> 버튼으로 띄울 수 있게 대기 중인 최신 알림
        self.lead_state = 0               # +1 블루가 REVERSAL_MIN 이상 앞섬 / -1 레드 / 0
        self.top_prev = {"blue": {}, "red": {}}   # 안정된(2회 연속) 상단바 값
        self.top_pending = {"blue": {}, "red": {}}
        self.buffs = {"blue": None, "red": None}  # {"type": baron|elder, "until": 게임시간, "diff0": 시작 시 팀 골드차}
        self.soul_claimed = False
        self.grub_pending = {}
        self.drg_pending = {}             # 팀 -> {cur, t} 용 종류 확인 대기            # 팀 -> {from, cur, last} 유충 알림 묶기 대기
        self.cur_diff = None              # 최신 팀 골드차 (블루 - 레드)
        self.last_dead = [False] * 10      # 최신 생존 상태 (블루 0~4, 레드 5~9)
        self.timeline = []                # 경기 기록: 오브젝트·한타 등 시간순 [{t, kind, team, text, ...}]
        self.core_items = []              # 첫 코어 아이템 완성 [{t, team, text, item}] (중계 콘솔용)
        self.last_t = None
        self.first_tick_t = None
        self.log = None
        self._open_log()

    # ── 기록 ──
    def _open_log(self):
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        existing = sorted(LOG_DIR.glob(f"*_{self.sig}.jsonl"))
        if existing:      # 같은 경기 기록이 있으면 이어 붙이고, 골드 흐름을 복원
            path = existing[-1]
            self._restore(path)
        else:
            path = LOG_DIR / f"{time.strftime('%Y%m%d-%H%M%S')}_{self.sig}.jsonl"
            path.write_text(json.dumps({"type": "meta", "startedAt": time.time(), "players": self.players}, ensure_ascii=False) + "\n", encoding="utf-8")
        self.log_path = path
        self.log = open(path, "a", encoding="utf-8")

    def _restore(self, path):
        """서버를 다시 켰을 때 같은 경기 기록 파일에서 되살림: 골드 흐름 · 경기 기록 · 대기 중 한타 결과 · 진행 중 바론/장로 버프."""
        buff = None   # 기록에서 마지막으로 시작된 버프 [팀, 종류, 시각, 보유자]
        try:
            for line in path.read_text(encoding="utf-8").splitlines():
                r = json.loads(line)
                ty = r.get("type")
                if ty == "tick":
                    if None not in r["gold"]:
                        self._add_history(r["t"], r["gold"])
                    dead = r.get("dead") or []
                    if buff and len(dead) == 10:
                        buff[3] = [i for i in buff[3] if not dead[i]]
                    self._restore_dead = dead
                    if self.last_t is not None and r["t"] < self.last_t - 5:   # 기록 안의 되감기: 그 시점 뒤 기록은 버림
                        rt = r["t"]
                        if getattr(self, "kill_log", None):
                            self.kill_log = [x for x in self.kill_log if x[0] <= rt]
                        self.timeline = [e for e in self.timeline if e["t"] <= rt]
                        later = {i for i, et in self.event_t.items() if et > rt}
                        self.seen_events -= later
                        for i in later:
                            self.event_t.pop(i, None)
                        if buff and buff[2] > rt:
                            buff = None
                    self.last_t = r["t"]   # 기록의 마지막 시각: 다시 켰을 때 경기가 그보다 앞이면(되감김) 첫 틱에서 되감기로 처리
                elif ty == "event":
                    if r.get("EventID") in self.seen_events:   # 되감기 뒤 다시 받은 같은 이벤트는 한 번만
                        continue
                    if self.last_t is not None and r.get("EventTime", 0) > self.last_t + 3:   # 예전 버전이 남긴 '미래' 이벤트
                        continue
                    self.seen_events.add(r.get("EventID"))
                    self.event_t[r.get("EventID")] = r.get("EventTime", 0)
                    if r.get("EventName") == "ChampionKill":   # 킬 기록도 되살림 ('킬 관여' 카드)
                        if not hasattr(self, "kill_log"):
                            self.kill_log = []
                        self.kill_log.append([round(r.get("EventTime", 0)), self.idx_of.get(r.get("KillerName")), self.idx_of.get(r.get("VictimName")),
                                              [x for x in (self.idx_of.get(n) for n in (r.get("Assisters") or [])) if x is not None]])
                elif ty in ("alert", "candidate") and not r.get("byButton"):
                    if self.last_t is not None and r.get("t", 0) > self.last_t + 3:   # 미래 이벤트로 생긴 기록 (예전 버전)
                        continue
                    extra = {k: v for k, v in r.items() if k not in ("type", "id", "kind", "team", "title", "sub", "t", "big")}
                    self._add_timeline(r["kind"], r.get("team"), r.get("title", ""), r.get("sub", ""), r.get("t", 0), extra)
                    if r["kind"] == "soul":
                        self.soul_claimed = True
                    if ty == "candidate":
                        self.recent[r["kind"]] = {k: v for k, v in r.items() if k != "type"}
                    if r["kind"] == "elder" and not any(e.get("kind") == "soul" and e["t"] < r.get("t", 0) for e in self.timeline):
                        self.timeline = [e for e in self.timeline if not (e.get("kind") == "elder" and e["t"] == round(r.get("t", 0)))]
                        continue   # 영혼 전에 잡힌 '장로' = 되감기 때 잘못 잡힌 것 (예전 버그) → 버림
                    if r["kind"] in ("baron", "elder") and r.get("team") in ("blue", "red"):
                        side = range(5) if r["team"] == "blue" else range(5, 10)
                        dead = getattr(self, "_restore_dead", None) or [False] * 10
                        buff = [r["team"], r["kind"], r.get("t", 0), [i for i in side if not dead[i]]]
        except Exception:
            pass
        self._pending_buff = buff

    def _write(self, obj):
        try:
            self.log.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")
            self.log.flush()
        except Exception:
            pass

    def close(self):
        try:
            self.log.close()
        except Exception:
            pass

    # ── 골드 흐름 ──
    def _add_history(self, t, golds):
        diff = sum(golds[:5]) - sum(golds[5:])
        if self.history and t < self.history[-1][0] - 5:     # 되감기: 그 시점 이후 기록을 잘라냄
            self.history = [h for h in self.history if h[0] <= t]
            for k in self.player_hist:
                self.player_hist[k] = [h for h in self.player_hist[k] if h[0] <= t]
        # 시작 구간 보정: 미니언이 나오기 전(1:05)에는 모두 시작 골드라 팀 골드차가 확실히 0.
        # 첫 기록이 그 전이고 차이가 0이면 0:00부터 이어 그림 (하단표가 아직 아이템 모드였던 초반 몇십 초 등).
        if not self.history and t <= MINION_SPAWN and diff == 0:
            self.history.append((0.0, 0))
            for p, g in zip(self.players, golds):
                self.player_hist.setdefault(p["name"], []).append((0.0, g))
        if not self.history or t - self.history[-1][0] >= HIST_STEP:
            self.history.append((round(t, 1), diff))
            for p, g in zip(self.players, golds):
                self.player_hist.setdefault(p["name"], []).append((round(t, 1), g))

    def team_diff_at(self, t):
        best = None
        for ht, d in self.history:
            if ht <= t:
                best = d
            else:
                break
        return best

    # ── 알림 ──
    def alert(self, kind, team, title, sub="", t=0.0, big=False, force=False, **extra):
        a = {"id": f"{kind}-{len(self.alerts)}-{int(time.time() * 1000)}", "kind": kind, "team": team,
             "title": title, "sub": sub, "t": round(t), "big": big, "until": time.time() + ALERT_SEC, **extra}
        self._add_timeline(kind, team, title, sub, t, extra)
        auto = force or kind in AUTO_KINDS
        self._write({"type": "alert" if auto else "candidate", **{k: v for k, v in a.items() if k != "until"}})
        if not auto:   # 버튼용: 가장 최근 것만 대기
            self.recent[kind] = a
            return
        self.alerts.append(a)
        self.alerts = self.alerts[-20:]

    def _add_timeline(self, kind, team, title, sub, t, extra):
        """골드 그래프 옆 '경기 기록' 한 줄. 버튼용(한타)도 기록에는 바로 들어감."""
        e = {"t": round(t), "kind": kind, "team": team}
        if kind in ("dragon", "soul", "elder", "baron", "herald", "grubs"):
            e["text"] = title.replace(" 처치", "")
            if extra.get("dtype"):
                e["dtype"] = extra["dtype"]
        elif kind == "fight":
            kl = extra.get("kills") or [0, 0]
            e["text"] = f"한타 {kl[0]}:{kl[1]}"
            if extra.get("swing") is not None:
                e["swing"] = extra["swing"]      # + = 블루가 골드 이득
        elif kind == "powerplay":
            e["text"] = ("바론" if "BARON" in title else "장로") + " 파워 플레이 " + sub.replace(" GOLD", "")
        elif kind == "item":   # 첫 코어 아이템 완성: "징크스 무한의 대검"
            e["text"] = title
            e["item"] = extra.get("item")
        else:
            e["text"] = {"ace": "에이스", "tower": "첫 포탑", "inhib": "억제기 파괴", "reversal": "골드 역전"}.get(kind, title)
        if kind == "item":   # 첫 코어 아이템은 따로 (경기 기록 칸을 밀어내지 않게 — 중계 콘솔용)
            self.core_items.append(e)
            self.core_items = self.core_items[-20:]
            return
        self.timeline.append(e)
        self.timeline.sort(key=lambda x: x["t"])   # 묶어서 늦게 띄운 알림(유충 등)도 실제 시각 순서대로
        self.timeline = self.timeline[-60:]

    def recent_gains(self, t, window=180):
        """최근 3분 동안 팀별 번 골드. 수집이 30초 미만이면 None."""
        # 구간 시작 = 3분 전 이후의 첫 기록 (되감기·건너뛰기로 기록이 비면 그만큼 짧아짐)
        t0 = next((ht for ht, _ in self.history if ht >= t - window), None)
        if t0 is None:
            return None
        if t - t0 < 30:
            return None
        g = self.gains_between(t0, t)
        if None in g:
            return None
        return {"blue": sum(g[:5]), "red": sum(g[5:]), "window": round(t - t0)}

    def hide(self, kind):
        """중계자 버튼 다시 누름: 지금 떠 있는 그 종류 알림을 바로 내림."""
        before = len(self.alerts)
        self.alerts = [a for a in self.alerts if a["kind"] != kind]
        return len(self.alerts) != before

    def show(self, kind):
        """중계자 버튼: 대기 중인 알림(예: 최근 한타 결과)을 지금 방송에 띄움."""
        a = self.recent.get(kind)
        if not a:
            return False
        b = dict(a, id=f"{kind}-show-{int(time.time() * 1000)}", until=time.time() + ALERT_SEC)
        self.alerts.append(b)
        self.alerts = self.alerts[-20:]
        self._write({"type": "alert", "byButton": True, **{k: v for k, v in b.items() if k != "until"}})
        return True

    def recent_view(self):
        return {k: {"title": a["title"], "sub": a["sub"], "t": a["t"], "team": a["team"]} for k, a in self.recent.items()}
    def active_alerts(self):
        now = time.time()
        return [{k: v for k, v in a.items() if k != "until"} for a in self.alerts if a["until"] > now]

    # ── 매초 갱신 ──
    def update(self, t, blue_v, red_v, events, top):
        players = blue_v + red_v
        golds = [p["gold_total"] for p in players]
        rewound = self.last_t is not None and t < self.last_t - 5
        if rewound:   # 되감기: 진행 중 판정 초기화
            self.fight = None
            self.buffs = {"blue": None, "red": None}
            self.top_prev = {"blue": {}, "red": {}}
            self.top_pending = {"blue": {}, "red": {}}
            self.timeline = [e for e in self.timeline if e["t"] <= t]
            self.drg_pending = {}
            # 영혼 상태도 되감은 시점 기준으로 (안 하면 되감은 뒤 3번째 용이 '장로'로 잡힘)
            self.soul_claimed = any(e.get("kind") == "soul" for e in self.timeline)
            # 킬 기록도 되감은 시점까지만 (안 하면 '킬 관여' 카드에 미래 킬이 남음). 그 뒤 이벤트는 다시 받음
            if getattr(self, "kill_log", None):
                self.kill_log = [x for x in self.kill_log if x[0] <= t]
            later = {i for i, et in self.event_t.items() if et > t}
            self.seen_events -= later
            for i in later:
                self.event_t.pop(i, None)
        self.last_t = t
        if self.first_tick_t is None:
            self.first_tick_t = t
        pb = getattr(self, "_pending_buff", None)
        if pb:
            self._pending_buff = None
            team, kind, t0, holders = pb
            dur = BARON_BUFF if kind == "baron" else ELDER_BUFF
            if t0 <= t < t0 + dur:
                self.buffs[team] = {"type": kind, "until": t0 + dur, "start": t0, "diff0": self.team_diff_at(t0),
                                    "bonus": BARON_GOLD if kind == "baron" else 0, "holders": holders}

        if getattr(self, "_last_tick_t", None) == round(t, 1):   # 시계가 멈춤 (경기 끝 결과 화면 · 일시정지) → 같은 기록 반복 안 함
            return
        self._last_tick_t = round(t, 1)
        self._write({"type": "tick", "t": round(t, 1), "gold": golds, "cur": [p["gold_current"] for p in players],
                     "cs": [p["cs"] for p in players], "kda": [[p["k"], p["d"], p["a"]] for p in players],
                     "lvl": [p["level"] for p in players], "bounty": [p["bounty"] for p in players],
                     "dead": [p["dead"] for p in players], "ward": [p.get("ward") for p in players],   # 시야 점수 (리포트 시야 지표용)
                     "top": top})
        self.last_dead = [bool(p["dead"]) for p in players]
        # 아이템: 바뀔 때만 기록 ('템 증발' 추적용 — 게임이 준 목록 그대로, 칸 번호 포함)
        its = [[[i.get("id"), i.get("slot")] for i in (p.get("items") or [])] for p in players]
        if its != getattr(self, "_last_items", None):
            self._last_items = its
            self._write({"type": "items", "t": round(t, 1), "items": its})
        # 체력 비율 기록 (양옆 초상화 막대를 읽은 값, 한타 리포트용 · 최근 90초)
        hh = getattr(self, "hp_hist", None)
        if hh is None:
            hh = self.hp_hist = []
        hh.append((t, [0.0 if p.get("dead") else p.get("hp") for p in players]))
        while hh and hh[0][0] < t - 90:
            hh.pop(0)

        if None not in golds:
            self.cur_diff = sum(golds[:5]) - sum(golds[5:])
            self._add_history(t, golds)
            self._check_reversal(t)

        for e in events:
            if e.get("EventTime", 0) > t + 3:   # 되감은 관전은 아직 안 일어난 '미래' 이벤트도 넘겨줌 → 그 시각이 올 때까지 무시
                continue
            if e.get("EventID") in self.seen_events:
                continue
            self.seen_events.add(e.get("EventID"))
            self.event_t[e.get("EventID")] = e.get("EventTime", t)
            self._write({"type": "event", **e})
            if not rewound:
                self._on_event(e, t)

        self._check_fight_end(t)
        if top:
            self._check_objectives(t, top)
        for team in ("blue", "red"):
            b = self.buffs[team]
            if b:   # 버프 보유자: 죽으면 버프를 잃음
                b["holders"] = [i for i in b["holders"] if not self.last_dead[i]]
            if b and b["until"] <= t:     # 버프 종료 → 파워플레이 최종 결과
                gain = self.power_gain(team)
                self.buffs[team] = None
                if gain is not None:
                    name = "BARON" if b["type"] == "baron" else "ELDER"
                    self.alert("powerplay", team, f"{name} POWER PLAY", f"{'+' if gain >= 0 else '-'}{abs(gain):,} GOLD", t, big=True)

    # ── 바론/장로 파워플레이: 버프를 얻은 뒤 벌어진 팀 골드차 (버프 팀 기준) ──
    def start_buff(self, team, kind, t):
        dur = BARON_BUFF if kind == "baron" else ELDER_BUFF
        self.buffs[team] = {"type": kind, "until": t + dur, "start": t, "diff0": self.cur_diff,
                            "bonus": BARON_GOLD if kind == "baron" else 0,
                            # 버프 받은 선수 = 그 순간 살아 있던 같은 팀 선수 (0~9 번호)
                            "holders": [i for i in (range(5) if team == "blue" else range(5, 10)) if not self.last_dead[i]]}

    def power_gain(self, team):
        b = self.buffs[team]
        if not b or b.get("diff0") is None or self.cur_diff is None:
            return None
        g = self.cur_diff - b["diff0"]
        return (g if team == "blue" else -g) + b.get("bonus", 0)

    # ── 이벤트 → 한타 / 에이스 / 첫 포탑 ──
    def _kill_team(self, e):
        killer_team = self.team_of.get(e.get("KillerName"))
        victim_team = self.team_of.get(e.get("VictimName"))
        if killer_team:
            return "blue" if killer_team == "ORDER" else "red"
        if victim_team:   # 포탑/미니언 처치 → 상대 팀 득점
            return "red" if victim_team == "ORDER" else "blue"
        return None

    def _on_event(self, e, now_t):
        name, et = e.get("EventName"), e.get("EventTime", now_t)
        if name == "ChampionKill":   # 경기 전체 킬 기록 (늦게 켜도 처음부터) [게임 초, 잡은 선수, 죽은 선수, 어시 선수들] — '킬 관여' 카드용
            kl = getattr(self, "kill_log", None)
            if kl is None:
                kl = self.kill_log = []
            kl.append([round(et), self.idx_of.get(e.get("KillerName")), self.idx_of.get(e.get("VictimName")),
                       [x for x in (self.idx_of.get(n) for n in (e.get("Assisters") or [])) if x is not None]])
        if now_t - et > 30:   # 오래된 이벤트(서버 늦게 켬)는 알림 없이 기록만
            return
        if name == "ChampionKill":
            self.last_kill_t = et   # 자동 연출: 조용한 시간 판단
            team = self._kill_team(e)
            if not team:
                return
            if self.fight and et - self.fight["last"] <= FIGHT_GAP:
                self.fight[team] += 1
                self.fight["last"] = et
            else:
                self.fight = {"start": et, "last": et, "blue": 0, "red": 0, "diff0": self.team_diff_at(et - 3),
                              "deaths": [0] * 10, "fkills": [0] * 10, "fassists": [0] * 10, "seq": []}
                self.fight[team] += 1
            # 한타 중 누가 죽고 누가 잡았는지 (선수 번호 0~9)
            vi, ki = self.idx_of.get(e.get("VictimName")), self.idx_of.get(e.get("KillerName"))
            if vi is not None:
                self.fight["deaths"][vi] += 1
            if ki is not None:
                self.fight["fkills"][ki] += 1
            ais = [x for x in (self.idx_of.get(n) for n in (e.get("Assisters") or [])) if x is not None]
            for x in ais:
                self.fight["fassists"][x] += 1
            # 킬 흐름: [게임 초, 잡은 선수, 죽은 선수, 어시 선수들, 득점 팀] (선수 번호 0~9, 포탑 · 미니언이면 None)
            self.fight["seq"].append([round(et), ki, vi, ais, team])
        elif name == "Ace":
            team = "blue" if e.get("AcingTeam") == "ORDER" else "red"
            self.alert("ace", team, "ACE", f"{'BLUE' if team == 'blue' else 'RED'} 전멸시킴", et)
        elif name == "FirstBrick":
            team = self._kill_team({"KillerName": e.get("KillerName")})
            if team:
                self.alert("tower", team, "첫 포탑 파괴", f"{'BLUE' if team == 'blue' else 'RED'}", et)
        elif name == "InhibKilled":
            team = self._kill_team({"KillerName": e.get("KillerName")}) or \
                ("blue" if "TChaos" in e.get("InhibKilled", "") else "red")
            self.alert("inhib", team, "억제기 파괴", f"{'BLUE' if team == 'blue' else 'RED'}", et)

    def _check_fight_end(self, t):
        f = self.fight
        if not f or t - f["last"] < FIGHT_SETTLE:
            return
        self.fight = None
        total = f["blue"] + f["red"]
        if total < FIGHT_MIN_KILLS:
            return
        winner = "blue" if f["blue"] > f["red"] else "red" if f["red"] > f["blue"] else None
        d1 = self.team_diff_at(t)
        swing = None if f["diff0"] is None or d1 is None else d1 - f["diff0"]
        sub = ""
        if swing is not None:
            sub = f"골드 +{abs(swing) / 1000:.1f}K {'BLUE' if swing >= 0 else 'RED'}"   # 이득 본 팀 기준
        hp0, hpmin, hp1 = self.hp_between(f["start"] - 4, t)
        # 한타 MVP: 킬 × 1.5 + 어시 + 살아남음 1.5. 이긴 팀에서 고름 (같으면 킬 많은 선수)
        def score(i):
            return f["fkills"][i] * 1.5 + f["fassists"][i] + (1.5 if f["deaths"][i] == 0 else 0)
        pool = [i for i in range(10) if winner is None or (i < 5) == (winner == "blue")]
        pool = [i for i in pool if f["fkills"][i] + f["fassists"][i] > 0]
        mvp = max(pool, key=lambda i: (score(i), f["fkills"][i])) if pool else None
        self.alert("fight", winner, f"한타 결과  BLUE {f['blue']} : {f['red']} RED", sub, t,
                   kills=[f["blue"], f["red"]], swing=swing, deaths=f["deaths"], fkills=f["fkills"], fassists=f["fassists"],
                   seq=f["seq"], hp0=hp0, hpmin=hpmin, hp1=hp1, mvp=mvp,
                   gains=self.gains_between(f["start"] - 3, t), start=round(f["start"]), end=round(t))

    def hp_between(self, t0, t1):
        """구간의 체력 비율 × 10명: (시작 전, 가장 낮았을 때, 끝). 기록이 없으면 None."""
        hh = [r for r in getattr(self, "hp_hist", []) if t0 - 2 <= r[0] <= t1]
        if not hh:
            return None, None, None
        low = [min((r[1][i] for r in hh if r[1][i] is not None), default=None) for i in range(10)]
        return hh[0][1], low, hh[-1][1]

    def gains_between(self, t0, t1):
        """구간 동안 선수별 획득 골드 (선수 순서 = 블루 5 + 레드 5). 기록이 없으면 None."""
        out = []
        for p in self.players:
            h = self.player_hist.get(p["name"], [])
            a = next((g for ht, g in reversed(h) if ht <= t0), None)
            b = next((g for ht, g in reversed(h) if ht <= t1), None)
            out.append(None if a is None or b is None else max(0, b - a))
        return out

    def _check_reversal(self, t):
        d = self.history[-1][1] if self.history else 0
        state = 1 if d >= REVERSAL_MIN else -1 if d <= -REVERSAL_MIN else 0
        if state and self.lead_state and state != self.lead_state:
            team = "blue" if state > 0 else "red"
            self.alert("reversal", team, "골드 역전!", f"{'BLUE' if team == 'blue' else 'RED'} {abs(d) / 1000:.1f}K 우세", t)
        if state:
            self.lead_state = state
        self._check_comeback(t)

    def _check_comeback(self, t):
        """추격 알림: 3천 이상 뒤졌던 팀이 최근 2분 동안 2천 이상 따라잡으면 (팀마다 3분에 한 번)."""
        if len(self.history) < 3:
            return
        cd = getattr(self, "_comeback_at", None)
        if cd is None:
            cd = self._comeback_at = {"blue": -1e9, "red": -1e9}
        now = self.history[-1][1]
        before = next((d for ht, d in reversed(self.history) if ht <= t - 120), None)
        if before is None:
            return
        for team, sg in (("blue", 1), ("red", -1)):
            worst = min(sg * d for _, d in self.history)   # 이 팀 기준 가장 크게 뒤졌던 골드 차 (음수)
            gain = sg * now - sg * before
            if worst <= -3000 and gain >= 2000 and sg * now <= 1000 and t - cd[team] >= 180:
                cd[team] = t
                name = "BLUE" if team == "blue" else "RED"
                self.alert("comeback", team, f"{name} 추격", f"최대 −{-worst / 1000:.1f}K · 최근 2분 +{gain / 1000:.1f}K", t,
                           worst=-worst, gain=gain)

    # ── 상단바 숫자 변화 → 대형 오브젝트 ──
    def _stable(self, team, key, val):
        """OCR 깜빡임 방지: 같은 값이 2번 연속 읽혀야 채택. 채택된 이전 값을 돌려줌."""
        if val is None:
            return None, None
        pend = self.top_pending[team]
        prev = self.top_prev[team].get(key)
        if pend.get(key) == val:
            self.top_prev[team][key] = val
            return prev, val
        pend[key] = val
        return prev, prev

    def _check_objectives(self, t, top):
        for team in ("blue", "red"):
            s = top.get(team) or {}
            label = "BLUE" if team == "blue" else "RED"
            prev, cur = self._stable(team, "dragons", s.get("dragons"))
            types = s.get("dragon_types") or []
            if prev is not None and cur is not None and cur > prev:
                kind = types[-1] if types else "unknown"
                if self.soul_claimed or (kind == "elder" and cur > 4):   # 장로는 영혼(4번째) 뒤에만. 막 나타나는 바람 아이콘이 잠깐 보라로 읽혀 장로 알림이 뜨던 것 (S11 R1 3세트 17:03)
                    self.start_buff(team, "elder", t)
                    self.alert("elder", team, "장로 드래곤 처치", label, t, big=True)
                else:   # 용 종류: 먹는 순간엔 새 아이콘이 막 나타나는 중이라 '모름'일 때가 많음 → 최대 DRAGON_WAIT초 기다림
                    self.drg_pending[team] = {"cur": cur, "t": t}
            dp = self.drg_pending.get(team)
            if dp:
                kind = types[dp["cur"] - 1] if len(types) >= dp["cur"] else "unknown"
                if kind == "unknown" and t - dp["t"] >= DRAGON_WAIT and len(types) >= 3 and dp["cur"] >= 3:
                    kind = next((x for x in types[2:] if x not in ("unknown", "elder")), "unknown")   # 3번째부터는 협곡 속성과 같은 용
                if kind != "unknown" or t - dp["t"] >= DRAGON_WAIT:
                    self.drg_pending.pop(team, None)
                    cur, td = dp["cur"], dp["t"]
                    if cur == 4:
                        self.soul_claimed = True
                        self.alert("soul", team, f"{DRAGON_KO.get(kind, '')} 드래곤의 영혼".strip(), label, td, big=True, dtype=kind)
                    else:
                        # 세 번째 용 = 다음 용을 먹으면 영혼 → "영혼 포인트"
                        self.alert("dragon", team, f"{DRAGON_KO.get(kind, '')} 드래곤 처치".strip(),
                                   f"{label} · {cur}번째" + (" · 영혼 포인트" if cur == 3 else ""), td, big=True, dtype=kind)
            prev, cur = self._stable(team, "obj2", s.get("obj2"))
            if prev is not None and cur is not None and cur > prev:
                if s.get("obj2_kind") == "baron":   # 이번 시즌 아타칸 없음 → 뿔 아이콘 = 바론
                    self.start_buff(team, "baron", t)
                    self.alert("baron", team, "내셔 남작 처치", label, t, big=True)
                else:
                    self.alert("herald", team, "협곡의 전령 처치", label, t, big=True)
            # 공허 유충: 1마리씩 연달아 잡히므로 마지막 처치 뒤 GRUB_WAIT초 조용하면 한 번에 "+3"으로 알림
            prev, cur = self._stable(team, "grubs", s.get("grubs"))
            gp = self.grub_pending.get(team)
            if prev is not None and cur is not None and cur > prev:
                if gp:
                    gp.update(cur=cur, last=t)
                else:
                    self.grub_pending[team] = {"from": prev, "cur": cur, "last": t}
            elif gp and t - gp["last"] >= GRUB_WAIT:
                self.grub_pending.pop(team, None)
                self.alert("grubs", team, f"공허 유충 +{gp['cur'] - gp['from']}", f"{label} · 총 {gp['cur']}마리", gp["last"])
            self._stable(team, "towers", s.get("towers"))

    def buff_view(self, t):
        out = {}
        for team in ("blue", "red"):
            b = self.buffs[team]
            out[team] = None if not b else {"type": b["type"], "remaining": max(0, round(b["until"] - t)),
                                            "gain": self.power_gain(team), "holders": b["holders"]}
        return out


def signature(blue, red):
    """같은 경기 판별용: 양 팀 챔피언 조합."""
    return "-".join(p["champion"] for p in blue) + "_vs_" + "-".join(p["champion"] for p in red)
