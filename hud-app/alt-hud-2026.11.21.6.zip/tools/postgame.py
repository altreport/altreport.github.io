"""경기가 끝나면 롤 클라이언트(LCU)에서 그 경기의 결과 기록 · 분 단위 타임라인을 받아 경기 기록 옆에 저장 (시험 기능).

- LCU = 이 PC에서 실행 중인 롤 클라이언트가 자기 자신에게만 여는 로컬 창구. 외부로 아무것도 보내지 않는다.
- 접속 정보(포트 · 임시 비밀번호)는 롤 설치 폴더의 lockfile에서 읽고, 화면 · 로그 · 파일에 남기지 않는다.
- 관전 중일 때 경기 번호(gameId)를 잡아 두고, 관전이 끝나면 몇 번 다시 물어본다 (기록 반영까지 시간이 걸림).
- 받으면 captures/logs/<경기 기록 이름>.match.json / .timeline.json 으로 저장 → '기록 보내기'에 같이 담김.
- 무엇이든 실패하면 조용히 넘어간다 (방송 · 다른 기능에 영향 없음). 결과는 STATUS에만 남김.
"""
import base64
import json
import os
import ssl
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

_ssl = ssl.create_default_context()
_ssl.check_hostname = False
_ssl.verify_mode = ssl.CERT_NONE

STATUS = {"gameId": None, "state": None, "msg": None}   # 점검표용 (비밀번호 등은 절대 안 담음)
_WATCH = {"gameId": None, "log": None, "thread": None}


def _lockfiles():
    """롤 설치 폴더의 lockfile 후보 (Riot 설치 기록 → 흔한 위치)."""
    found = []
    try:
        d = json.loads(Path(os.environ.get("ProgramData", r"C:\ProgramData"), "Riot Games", "RiotClientInstalls.json").read_text(encoding="utf-8"))
        found += [Path(p) / "lockfile" for p in (d.get("associated_client") or {})]
    except Exception:
        pass
    found += [Path(f"{drv}:/Riot Games/League of Legends/lockfile") for drv in "CDEFG"]
    return [f for f in found if f.is_file()]


def _get(path, timeout=8):
    """LCU GET → (상태 코드, JSON). lockfile이 없거나 실패하면 (None, None)."""
    for lf in _lockfiles():
        try:
            _name, _pid, port, pw, _proto = lf.read_text().split(":")
        except Exception:
            continue
        auth = base64.b64encode(f"riot:{pw}".encode()).decode()
        req = urllib.request.Request(f"https://127.0.0.1:{port}{path}", headers={"Authorization": f"Basic {auth}"})
        try:
            with urllib.request.urlopen(req, context=_ssl, timeout=timeout) as r:
                return r.status, json.loads(r.read().decode("utf-8") or "null")
        except urllib.error.HTTPError as e:
            return e.code, None
        except Exception:
            continue
    return None, None


def current_game_id():
    """관전(또는 게임) 중인 경기 번호. 모르면 None."""
    code, sess = _get("/lol-gameflow/v1/session")
    if code == 200 and sess:
        gid = (sess.get("gameData") or {}).get("gameId")
        return int(gid) if gid else None
    return None


def _fetch_and_save(gid, log_path):
    """관전이 끝날 때까지 기다렸다가 결과 · 타임라인을 받아 저장. 최대 약 60분 대기 + 6번 재시도."""
    try:
        limit = time.time() + 60 * 60
        while time.time() < limit:
            code, phase = _get("/lol-gameflow/v1/gameflow-phase")
            if phase not in ("InProgress", "Reconnect", "WaitingForStats", "GameStart"):
                break
            time.sleep(20)
        STATUS.update(state="waiting", msg="관전 끝, 경기 기록 반영 기다리는 중")
        base = Path(str(log_path)).with_suffix("")
        got_g = got_t = False
        for _ in range(6):
            time.sleep(30)
            if not got_g:
                c1, g = _get(f"/lol-match-history/v1/games/{gid}", timeout=15)
                if c1 == 200 and g and g.get("participants"):
                    Path(f"{base}.match.json").write_text(json.dumps(g, ensure_ascii=False), encoding="utf-8")
                    got_g = True
            if not got_t:
                c2, tl = _get(f"/lol-match-history/v1/game-timelines/{gid}", timeout=15)
                if c2 == 200 and tl and tl.get("frames"):
                    Path(f"{base}.timeline.json").write_text(json.dumps(tl, ensure_ascii=False), encoding="utf-8")
                    got_t = True
            if got_g and got_t:
                break
        STATUS.update(state="ok" if got_g else "fail",
                      msg=("결과" if got_g else "결과 없음") + " · " + ("타임라인" if got_t else "타임라인 없음") + f" (경기 {gid})")
        print(f"경기 후 기록: {STATUS['msg']}", flush=True)
    except Exception as e:
        STATUS.update(state="fail", msg=f"경기 후 기록 실패: {type(e).__name__}")


def watch(log_path):
    """경기 기록이 열려 있는 동안 서버가 가끔 부름. 경기 번호를 잡으면 끝날 때 받아 오는 일을 한 번만 걸어 둠."""
    if not log_path or _WATCH["log"] == str(log_path):
        return
    gid = current_game_id()
    if not gid:
        return
    _WATCH.update(gameId=gid, log=str(log_path))
    STATUS.update(gameId=gid, state="watching", msg=f"경기 {gid} 끝나면 결과 받기")
    t = threading.Thread(target=_fetch_and_save, args=(gid, log_path), daemon=True)
    _WATCH["thread"] = t
    t.start()
