"""스택 챔피언(나서스 · 스몰더) 스택 숫자 읽기 — 관전 화면 왼쪽 아래 '고른 챔피언' 칸 위의 버프 아이콘 숫자.

관전 데이터에는 스택이 없어서 화면에서 읽음. 옵저버(자동 카메라 포함)가 그 챔피언을 골라 둔 동안만 보임.
버프 아이콘: 27px 간격, 첫 칸 숫자 가운데 x≈15.5 · 숫자 가로 5 · 간격 6 · 세로 9칸(y 816~824), 흰 글씨.
숫자 모양은 에일형 PC 원본 화면(captures/stacks/*.jpg)에서 뽑음. 3 · 9는 아직 표본이 없어 읽기 거부(None).
"""
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
TPL_FILE = Path(__file__).resolve().parent / "stack_templates_1080.npz"
SLOT_CENTER = [15.5, 42.5, 69.5]
Y0, H, W, PITCH = 816, 9, 5, 6
MIN_SCORE = 0.72
# 표본: (파일, 칸, 숫자)
SAMPLES = [("nasus_058.jpg", 0, "58"), ("nasus_102.jpg", 0, "102"), ("nasus_178.jpg", 0, "178"), ("nasus_210.jpg", 0, "210"),
           ("nasus_058.jpg", 1, "14"), ("nasus_102.jpg", 1, "100"), ("nasus_178.jpg", 1, "76"), ("nasus_210.jpg", 1, "24")]


def _gray(img):
    return img.astype(np.float32).min(axis=2)   # 흰 글씨만 밝게 (보라 · 주황 아이콘 바탕은 어둡게)


def _patch(g, x, y):
    p = g[y:y + H, x:x + W]
    return p if p.shape == (H, W) else None


def _starts(slot, n, dx):
    """n자리 숫자의 각 자리 왼쪽 x (가운데 정렬 · 6px 간격 기준)."""
    x = int(round(SLOT_CENTER[slot] - n * PITCH / 2)) + dx
    return [x + k * PITCH for k in range(n)]


def _norm(p):
    p = p - p.mean()
    s = np.sqrt((p * p).sum())
    return p / s if s > 1e-6 else p * 0


def _best_local(g, x, y, ref):
    """글자 간격이 1px씩 들쭉날쭉해서(가는 '1' 등), 자리마다 좌우 ±1 · 위아래 ±1 안에서 가장 잘 맞는 곳."""
    best = None
    for ex in (-1, 0, 1):
        for ey in (-1, 0, 1):
            p = _patch(g, x + ex, y + ey)
            if p is None:
                continue
            s = float((ref * _norm(p)).sum())
            if best is None or s > best[0]:
                best = (s, p)
    return best


def build():
    """표본 화면에서 숫자별 평균 모양을 만들어 저장. 자리마다 위치를 맞춰 가며 두 번 다듬음."""
    from PIL import Image
    grays = {f: _gray(np.asarray(Image.open(ROOT / "captures" / "stacks" / f).convert("RGB"))) for f, _, _ in SAMPLES}
    acc = {}
    for f, slot, text in SAMPLES:
        for ch, x in zip(text, _starts(slot, len(text), 0)):
            p = _patch(grays[f], x, Y0)
            acc.setdefault(ch, []).append(_norm(p))
    tpl = {c: _norm(np.mean(v, axis=0)) for c, v in acc.items()}
    for _ in range(3):
        acc = {}
        for f, slot, text in SAMPLES:
            n = len(text)
            # 표본 전체 위치(dx)를 먼저 맞추고, 자리마다 ±1 다듬기
            best = None
            for dx in (-2, -1, 0, 1, 2):
                got = [_best_local(grays[f], x, Y0, tpl[ch]) for ch, x in zip(text, _starts(slot, n, dx))]
                if any(g is None for g in got):
                    continue
                sc = sum(g[0] for g in got)
                if best is None or sc > best[0]:
                    best = (sc, got)
            for ch, (s, p) in zip(text, best[1]):
                acc.setdefault(ch, []).append(_norm(p))
        tpl = {c: _norm(np.mean(v, axis=0)) for c, v in acc.items()}
    chars = sorted(tpl)
    np.savez(TPL_FILE, chars=np.array(chars), vecs=np.stack([tpl[c] for c in chars]))
    return chars


def load_templates():
    d = np.load(TPL_FILE)
    return list(d["chars"]), d["vecs"]


def _read_digit(g, x, y, vecs):
    """한 자리: ±1 범위에서 가장 잘 맞는 숫자 (점수, 숫자 번호, 글자 밝기)."""
    best = None
    for ex in (-1, 0, 1):
        for ey in (-1, 0, 1):
            p = _patch(g, x + ex, y + ey)
            if p is None:
                continue
            sc = (vecs * _norm(p)).sum(axis=(1, 2))
            i = int(sc.argmax())
            if best is None or sc[i] > best[0]:
                best = (float(sc[i]), i, float(p.max()))
    return best


def read_slot(img, slot=0, templates=None):
    """버프 칸 숫자 → int, 확실하지 않으면 None.
    자리 수(3 → 2 → 1) 순서로, '모든 숫자가 충분히 맞고 흰 글씨가 있는' 가장 긴 읽기를 고름."""
    chars, vecs = templates or load_templates()
    g = _gray(img)
    for n in (3, 2, 1):
        best = None
        for dx in (-1, 0, 1):
            got = [_read_digit(g, x, Y0, vecs) for x in _starts(slot, n, dx)]
            if any(d is None for d in got):
                continue
            scores = [d[0] for d in got]
            cand = (sum(scores) / n, min(scores), "".join(chars[d[1]] for d in got), min(d[2] for d in got))
            if best is None or cand > best:
                best = cand
        if not best:
            continue
        mean, low, txt, bright = best
        need_low, need_mean = (0.85, 0.85) if n == 1 else (0.6, 0.75)   # 한 자리는 더 엄격 (가는 '1'이 잡음과 비슷)
        if low >= need_low and mean >= need_mean and bright >= 170 and not txt.startswith("0"):
            return int(txt)
    return None


if __name__ == "__main__":
    from PIL import Image
    print("숫자 모양:", build())
    T = load_templates()
    for f, slot, text in SAMPLES:
        v = read_slot(np.asarray(Image.open(ROOT / "captures" / "stacks" / f).convert("RGB")), slot, T)
        print(f, slot, "정답", text, "→ 읽음", v)
