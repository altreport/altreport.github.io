"""포털 로스터로 선수 자동 인식: 게임 속 라이엇 ID → 리그 닉 · 팀 · 실력 점수.

포털(노챗님 Firebase, 공개 읽기)에서 두 컬렉션을 **하루 한 번만** 읽어 captures/roster.json에 저장:
  player_riot_ids  {altId: 리그 닉, riotIds: ["트 왈#KR1", ...]}
  team_rosters     {season: "S11", team, name: 리그 닉, tier: 실력 점수}
포털 읽기 한도가 빡빡하므로(공지) 서버 켤 때 파일이 12시간 넘었을 때만 새로 읽음. 콘솔에서 수동 새로고침 가능.

  python roster_sync.py 11     → 지금 바로 새로 받기
"""
import json
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

KEY = "AIzaSyBZ02ym_5CiTw_g-1qeOL8D0JlQW0VbTVI"   # 포털 HTML에 공개로 들어 있는 웹 API 키 (리그리포트와 같음)
BASE = "https://firestore.googleapis.com/v1/projects/alt-lol-league/databases/(default)/documents"
FILE = Path(__file__).resolve().parent.parent / "captures" / "roster.json"
MAX_AGE = 12 * 3600


def _val(v):
    if v is None:
        return None
    for k in ("stringValue", "booleanValue", "timestampValue"):
        if k in v:
            return v[k]
    if "integerValue" in v:
        return int(v["integerValue"])
    if "doubleValue" in v:
        return float(v["doubleValue"])
    if "arrayValue" in v:
        return [_val(x) for x in v["arrayValue"].get("values", [])]
    if "mapValue" in v:
        return {k: _val(x) for k, x in v["mapValue"].get("fields", {}).items()}
    return None


def _query(coll, where=None):
    out, cursor = [], None
    while True:
        q = {"from": [{"collectionId": coll}], "limit": 300, "orderBy": [{"field": {"fieldPath": "__name__"}}]}
        if where:
            q["where"] = where
        if cursor:
            q["startAt"] = {"values": [{"referenceValue": cursor}], "before": False}
        req = urllib.request.Request(f"{BASE}:runQuery?key={KEY}", data=json.dumps({"structuredQuery": q}).encode(),
                                     headers={"Content-Type": "application/json"})
        try:
            res = json.load(urllib.request.urlopen(req, timeout=30))
        except urllib.error.HTTPError as e:
            if e.code == 429:
                raise RuntimeError("포털 읽기 한도(429) — 오늘은 저장된 로스터를 그대로 씀")
            raise
        docs = [r["document"] for r in res if "document" in r]
        out += [{k: _val(v) for k, v in d.get("fields", {}).items()} for d in docs]
        if len(docs) < 300:
            return out
        cursor = docs[-1]["name"]


def norm_id(rid):
    """라이엇 ID 비교용: 소문자 · 띄어쓰기 없앰. 태그 없이 이름만으로도 찾을 수 있게 둘 다 씀."""
    return (rid or "").replace(" ", "").lower()


def refresh(season):
    ids = _query("player_riot_ids")
    ros = _query("team_rosters", {"fieldFilter": {"field": {"fieldPath": "season"}, "op": "EQUAL", "value": {"stringValue": f"S{season}"}}})
    team = {norm_id(r["name"]): (r.get("team"), r.get("tier")) for r in ros if r.get("name")}   # 대소문자·띄어쓰기 달라도 맞춤
    by_id, by_name = {}, {}
    for d in ids:
        alt = d.get("altId")
        if not alt:
            continue
        t, pts = team.get(norm_id(alt), (None, None))
        info = {"alt": alt, "team": t, "pts": pts}
        for rid in d.get("riotIds") or []:
            if rid:
                by_id[norm_id(rid)] = info
                by_name.setdefault(norm_id(rid.split("#")[0]), info)
    data = {"season": season, "fetched": time.strftime("%Y-%m-%d %H:%M"), "players": len(ids), "rostered": len(team),
            "byId": by_id, "byName": by_name}
    FILE.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    return data


def load(season=11, force=False):
    """저장된 로스터를 돌려줌. 없거나 12시간 넘었으면(또는 force) 포털에서 새로 받음. 실패하면 있던 걸 씀."""
    old = None
    try:
        old = json.loads(FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    fresh = old and old.get("season") == season and time.time() - FILE.stat().st_mtime < MAX_AGE
    if fresh and not force:
        return old
    try:
        return refresh(season)
    except Exception as e:
        print("로스터 새로 받기 실패:", e, flush=True)
        return old


def lookup(roster, riot_id, game_name=None):
    """게임 속 라이엇 ID(이름#태그) → {alt, team, pts} 또는 None"""
    if not roster:
        return None
    return (roster["byId"].get(norm_id(riot_id)) or
            roster["byName"].get(norm_id((riot_id or "").split("#")[0])) or
            (roster["byName"].get(norm_id(game_name)) if game_name else None))


if __name__ == "__main__":
    d = refresh(int(sys.argv[1]) if len(sys.argv) > 1 else 11)
    print(f"S{d['season']}: 라이엇 ID 등록 선수 {d['players']}명 · 이번 시즌 로스터 {d['rostered']}명 · ID {len(d['byId'])}개")
