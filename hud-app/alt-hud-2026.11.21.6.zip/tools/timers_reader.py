"""관전 클라이언트의 오브젝트 타이머 창(미니맵 위)을 읽는다 → 다음 바론/전령/용 등장까지 남은 시간.

창의 칸은 배경색이 고정돼 있어 색으로 찾는다 (1920x1080 기준, 위치는 미니맵 크기에 따라 달라질 수 있음):
  전령 (130,51,167)  바론 (80,2,114)  용 (162,107,4)  레드 버프 (124,0,13)  블루 버프 (5,66,112)
칸 = [아이콘][m:ss]. 시간이 없고 아이콘만 있으면 '등장해 있음(up)'.
숫자는 gold_reader와 같은 방식(글자 단위 대조). 견본은 전령·바론 칸에서 자동으로 만든다:
  표시값 = ceil(등장 시각 - 게임 시간)  (전령 15:00, 바론 20:00 — 실측 확인)

  python timers_reader.py build            # captures/timers-collect/ 로 견본 생성
  python timers_reader.py test             # 수집 프레임 전체로 정확도 확인
"""
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gold_reader as gr  # noqa: E402

ROOT = gr.ROOT
TEMPLATE_FILE = ROOT / "tools" / "timers_templates_1080.npz"
UNKNOWN_DIR = ROOT / "captures" / "timers-unknown"
COLLECT_DIR = ROOT / "captures" / "timers-collect"
REGION = (1640, 560, 1920, 800)          # 찾는 범위 (x1, y1, x2, y2) — 미니맵 31% 바로 위
COLLECT_ORIGIN = (1560, 540)             # timers_collect.py 가 저장한 잘린 화면의 원점
CELL_COLORS = {"herald": (130, 51, 167), "baron": (80, 2, 114), "dragon": (162, 107, 4)}
TOL = 8
ICON_W = 32                              # 칸 왼쪽 아이콘 폭 (이후가 시간 글자)
SPAWN = {"herald": 900, "baron": 1200}   # 첫 등장 시각(초) — 견본 자동 생성용
MIN_SCORE = 0.75
ICON_GLYPH_W = 15                        # 이보다 넓은 조각 = 숫자가 아니라 아이콘
MIN_GLYPH_H = 8                          # 이보다 낮은 조각은 잡티로 버림


def _color_mask(a16, rgb):
    return np.all(np.abs(a16 - np.array(rgb, dtype=np.int16)) <= TOL, axis=2)


def cell_box(region, rgb, coarse=None):
    """해당 배경색 칸의 (x1, y1, x2, y2) — region 좌표. 없거나 모양이 이상하면 None.
    속도를 위해 2칸 간격으로 대략 찾은 뒤(coarse) 그 주변만 원본 해상도로 다듬는다."""
    if coarse is None:
        coarse = region[::2, ::2].astype(np.int16)
    m = _color_mask(coarse, rgb)
    cols = np.where(m.sum(axis=0) >= 2)[0]
    rows = np.where(m.sum(axis=1) >= 5)[0]
    if len(cols) < 20 or len(rows) < 4:
        return None
    ya, yb = max(0, rows.min() * 2 - 2), rows.max() * 2 + 3
    xa, xb = max(0, cols.min() * 2 - 2), cols.max() * 2 + 3
    m = _color_mask(region[ya:yb, xa:xb].astype(np.int16), rgb)
    cols = np.where(m.sum(axis=0) >= 4)[0]
    rows = np.where(m.sum(axis=1) >= 10)[0]
    if len(cols) < 40 or len(rows) < 8:
        return None
    x1, x2, y1, y2 = xa + cols.min(), xa + cols.max() + 1, ya + rows.min(), ya + rows.max() + 1
    if not (50 <= x2 - x1 <= 130 and 8 <= y2 - y1 <= 40):
        return None
    return int(x1), int(y1), int(x2), int(y2)


def text_mask(cell, rgb, k=1.0):
    """배경보다 확실히 밝은 픽셀 = 시간 글자 (검은 외곽선·아이콘 어두운 부분 제외).
    k: 화면 밝기 배율 (관전 중인 챔피언이 죽으면 화면 전체가 약 0.5배로 어두워짐)."""
    s = cell.astype(np.float32).sum(axis=2)
    return np.clip((s - sum(rgb) - 70 * k) / (160 * k), 0, 1)


def glyphs_of(region, box, rgb, k=1.0):
    x1, y1, x2, y2 = box
    cell = region[y1:y2, x1 + ICON_W:x2]
    # 숫자 높이 15px·콜론 10px (실측). 그보다 낮은 조각은 아이콘 반짝임 등 잡티
    gl = [g for g in gr.segment(text_mask(cell, rgb, k)) if g[3] - g[2] + 1 >= MIN_GLYPH_H]
    return gl, cell


DIM_LEVELS = (1.0, 0.5)   # 평소 / 어두워진 화면(관전 챔피언 사망 등)


def find_cell(region, rgb, coarse):
    """평소 색으로 먼저 찾고, 없으면 어두워진 색(×0.5)으로 찾는다 → (box, 그때 색, 배율)."""
    for k in DIM_LEVELS:
        c = tuple(int(round(v * k)) for v in rgb)
        box = cell_box(region, c, coarse)
        if box:
            return box, c, k
    return None, rgb, 1.0


def load_templates():
    d = np.load(TEMPLATE_FILE, allow_pickle=True)
    return list(d["chars"]), d["vecs"], d["dims"]


def parse_mmss(text):
    if ":" not in text:
        return None
    m, _, s = text.partition(":")
    if not (m.isdigit() and s.isdigit() and len(s) == 2 and int(s) < 60):
        return None
    return int(m) * 60 + int(s)


LAST_BOX = None   # 마지막으로 찾은 타이머 창 칸들을 감싸는 상자 (화면 좌표) — HUD가 방송 화면에서 덮어 가림


def read_image(img, templates=None, save_unknown=False, region_origin=(REGION[0], REGION[1])):
    """img: 1920x1080 전체 화면(또는 region_origin을 준 잘린 화면).
    → {"baron": {"up": bool, "remaining": int|None} | None, "herald": ..., "dragon": ...}"""
    templates = templates or load_templates()
    if img.shape[:2] == (1080, 1920):
        rx1, ry1, rx2, ry2 = REGION
        region = img[ry1:ry2, rx1:rx2]
    else:
        region = img
    global LAST_BOX
    out, boxes = {}, []
    ox, oy = (REGION[0], REGION[1]) if img.shape[:2] == (1080, 1920) else region_origin
    coarse = region[::2, ::2].astype(np.int16)
    for name, rgb0 in CELL_COLORS.items():
        box, rgb, k = find_cell(region, rgb0, coarse)
        if box is None:
            out[name] = None
            continue
        boxes.append(box)
        gl, cell = glyphs_of(region, box, rgb, k)
        # 등장해 있으면 시간 없이 아이콘만 칸 가운데에 뜬다 → 숫자(폭 ~10px)보다 넓은 조각이 있으면 아이콘 = LIVE
        if not gl or any(e - s > ICON_GLYPH_W for s, e, *_ in gl):
            out[name] = {"up": True, "remaining": None}
            continue
        text, worst = "", 1.0
        for g in gl:
            c, s = gr.classify(g, templates)
            text += c
            worst = min(worst, s)
        sec = parse_mmss(text)
        if sec is None or worst < MIN_SCORE:
            if save_unknown and gr.may_save(("tm", name), UNKNOWN_DIR):
                UNKNOWN_DIR.mkdir(parents=True, exist_ok=True)
                Image.fromarray(cell).save(UNKNOWN_DIR / f"{int(time.time())}_{name}_{text.replace(':', '-')}.png")
            out[name] = {"up": False, "remaining": None}
        else:
            out[name] = {"up": False, "remaining": sec}
    LAST_BOX = [min(b[0] for b in boxes) + ox, min(b[1] for b in boxes) + oy, max(b[2] for b in boxes) + ox, max(b[3] for b in boxes) + oy] if boxes else None
    return out


def _labels():
    """수집 프레임 → (잘린 화면, 칸 이름, 기대 문자열). 경계(소수점 0.15~0.85 밖)는 제외."""
    for jf in sorted(COLLECT_DIR.glob("*.json")):
        gt = json.loads(jf.read_text())["gt"]
        crop = np.load(jf.with_suffix(".npy"))
        for name in ("herald", "baron"):
            rem = SPAWN[name] - gt
            if rem <= 0 or not (0.15 <= rem - math.floor(rem) <= 0.85):
                continue
            v = math.ceil(rem)
            yield crop, name, f"{v // 60}:{v % 60:02d}", jf.stem


def build():
    chars, vecs, dims, per = [], [], [], {}
    for crop, name, exp, stem in _labels():
        box = cell_box(crop, CELL_COLORS[name])
        if box is None:
            continue
        gl, _ = glyphs_of(crop, box, CELL_COLORS[name])
        if len(gl) != len(exp):
            print(f"[건너뜀] {stem} {name}: 글자 {len(gl)}개 vs '{exp}'")
            continue
        for g, ch in zip(gl, exp):
            if per.get(ch, 0) >= 10:
                continue
            v, w, h = gr.glyph_features(g)
            chars.append(ch); vecs.append(v); dims.append((w, h)); per[ch] = per.get(ch, 0) + 1
    np.savez(TEMPLATE_FILE, chars=np.array(chars), vecs=np.array(vecs), dims=np.array(dims, dtype=np.float32))
    print(f"타이머 견본 {len(chars)}개, 글자 {''.join(sorted(per))}  (부족: {''.join(c for c in '0123456789:' if c not in per) or '없음'})")


def test():
    t = load_templates()
    ok = bad = 0
    times = []
    for crop, name, exp, stem in _labels():
        t0 = time.perf_counter()
        r = read_image(crop, t)
        times.append((time.perf_counter() - t0) * 1000)
        got = r.get(name) or {}
        sec = got.get("remaining")
        want = int(exp.split(":")[0]) * 60 + int(exp.split(":")[1])
        if sec == want:
            ok += 1
        else:
            bad += 1
            print(f"[틀림] {stem} {name}: 기대 {exp}, 읽음 {sec}")
    print(f"정확도 {ok}/{ok + bad}, 1회 평균 {np.mean(times):.2f}ms 최대 {np.max(times):.2f}ms")


if __name__ == "__main__":
    {"build": build, "test": test}[sys.argv[1]]()
