"""관전 원본 상단 점수바(1920x1080)에서 오브젝트 카운터와 드래곤 종류를 읽는다.

레이아웃 (2026-11 캡처로 확인):
  블루  [A 드래곤][B 전령(눈)→20분 후 바론(뿔)][C 공허 유충][D 포탑][팀 골드] | 킬 | [골드][D][C][B][A]  레드
  점수바 아래 작은 아이콘: 팀별 드래곤 종류, 획득 순서대로 가운데에서 바깥쪽으로 쌓임.

숫자는 팀색(블루=파랑, 레드=빨강) 글자라 회색 아이콘·황토색 골드와 색으로 분리된다.
gold_reader와 같은 숫자 대조 방식. 자신 없는 값은 None (save_unknown=True면 장면 저장).

  python topbar_reader.py build      # 라벨된 캡처로 견본 생성 + 검증표 출력
  python topbar_reader.py read <캡처.png> [...]
"""
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gold_reader as gr  # noqa: E402

ROOT = gr.ROOT
TEMPLATE_FILE = ROOT / "tools" / "topbar_templates_1080.npz"
UNKNOWN_DIR = ROOT / "captures" / "topbar-unknown"
SAMPLE_DIR = Path(__file__).resolve().parent / "topbar_samples"   # 방송 중 못 읽은 칸에 정답을 붙인 견본

Y0, Y1 = 14, 38  # 숫자 줄 (아래쪽 작은 골드 툴팁 숫자 제외)
DIGIT_X = {
    "blue": {"dragons": (512, 548), "obj2": (588, 622), "grubs": (658, 692), "towers": (737, 776)},
    "red": {"towers": (1180, 1218), "grubs": (1247, 1282), "obj2": (1324, 1358), "dragons": (1402, 1437)},
}
OBJ2_ICON_X = {"blue": (566, 592), "red": (1302, 1328)}  # 전령/바론 아이콘
ICON_Y = (63, 84)                                       # 드래곤 종류 아이콘 줄
DRAGON_SLOTS = {"blue": [865, 844, 823, 802, 781], "red": [1071, 1093, 1115, 1137, 1159]}  # 첫 획득 → 바깥쪽
SLOT_HALF = 9
MIN_SCORE = 0.82
MAX_VAL = {"dragons": 9, "obj2": 5, "grubs": 6, "towers": 11}


def digit_mask(c, team):
    c = c.astype(np.float32)
    R, G, B = c[..., 0], c[..., 1], c[..., 2]
    if team == "blue":
        return np.clip((B - R - 60) / 80, 0, 1) * (B > 100)
    return np.clip((R - B - 70) / 80, 0, 1) * np.clip((R - G - 70) / 60, 0, 1)


def gray_icon(c):
    g = c.astype(np.float32).mean(axis=2)
    v = g - g.mean()
    n = np.linalg.norm(v)
    return (v / n).ravel() if n else v.ravel()


# 실측 평균색 (채도 높은 픽셀). 문턱값 대신 가장 가까운 색으로 고름 — 화면 밝기가 조금 달라도 흔들리지 않게
DRAGON_REF = {
    "ocean": (72, 166, 145),     # 바다: 초록 > 파랑
    "hextech": (107, 178, 201),  # 마법공학: 파랑 > 초록
    "infernal": (185, 105, 70),  # 화염: 주황 (실측 177,111,76)
    "mountain": (154, 128, 106), # 대지: 베이지 · 갈색 (채도 낮아 대개 밝은 픽셀 경로로 판정)
    "chemtech": (140, 200, 60),  # 화학공학: 연두
    "cloud": (190, 210, 230),    # 바람: 흰 · 연한 하늘
    "elder": (150, 110, 200),    # 장로: 보라
}
DRAGON_MAX_DIST = 70


def classify_dragon(px):
    """채도 높은 픽셀들의 평균색 → 가장 가까운 용 (너무 멀면 unknown)."""
    c = np.asarray(px, dtype=np.float32).mean(axis=0)
    best, dist = "unknown", 1e9
    for k, ref in DRAGON_REF.items():
        d = float(np.linalg.norm(c - np.asarray(ref, dtype=np.float32)))
        if d < dist:
            best, dist = k, d
    return best if dist <= DRAGON_MAX_DIST else "unknown"


def dragon_types(img, team, n=None):
    out = []
    y0, y1 = ICON_Y
    for cx in DRAGON_SLOTS[team]:
        if n is not None and len(out) >= n:
            break
        reg = img[y0:y1, cx - SLOT_HALF: cx + SLOT_HALF + 1].astype(np.int32)
        sat = reg.max(axis=2) - reg.min(axis=2)
        m = sat > 70
        if m.sum() < 12:
            # 채도 낮은 아이콘(대지 = 베이지·갈색)은 '밝은 픽셀'로 확인. 빈 칸은 어두운 남색이라 밝은 픽셀이 거의 없음
            bright = reg.mean(axis=2) > 140
            if bright.sum() >= 25:
                r_, g_, b_ = reg[bright].mean(axis=0)
                out.append("mountain" if r_ > b_ + 20 else "cloud" if b_ >= r_ else "unknown")   # 실측 대지 (180,158,146)
                continue
            break  # 빈 칸 = 더 이상 드래곤 없음
        kind = classify_dragon(reg[m])
        # 장로는 영혼(4번째 용) 다음에만 나옴 → 1~4번째 칸에서 '장로'로 읽히면 색이 가까운 바람 용 (S11 R1 생방: 바람용을 장로로 읽음)
        out.append("cloud" if kind == "elder" and len(out) < 4 else kind)
    return out


def load_templates():
    d = np.load(TEMPLATE_FILE, allow_pickle=True)
    return {"digits": (list(d["chars"]), d["vecs"], d["dims"]),
            "icons": (list(d["icon_kinds"]), d["icon_vecs"])}


def read_number(img, team, key, templates, save_unknown):
    x1, x2 = DIGIT_X[team][key]
    c = img[Y0:Y1, x1:x2]
    glyphs = gr.segment(digit_mask(c, team))
    if not glyphs:
        return None
    text, worst = "", 1.0
    for gl in glyphs:
        ch, s = gr.classify(gl, templates["digits"])
        text += ch
        worst = min(worst, s)
    ok = text.isdigit() and worst >= MIN_SCORE and int(text) <= MAX_VAL[key]
    if not ok and save_unknown and gr.may_save(("top", team, key), UNKNOWN_DIR):
        UNKNOWN_DIR.mkdir(parents=True, exist_ok=True)
        Image.fromarray(c).save(UNKNOWN_DIR / f"{int(time.time())}_{team}_{key}_{text}.png")
    return int(text) if ok else None


def obj2_kind(img, team, templates):
    x1, x2 = OBJ2_ICON_X[team]
    v = gray_icon(img[Y0:Y1, x1:x2])
    kinds, vecs = templates["icons"]
    s = vecs @ v
    i = int(np.argmax(s))
    return kinds[i] if s[i] > 0.6 else None


def read_image(img, templates=None, save_unknown=False):
    templates = templates or load_templates()
    if not isinstance(img, np.ndarray):
        img = np.asarray(Image.open(img).convert("RGB"))
    out = {}
    for team in ("blue", "red"):
        t = {k: read_number(img, team, k, templates, save_unknown) for k in ("dragons", "obj2", "grubs", "towers")}
        t["obj2_kind"] = obj2_kind(img, team, templates)
        t["dragon_types"] = dragon_types(img, team, t["dragons"])
        out[team] = t
    return out


# ── 라벨 (blue A,B,C,D / red A,B,C,D / B 아이콘 / 드래곤 종류 첫 획득부터) ──
H, BA = "herald", "baron"
LABELS = {
    "captures/set-20261118-212728/01.png": ((1, 0, 3, 0), (0, 0, 0, 0), H, ["hextech"], []),
    "captures/set-20261118-212728/02.png": ((1, 0, 3, 0), (0, 0, 0, 0), H, ["hextech"], []),
    "captures/set-20261118-212817/01.png": ((1, 0, 3, 0), (0, 0, 0, 0), H, ["hextech"], []),
    "captures/set-20261118-212817/02.png": ((1, 0, 3, 0), (0, 0, 0, 0), H, ["hextech"], []),
    "captures/set-20261118-213717/01.png": ((1, 1, 3, 5), (1, 0, 0, 0), H, ["hextech"], ["ocean"]),
    "captures/set-20261118-213717/02.png": ((1, 1, 3, 5), (1, 0, 0, 0), H, ["hextech"], ["ocean"]),
    "captures/set-20261118-213821/01.png": ((2, 0, 3, 5), (1, 0, 0, 1), BA, ["hextech", "chemtech"], ["ocean"]),
    "captures/set-20261118-213921/01.png": ((2, 0, 3, 5), (1, 0, 0, 1), BA, ["hextech", "chemtech"], ["ocean"]),
    "captures/set-20261118-215155/01.png": ((1, 0, 0, 0), (0, 0, 3, 0), H, ["hextech"], []),
    "captures/set-20261118-215315/01.png": ((1, 0, 0, 0), (0, 0, 3, 1), H, ["hextech"], []),
    "captures/set-20261118-215427/01.png": ((1, 0, 0, 0), (0, 0, 3, 1), H, ["hextech"], []),
    "captures/bounty-live.png": ((3, 1, 0, 7), (2, 0, 3, 3), BA, ["hextech", "chemtech", "chemtech"], ["ocean", "chemtech"]),
    "captures/topbar-live-full.png": ((1, 0, 0, 4), (2, 0, 3, 1), BA, ["hextech"], ["ocean", "chemtech"]),
}
KEYS = ("dragons", "obj2", "grubs", "towers")
TRAIN = ["captures/set-20261118-213717/02.png", "captures/set-20261118-213921/01.png",
         "captures/bounty-live.png", "captures/set-20261118-215427/01.png", "captures/topbar-live-full.png"]


def build():
    chars, vecs, dims, icon_kinds, icon_vecs = [], [], [], [], []
    for path in TRAIN:
        img = np.asarray(Image.open(ROOT / path).convert("RGB"))
        blue, red, kind, _, _ = LABELS[path]
        for team, vals in (("blue", blue), ("red", red)):
            for key, val in zip(KEYS, vals):
                x1, x2 = DIGIT_X[team][key]
                glyphs = gr.segment(digit_mask(img[Y0:Y1, x1:x2], team))
                if len(glyphs) != len(str(val)):
                    print(f"[경고] {path} {team} {key}: 글자 {len(glyphs)}개 vs '{val}'")
                    continue
                for gl, ch in zip(glyphs, str(val)):
                    v, w, h = gr.glyph_features(gl)
                    chars.append(ch); vecs.append(v); dims.append((w, h))
            x1, x2 = OBJ2_ICON_X[team]
            icon_kinds.append(kind); icon_vecs.append(gray_icon(img[Y0:Y1, x1:x2]))
    # 실제 방송에서 못 읽었던 칸 (topbar_samples/팀_칸_정답_시각.png, 칸만 잘린 그림) — 6 · 8 · 9 등 원래 견본에 없던 숫자
    for f in sorted(SAMPLE_DIR.glob("*.png")):
        team, key, val = f.stem.split("_")[:3]
        glyphs = gr.segment(digit_mask(np.asarray(Image.open(f).convert("RGB")), team))
        if len(glyphs) != len(val):
            print(f"[경고] {f.name}: 글자 {len(glyphs)}개 vs '{val}'")
            continue
        for gl, ch in zip(glyphs, val):
            v, w, h = gr.glyph_features(gl)
            chars.append(ch); vecs.append(v); dims.append((w, h))
    np.savez(TEMPLATE_FILE, chars=np.array(chars), vecs=np.array(vecs), dims=np.array(dims, dtype=np.float32),
             icon_kinds=np.array(icon_kinds), icon_vecs=np.array(icon_vecs))
    print(f"숫자 견본 {len(chars)}개 ({''.join(sorted(set(chars)))}), 아이콘 견본 {len(icon_kinds)}개")


def validate():
    t = load_templates()
    total = ok = 0
    print(f"{'캡처':40} {'숫자':>6} {'B종류':>6} {'용종류':>6}  ms")
    for path, (blue, red, kind, bt, rt) in LABELS.items():
        img = np.asarray(Image.open(ROOT / path).convert("RGB"))
        t0 = time.perf_counter()
        r = read_image(img, t)
        ms = (time.perf_counter() - t0) * 1000
        good = sum(r[team][k] == v for team, vals in (("blue", blue), ("red", red)) for k, v in zip(KEYS, vals))
        kgood = (r["blue"]["obj2_kind"] == kind) + (r["red"]["obj2_kind"] == kind)
        dgood = (r["blue"]["dragon_types"] == bt) + (r["red"]["dragon_types"] == rt)
        total += 12; ok += good + kgood + dgood
        mark = "" if good == 8 and kgood == 2 and dgood == 2 else f"  <- {r}"
        print(f"{path:40} {good:>4}/8 {kgood:>4}/2 {dgood:>4}/2  {ms:.1f}{mark}")
    print(f"합계 {ok}/{total}")


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "build"
    if cmd == "build":
        build(); validate()
    elif cmd == "validate":
        validate()
    else:
        t = load_templates()
        for p in sys.argv[2:]:
            print(p, read_image(p, t))
