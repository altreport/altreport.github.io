"""ALT HUD 실행기 — 중계자가 'ALT HUD 시작'을 더블클릭하면 이게 돈다.

1. 이미 켜져 있으면 중계 콘솔만 열고 끝 (두 번 켜도 안전)
2. 새 버전이 있으면 받아서 바꿔 끼움 (자동 업데이트, 실패해도 그냥 지금 버전으로 실행)
3. HUD 서버를 창 없이 켜고, 몇 초 뒤 브라우저로 중계 콘솔을 엶

업데이트: UPDATE_URL의 version.json  {"version": "2026.11.19", "zip": "https://…/alt-hud-2026.11.19.zip", "note": "바뀐 점"}
  zip 안의 tools/ hud/ docs/ 만 바꿈. captures/(라인업·기록·설정)는 절대 안 건드림.
"""
import io
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
import webbrowser
import zipfile
from pathlib import Path

APP = Path(__file__).resolve().parent.parent          # 패키지 폴더 (tools/ hud/ docs/ captures/ python/)
PORT = 8765
UPDATE_URL = "https://altreport.github.io/hud-app/version.json"   # 배포 위치 (정해지면 여기만 바꿈)
CONSOLE = f"http://127.0.0.1:{PORT}/live.html"   # 중계 화면 (미리 보기 + 버튼 줄). 설정·준비는 /control.html
REPLACE = ("tools/", "hud/", "docs/")


def running():
    try:
        urllib.request.urlopen(f"http://127.0.0.1:{PORT}/state.json", timeout=1).read()
        return True
    except Exception:
        return False


def local_version():
    try:
        return (APP / "VERSION").read_text(encoding="utf-8").strip()
    except Exception:
        return "0"


def vnum(v):
    """'2026.11.21.10' → (2026, 11, 21, 10). 숫자로 비교해야 .10 이 .9 보다 새 버전으로 잡힘."""
    import re
    return tuple(int(x) for x in re.findall(r"\d+", str(v))) or (0,)


def update():
    """새 버전이 있으면 받아서 tools/ hud/ docs/ 를 바꿔 끼움. 어떤 이유로든 실패하면 조용히 넘어감."""
    try:
        with urllib.request.urlopen(UPDATE_URL, timeout=5) as r:
            info = json.loads(r.read().decode("utf-8"))
        if vnum(info.get("version", "0")) <= vnum(local_version()):
            return None
        with urllib.request.urlopen(info["zip"], timeout=60) as r:
            data = r.read()
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for name in z.namelist():
                if not name.startswith(REPLACE) or name.endswith("/") or ".." in name:
                    continue
                out = APP / name
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_bytes(z.read(name))
        (APP / "VERSION").write_text(str(info["version"]), encoding="utf-8")
        return f"{info['version']} — {info.get('note', '')}"
    except Exception:
        return None


def pack():
    """기록 보내기: captures 폴더(경기 기록 · 로그 · 라인업)를 바탕화면에 압축 하나로. 끝나면 탐색기에서 그 파일을 보여 줌."""
    desk = Path.home() / "Desktop"
    if not desk.is_dir():
        desk = Path.home() / "OneDrive" / "Desktop" if (Path.home() / "OneDrive" / "Desktop").is_dir() else APP
    out = desk / time.strftime("ALT-HUD-기록-%Y%m%d-%H%M.zip")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f in (APP / "captures").rglob("*"):
            if f.is_file() and f.name not in ("league_feed.json", "remote-key.txt"):   # 폰 연결 키는 보내지 않음
                z.write(f, f.relative_to(APP).as_posix())
    subprocess.Popen(["explorer", "/select,", str(out)])


NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def running_info():
    try:
        return json.loads(urllib.request.urlopen(f"http://127.0.0.1:{PORT}/state.json", timeout=2).read().decode("utf-8"))
    except Exception:
        return None


def old_app_dir(info):
    """돌고 있는 HUD의 폴더. 새 버전은 스스로 알려 주고, 옛 버전은 실행 중인 프로그램 경로에서 찾음."""
    if info.get("appDir"):
        return Path(info["appDir"])
    try:
        ps = ("Get-CimInstance Win32_Process -Filter \"Name like 'python%'\" | Where-Object { $_.CommandLine -like '*hud_server.py*' } | "
              "Select-Object -First 1 -ExpandProperty CommandLine")
        out = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, encoding="mbcs", errors="replace", timeout=20, creationflags=NO_WINDOW).stdout
        import re
        m = re.search(r"([A-Za-z]:\\(?:(?![A-Za-z]:\\)[^\"])*?)\\tools\\hud_server\.py", out)   # 마지막 드라이브 경로부터
        return Path(m.group(1)) if m else None
    except Exception:
        return None


def take_over(info):
    """옛 버전 HUD를 끄고(같은 폴더가 아니면) 옛 폴더의 경기 기록 · 라인업을 새 폴더로 옮김."""
    old = old_app_dir(info)
    try:
        urllib.request.urlopen(f"http://127.0.0.1:{PORT}/api/quit", timeout=3).read()
    except Exception:
        pass
    for _ in range(40):   # 꺼질 때까지 최대 20초
        if not running():
            break
        time.sleep(0.5)
    if not old or not (old / "captures").is_dir() or old.resolve() == APP.resolve():
        return
    dst = APP / "captures"
    (dst / "logs").mkdir(parents=True, exist_ok=True)
    for f in (old / "captures" / "logs").glob("*"):
        if f.is_file() and not (dst / "logs" / f.name).exists():
            shutil.copy2(f, dst / "logs" / f.name)
    for name in ("entry-today.json", "match.json", "roster.json", "settings.json", "hud_server.log", "launcher.log"):
        f = old / "captures" / name
        if f.is_file() and not (dst / name).exists():
            shutil.copy2(f, dst / name)


SILENT = "--silent" in sys.argv   # 노챗님 프로그램 등에서 뒤로 켤 때: 콘솔 브라우저를 열지 않음


def main():
    info = running_info()
    if info is not None:
        same = info.get("hudVersion") == local_version() and str(info.get("appDir") or "") == str(APP)
        if same:   # 이미 이 버전이 켜져 있음 → 화면만
            if not SILENT:
                webbrowser.open(CONSOLE)
            return
        take_over(info)   # 다른(옛) 버전이 켜져 있음 → 끄고 기록 옮기고 새로 켬
    note = update()
    log = APP / "captures" / "launcher.log"
    log.parent.mkdir(exist_ok=True)
    with open(log, "a", encoding="utf-8") as f:
        f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + (f"업데이트됨: {note}" if note else f"버전 {local_version()}") + "\n")
    # 창 없는 파이썬(pythonw)으로 서버 실행. 출력은 captures/hud_server.log
    exe = Path(sys.executable)
    pyw = exe.with_name("pythonw.exe") if exe.with_name("pythonw.exe").exists() else exe
    slog = APP / "captures" / "hud_server.log"
    try:
        if slog.exists() and slog.stat().st_size > 5 * 1024 * 1024:   # 5MB 넘으면 새로 시작 (지난 것은 .old 하나만)
            slog.replace(slog.with_suffix(".old.log"))
    except OSError:
        pass
    out = open(slog, "a", encoding="utf-8")
    subprocess.Popen([str(pyw), "-X", "utf8", str(APP / "tools" / "hud_server.py")], cwd=str(APP), stdout=out, stderr=out,
                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    for _ in range(30):   # 서버가 뜰 때까지 최대 15초
        time.sleep(0.5)
        if running():
            break
    if not SILENT:
        webbrowser.open(CONSOLE)


if __name__ == "__main__":
    os.chdir(APP)
    if "--pack" in sys.argv:
        pack()
    elif "--restore-lol" in sys.argv:   # 롤 설정을 ALT HUD가 바꾸기 전으로 되돌림
        sys.path.insert(0, str(APP / "tools"))
        import lol_setup
        lol_setup.restore()
    else:
        main()
