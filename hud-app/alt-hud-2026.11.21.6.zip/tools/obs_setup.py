"""OBS 자동 설정 (형 11-21): 중계자 PC의 OBS에 'ALT 중계' 장면 모음을 하나 넣어 둔다.

- 중계자는 OBS 위쪽 메뉴 '장면 모음' → 'ALT 중계' 만 고르면 됨. (OBS가 켜져 있었으면 껐다 켜야 메뉴에 보임)
- 원래 쓰던 장면 모음 · 프로필 · 설정은 건드리지 않는다. 새 파일 하나만 추가.
- 이미 'ALT 중계' 파일이 있으면 그대로 둔다 (중계자가 고친 것 보존). 다시 만들려면 그 파일을 지우고 HUD를 다시 켜면 됨.
- 장면 구성 (아래 → 위):
    롤 게임            게임 캡처 · League of Legends (TM) Client 창 · 화면 크기에 맞춤
    롤 게임 (창 캡처)  게임 캡처가 까맣게 나올 때 대신 켜는 것 (기본 꺼짐)
    채팅 가림판        왼쪽 아래 290x270 검은 판 (채팅을 안 띄울 때 게임 화면이 비치지 않게)
    ALT HUD            브라우저 · http://127.0.0.1:8765/ · 1920x1080
"""
import json
import os
import uuid
from pathlib import Path

NAME = "ALT 중계"
LOL_WINDOW = "League of Legends (TM) Client:RiotWindowClass:League of Legends.exe"
HUD_URL = "http://127.0.0.1:8765/"
MAIN_CANVAS = "6c69626f-6273-4c00-9d88-c5136d61696e"   # OBS 기본 캔버스 (이 PC OBS 32 파일과 같은 값)
VERSION = 1


def scenes_dir():
    app = os.environ.get("APPDATA")
    return Path(app) / "obs-studio" / "basic" / "scenes" if app else None


def _source(sid, name, settings, **extra):
    s = {"name": name, "uuid": str(uuid.uuid4()), "id": sid, "versioned_id": sid, "settings": settings,
         "mixers": 0, "sync": 0, "flags": 0, "volume": 1.0, "balance": 0.5, "enabled": True, "muted": False,
         "push-to-mute": False, "push-to-mute-delay": 0, "push-to-talk": False, "push-to-talk-delay": 0,
         "hotkeys": {}, "deinterlace_mode": 0, "deinterlace_field_order": 0, "monitoring_type": 0, "private_settings": {}}
    s.update(extra)
    return s


def _item(src, iid, pos=(0, 0), visible=True, fit=False, locked=False):
    it = {"name": src["name"], "source_uuid": src["uuid"], "visible": visible, "locked": locked, "rot": 0.0,
          "scale_ref": {"x": 1920.0, "y": 1080.0}, "align": 5, "bounds_type": 0, "bounds_align": 0, "bounds_crop": False,
          "crop_left": 0, "crop_top": 0, "crop_right": 0, "crop_bottom": 0, "id": iid, "group_item_backup": False,
          "pos": {"x": float(pos[0]), "y": float(pos[1])}, "scale": {"x": 1.0, "y": 1.0}, "bounds": {"x": 0.0, "y": 0.0},
          "scale_filter": "disable", "blend_method": "default", "blend_type": "normal",
          "show_transition": {"duration": 0}, "hide_transition": {"duration": 0}, "private_settings": {}}
    if fit:   # 롤 창 크기가 달라도 1920x1080 화면에 꽉 맞춤
        it.update(bounds_type=2, bounds={"x": 1920.0, "y": 1080.0})
    return it


def build():
    game = _source("game_capture", "롤 게임", {"capture_mode": "window", "window": LOL_WINDOW, "priority": 2, "capture_cursor": False})
    win = _source("window_capture", "롤 게임 (창 캡처)", {"window": LOL_WINDOW, "priority": 2, "method": 2, "cursor": False})
    plate = _source("color_source_v3", "채팅 가림판", {"color": 0xFF000000, "width": 290, "height": 270})
    hud = _source("browser_source", "ALT HUD", {"url": HUD_URL, "width": 1920, "height": 1080, "reroute_audio": False,
                                               "shutdown": False, "restart_when_active": False})
    items = [_item(game, 1, fit=True), _item(win, 2, fit=True, visible=False), _item(plate, 3, pos=(0, 810)), _item(hud, 4, locked=True)]
    scene = _source("scene", NAME, {"id_counter": 4, "custom_size": False, "items": items}, canvas_uuid=MAIN_CANVAS)
    # 소리: 이게 없으면 이 장면 모음으로 방송할 때 게임 소리 · 마이크가 안 나감 (OBS 기본과 같은 '기본 장치')
    desk = _source("wasapi_output_capture", "데스크탑 오디오", {"device_id": "default"}, mixers=255)
    mic = _source("wasapi_input_capture", "마이크/Aux", {"device_id": "default"}, mixers=255)
    return {"name": NAME, "alt_hud_obs": VERSION,
            "DesktopAudioDevice1": desk, "AuxAudioDevice1": mic, "migration_resolution": {"x": 1920, "y": 1080},
            "sources": [game, win, plate, hud, scene], "groups": [],
            "scene_order": [{"name": NAME}], "current_scene": NAME, "current_program_scene": NAME,
            "canvases": [], "transitions": [], "current_transition": "", "transition_duration": 300,
            "quick_transitions": [], "saved_projectors": [], "preview_locked": False,
            "scaling_enabled": False, "scaling_level": 0, "scaling_off_x": 0.0, "scaling_off_y": 0.0,
            "modules": {}, "resolution": {"x": 1920, "y": 1080}, "version": 2}


def current():
    """OBS에서 지금 고른 장면 모음 이름 (OBS 설정 파일에서 읽음, 모르면 None). OBS가 설정을 저장한 뒤에만 바뀜."""
    app = os.environ.get("APPDATA")
    if not app:
        return None
    for ini in ("user.ini", "global.ini"):   # OBS 31+ 는 user.ini, 예전 버전은 global.ini
        f = Path(app) / "obs-studio" / ini
        try:
            sec = None
            for line in f.read_text(encoding="utf-8-sig", errors="replace").splitlines():
                line = line.strip()
                if line.startswith("[") and line.endswith("]"):
                    sec = line[1:-1]
                elif sec == "Basic" and line.startswith("SceneCollection="):
                    return line.split("=", 1)[1].strip()
        except Exception:
            continue
    return None


def install():
    """HUD 켤 때 한 번. 돌려주는 값: 'added' 새로 넣음 / 'exists' 이미 있음 / 'noobs' OBS 없음 / 'error'"""
    d = scenes_dir()
    if not d or not d.parent.parent.exists():
        return "noobs"
    try:
        d.mkdir(parents=True, exist_ok=True)
        f = d / f"{NAME}.json"
        if f.exists():
            return "exists"
        f.write_text(json.dumps(build(), ensure_ascii=False, indent=1), encoding="utf-8")
        return "added"
    except Exception:
        return "error"


if __name__ == "__main__":
    print(install())
