"""챔피언 기록: 이번 경기 챔피언 중 '이야깃거리가 있는' 챔피언만 골라 하단 패널로 띄움.
판에 나온 챔피언을 다 보여주는 게 아님 — 아래 5가지 중 하나에 걸릴 때만. 없으면 아무것도 안 띄움.

  1 혼자 살린 챔피언   다른 선수들은 대부분 졌는데(4판+, 승률 35% 이하) 이번 경기 선수만 이김(2판+, 67% 이상)
  2 저격밴 풀림        이번 경기 선수의 주력 챔프(2판+)가 그 팀 상대일 때만 유난히 밴됨(4번+, 다른 팀 상대보다 2배+)
  3 연승·연패 / 전승·전패  리그 전체에서 지금 4연속 이상, 또는 시즌 4판+ 전승·전패
  4 팀 시그니처        이번 경기 팀이 꺼내면 4판+ 전승 또는 80% 이상
  5 밴만 당하던 첫 픽   시즌 픽 0번, 밴 5번 이상

league_feed.json 의 champs (league_feed.py가 리그리포트 시즌 데이터에서 만듦)만 씀 — 계산 가벼움.
"""

MIN_SCORE = 10   # 이 점수 미만은 버림 (위 조건에 걸리면 전부 10 이상)


def _key(name):
    return (name or "").replace(" ", "")


def _rec(w, l):
    return f"{w}-{l}"


def _stories(c, p, feed, tag):
    """한 챔피언에서 나올 수 있는 이야깃거리 후보들 [(점수, 내용)]"""
    w, l, ban = c["w"], c["l"], c["ban"]
    n = w + l
    who, team = p["who"], p.get("team")
    mine = c["by"].get(who)
    out = []
    # 1. 혼자 살린 챔피언
    if mine and sum(mine) >= 2 and mine[0] / sum(mine) >= 0.67:
        ow, ol = w - mine[0], l - mine[1]
        if ow + ol >= 4 and ow / (ow + ol) <= 0.35:
            out.append((15 + sum(mine) / 2, dict(kind="carry", head="혼자 살린 챔피언", big=f"{who} {_rec(*mine)}", tone="good",
                                                 desc=f"다른 선수들은 {_rec(ow, ol)} — {who}만 이 챔피언으로 이겼어요")))
    # 2. 저격밴 풀림
    if team and mine and sum(mine) >= 2:
        bv = c["bannedVs"].get(team, 0)
        ts = (feed.get("teamSets") or {}).get(team) or 0
        all_ts = sum((feed.get("teamSets") or {}).values())
        rate_t = bv / ts if ts else 0
        rate_o = (ban - bv) / (all_ts - ts) if all_ts - ts > 0 else 0
        if bv >= 4 and rate_t >= 0.15 and rate_t >= 2 * rate_o:
            out.append((14 + bv / 4, dict(kind="snipe", head="저격밴 풀림", big=f"밴 {bv}회", tone="hot",
                                          desc=f"{team} 상대로 {bv}번 밴당하던 {who}의 {c['name']} (다른 팀 상대로는 {ban - bv}번)")))
    # 3. 연승·연패 / 전승·전패 (리그 전체)
    st = c.get("streak", 0)
    if n >= 4 and (w == 0 or l == 0):
        out.append((11 + n / 2, dict(kind="streak", head="시즌 전승" if l == 0 else "시즌 전패", big=f"ALT {_rec(w, l)}",
                                     tone="good" if l == 0 else "bad", desc=f"{tag} {n}번 나와서 {'한 번도 안 졌어요' if l == 0 else '한 번도 못 이겼어요'}")))
    elif abs(st) >= 4:
        out.append((10 + abs(st) / 2, dict(kind="streak", head=f"{abs(st)}연{'승' if st > 0 else '패'} 중", big=f"{abs(st)}연{'승' if st > 0 else '패'}",
                                           tone="good" if st > 0 else "bad", desc=f"리그 전체 최근 {abs(st)}판 {'전승' if st > 0 else '전패'} · 시즌 {_rec(w, l)}")))
    # 4. 팀 시그니처
    tr = c["team"].get(team) if team else None
    if tr and sum(tr) >= 4 and (tr[1] == 0 or tr[0] / sum(tr) >= 0.8):
        out.append((10 + tr[0] / 2, dict(kind="team", head=f"{team} 시그니처", big=f"{team} {_rec(*tr)}", tone="good",
                                         desc=f"{team} 픽일 때 {tr[0]}승 {tr[1]}패 · 리그 전체 {_rec(w, l)}")))
    # 5. 밴만 당하던 첫 픽
    if n == 0 and ban >= 5:
        out.append((12 + ban / 3, dict(kind="firstpick", head="이번이 시즌 첫 픽", big=f"밴 {ban}회", tone="hot",
                                       desc=f"{tag} 내내 한 번도 안 나왔던 챔피언")))
    return out


def build(feed, players):
    """players: [{"champ": 한글 챔피언 이름, "img": 그림 id, "who": 리그 닉, "side": blue|red, "team": 팀 이름}] 10명.
    돌려줌: 이야깃거리가 있는 챔피언만, 재밌는 순서. 한 챔피언에 여러 개 걸리면 제일 센 것 하나."""
    if not feed or not feed.get("champs"):
        return []
    champs, season = feed["champs"], feed.get("season")
    tag = f"S{season}" if season else "시즌"
    out = []
    for p in players:
        c = champs.get(_key(p["champ"]))
        if not c:
            continue
        cands = [x for x in _stories(c, p, feed, tag) if x[0] >= MIN_SCORE]
        if not cands:
            continue
        score, st = max(cands, key=lambda x: x[0])
        by = c["by"]
        mine = by.get(p["who"])
        card = {"champ": p["champ"], "img": p["img"], "side": p["side"], "who": p["who"], "tag": tag, "score": score,
                "w": c["w"], "l": c["l"], "ban": c["ban"], "nsets": feed.get("nsets"),
                "bannedVs": sorted(c.get("bannedVs", {}).items(), key=lambda kv: -kv[1])[:4],   # 어느 팀 상대일 때 밴됐나
                "mine": f"{p['who']} 본인 {_rec(*mine)}" if mine and st["kind"] != "carry" else None,
                # 오른쪽 칸: 시즌에 이 챔피언을 쓴 선수 (많이 쓴 순 6명)
                "userList": [[u, r[0], r[1]] for u, r in sorted(by.items(), key=lambda kv: (-(kv[1][0] + kv[1][1]), -kv[1][0]))[:6]],
                **st}
        out.append(card)
    out.sort(key=lambda x: -x["score"])
    return out
