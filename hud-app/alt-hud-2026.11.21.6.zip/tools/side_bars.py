"""관전 화면 양옆 선수 초상화 밑의 체력 · 자원(마나 · 기력 · 분노 등) 막대를 읽는다 (1920x1080, 인터페이스 크기 기본).

관전 데이터(API)에는 다른 선수의 체력 · 마나가 없어서 화면에서 읽는다.
  왼쪽(블루) 막대 x 31~72, 오른쪽(레드) x 1847~1888, 가로 42칸
  체력 막대 y = 208 + 103·i, 자원 막대 y = 218 + 103·i  (i = 0~4, 위에서부터 탑→서폿)
막대 칸 중 색이 진하고 밝은 칸의 비율 = 채워진 정도. 자원 종류는 채워진 칸의 평균 색으로 판단.
2026-11-20 이 PC 실제 관전 화면으로 위치 확인.
"""
import numpy as np

BAR_X = {"blue": (31, 73), "red": (1847, 1889)}
HP_Y0, RES_Y0, PITCH = 208, 218, 103


def _fill(row):
    """막대 한 줄 → (채운 비율, 채운 칸 평균색). 밝은 칸만 셈 (빈 칸은 어두움 ~20).
    흰 막대(레넥톤 분노 50 미만 등)도 세려고 채도는 안 봄."""
    row = row.astype(np.int16)
    on = row.max(axis=-1) > 110
    n = int(on.sum())
    return n / len(row), (row[on].mean(axis=0) if n else None)


def _kind(rgb):
    if rgb is None:
        return None
    r, g, b = rgb
    if b > r + 30 and b > g:
        return "mana"          # 파랑
    if r > 140 and g > 140 and b < 110:
        return "energy"        # 노랑 (기력)
    if r > g + 50 and r > b + 50:
        return "rage"          # 빨강 (분노 · 투지 · 열기 등)
    if min(r, g, b) > 150:
        return "white"         # 흰색 (레넥톤 분노 50 미만 등)
    return "other"


def read_image(img):
    """[{hp, res, kind}] × 10 (블루 0~4, 레드 0~4). 읽을 수 없으면 값이 None."""
    out = []
    h = img.shape[0]
    for team in ("blue", "red"):
        x0, x1 = BAR_X[team]
        for i in range(5):
            yh, yr = HP_Y0 + PITCH * i, RES_Y0 + PITCH * i
            if yr + 1 >= h:
                out.append({"hp": None, "res": None, "kind": None})
                continue
            # 위아래 1줄씩 같이 보고 가장 많이 찬 줄을 씀 (JPEG 번짐 · 1px 오차 대비)
            hp = max(_fill(img[y, x0:x1])[0] for y in (yh - 1, yh, yh + 1))
            res_rows = [_fill(img[y, x0:x1]) for y in (yr - 1, yr, yr + 1)]
            res, col = max(res_rows, key=lambda t: t[0])
            out.append({"hp": round(min(1.0, hp), 3), "res": round(min(1.0, res), 3), "kind": _kind(col)})
    # 10명 중 7명 이상이 체력 0 = 양옆 선수 칸이 화면에 없음 (관전 인터페이스 전환 등) → 전부 못 읽음
    if sum(1 for x in out if x["hp"] is not None and x["hp"] < 0.05) >= 7:
        return [{"hp": None, "res": None, "kind": None} for _ in out]
    return out


if __name__ == "__main__":
    import sys
    from PIL import Image
    for p in sys.argv[1:]:
        r = read_image(np.asarray(Image.open(p).convert("RGB")))
        for i, x in enumerate(r):
            print(("B" if i < 5 else "R") + str(i % 5), x)


# ── 소환사 주문 · 궁극기 쓸 수 있나 (양옆 선수 칸 아이콘) ──
# 쿨타임 중이면 아이콘에 흰 시계바늘 선이 그어지고 어두워짐. 왼쪽(블루) 기준 좌표, 레드는 좌우 반전(x → 1919 − x).
#   주문1 x 6~26 · y 157~176, 주문2 x 6~26 · y 180~199, 궁 동그라미 x 63~80 · y 155~172  (+103 · i)
# 판정이 애매하면 None (화면에서 흐리게 안 함). 2026-11-20 저장 화면 2장으로만 맞춤 — 실제 경기로 더 확인 필요.
def _icon(a, x0, x1, y0, y1):
    p = a[y0:y1, x0:x1].astype(np.int16)
    mx, mn = p.max(-1), p.min(-1)
    return float(((mn > 185) & (mx - mn < 40)).mean()), float(mx.mean())


def _ready(white, bright):
    if white >= 0.04 or bright < 75:
        return False
    if white < 0.02 and bright >= 100:
        return True
    return None


def read_cooldowns(img):
    """[{"spells": [준비?, 준비?], "ult": 준비?}] × 10. True = 쓸 수 있음, False = 쿨타임, None = 모름."""
    out = []
    for team in ("blue", "red"):
        for i in range(5):
            y = 103 * i
            fx = (lambda x0, x1: (x0, x1)) if team == "blue" else (lambda x0, x1: (1919 - x1, 1919 - x0))
            try:
                s1 = _ready(*_icon(img, *fx(6, 26), 157 + y, 176 + y))
                s2 = _ready(*_icon(img, *fx(6, 26), 180 + y, 199 + y))
                ul = _ready(*_icon(img, *fx(63, 80), 155 + y, 172 + y))
            except Exception:
                s1 = s2 = ul = None
            out.append({"spells": [s1, s2], "ult": ul})
    return out

