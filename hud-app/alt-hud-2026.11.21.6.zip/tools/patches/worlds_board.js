// 하단 선수표 월즈 배치: 같은 이름의 함수를 덮어써서 #rows에 .wl
const spellKey = s => s.startsWith("SummonerSmite") ? "SummonerSmite" : s.replace(/Upgrade$/, "");   // 강타 강화 · 순간이동 강화 → 기본 그림
function sideHtml(p, team, share, bf) {
  if (!RUNE_ICON) loadRuneIcons();
  document.getElementById("rows").classList.add("wl");
  const bySlot = {}; (p.items || []).forEach(i => bySlot[i.slot] = i);
  const im = (it, cls = "") => it ? `<img${cls ? ` class="${cls}"` : ""} src="${DD}/${ver}/img/item/${it.id}.png" onerror="this.style.visibility='hidden'">` : `<span${cls ? ` class="${cls}"` : ""}></span>`;
  const extra = Object.keys(bySlot).map(Number).filter(n => n > 6).sort((x, y) => x - y);
  const items = `<div class="items">${[0, 1, 2, 3, 4, 5].map(s => im(bySlot[s])).join("")}</div>`;
  const icol = `<div class="icol">${im(bySlot[6], "trk")}${extra.length ? im(bySlot[extra[0]], "qst") : "<span></span>"}</div>`;
  const vis = p.ward != null ? `<i class="vis">${p.ward}</i>` : "";
  const sp = `<div class="sp">${(p.spells || []).slice(0, 2).map(s => s ? `<img src="${DD}/${ver}/img/spell/${spellKey(s)}.png" onerror="this.style.visibility='hidden'">` : "<span></span>").join("")}</div>`;
  const champ = `<div class="champ ${p.dead ? "dead" : ""} ${bf ? "bf-" + bf : ""}"><img src="${DD}/${ver}/img/champion/${p.champion}.png" onerror="this.style.visibility='hidden'"><span class="lv">${p.level}</span><span class="rs">${p.dead ? p.respawn : ""}</span>${p.bounty && !p.dead ? `<span class="bty">${p.bounty}<small>G</small></span>` : ""}</div>`;
  const kid = p.runes && p.runes.key && p.runes.key.id, ks = RUNE_ICON && RUNE_ICON[kid] ? `<img class="ks" src="${DD}/img/${RUNE_ICON[kid]}" alt="">` : `<span class="ks"></span>`;
  const pts = p.pts != null ? `<span class="pts">${p.pts}</span>` : "";
  const who = `<div class="who"><div class="l1">${pts}<div class="nm">${p.display || p.name || p.championName || ""}</div></div><span class="bar"><i style="width:${Math.round(share * 100)}%"></i></span></div>`;
  const ck = `<div class="ck"><span class="kda">${p.k}<i>/</i>${p.d}<i>/</i>${p.a}</span><span class="cs">${p.cs ?? p.cs_api}<i>CS</i></span></div>`;
  return `<div class="side ${team}"><div class="itile">${vis}${items}${icol}</div><div class="ctile">${sp}${champ}${ks}${who}${ck}</div></div>`;
}
// 이름 크기: 월즈처럼 20에서 시작 (길면 줄여서 맞춤)
function fitNames() {
  document.querySelectorAll("#rows .who .nm").forEach(el => {
    let fs = 20; el.style.fontSize = fs + "px";
    while (el.scrollWidth > el.clientWidth && fs > 13) { fs -= 0.5; el.style.fontSize = fs + "px"; }
  });
}
