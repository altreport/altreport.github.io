"""경기 기록 자동 보내기 (형 11-21, 중계진과 얘기됨): 경기가 끝나 결과 파일까지 받으면 그 경기 기록을 리그 기록 보관함으로 보냄.

- 보내는 곳: 수파베이스 저장소(버킷) — HUD에는 '넣기만 되는' 공개 열쇠(anon)만 들어 있음. 읽기는 관리자 열쇠가 있는 쪽만.
- 보내는 것: captures/logs 의 경기 기록(.jsonl) · 결과(.match.json) · 분 단위 기록(.timeline.json), 그날 라인업(entry-today.json) · 포털 로스터(roster.json).
  폰 연결 키(remote-key.txt) · 설정(settings.json) · 롤 접속 정보는 절대 안 보냄.
- 언제: 1분마다 확인. 결과 파일이 생긴 경기(= 끝난 경기)만. 결과를 못 받은 경기는 2시간 지나면 기록만 보냄.
- 실패하면 다음에 다시 (인터넷 끊김 · 서버 문제). 이미 보낸 건 captures/upload_state.json 에 적어 두고 다시 안 보냄.
- 설정(URL · 열쇠)이 비어 있으면 아무것도 안 함 → 점검표에 '설정 안 됨'.
- 중계자가 알 수 있게 점검표 · 콘솔에 상태가 항상 보임 (몰래 보내지 않음).
"""
import hashlib
import json
import platform
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

# ── 기록 보관함 (수파베이스) — 형이 프로젝트를 만들면 여기 채움. 비어 있으면 꺼짐 ──
SUPABASE_URL = "https://awhzwqfjxchnrqlpxpxr.supabase.co"   # ALT 기록 보관함 (형 계정 · 서울)
SUPABASE_ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF3aHp3cWZqeGNobnJxbHB4cHhyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTUzNDg5NjcsImV4cCI6MjExMDkyNDk2N30.MBaN-Y4cJQYt7I4gAnEGDzicpZ0Tj4qKsyt2U6AOHLw"
# ↑ 공개(anon) 열쇠: 저장소 규칙으로 '올리기 · 읽기'만 됨. 덮어쓰기 · 지우기는 막힘 (형 11-23 확인)
BUCKET = "hud-logs"

ROOT = Path(__file__).resolve().parent.parent
CAP = ROOT / "captures"
STATE_FILE = CAP / "upload_state.json"
STATUS = {"state": None, "msg": None, "last": None, "sent": 0, "fail": 0}
NEVER = {"remote-key.txt", "settings.json"}
_PC = hashlib.sha1(platform.node().encode("utf-8", "replace")).hexdigest()[:8]   # PC 구분용 (컴퓨터 이름은 안 보냄)


def enabled():
    # captures/no-upload.txt 가 있으면 끔 (관리자 PC의 시험 기록이 리그 기록에 섞이지 않게 — 배포 패키지엔 안 들어감)
    return bool(SUPABASE_URL and SUPABASE_ANON) and not (CAP / "no-upload.txt").exists()


def _load():
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"sent": {}}


def _save(st):
    try:
        STATE_FILE.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def _put(remote, data, upsert=False):
    req = urllib.request.Request(f"{SUPABASE_URL}/storage/v1/object/{BUCKET}/{urllib.parse.quote(remote)}", data=data, method="POST",
                                 headers={"apikey": SUPABASE_ANON, "Authorization": f"Bearer {SUPABASE_ANON}",
                                          "Content-Type": "application/octet-stream", "x-upsert": "true" if upsert else "false"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.status in (200, 201)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")
        if e.code in (400, 409) and ("Duplicate" in body or "already exists" in body):
            return True   # 이미 올라가 있음
        raise


def _groups():
    """끝난 경기 묶음: {stem: [파일들]} — 결과 파일이 있거나, 2시간 넘게 안 바뀐 기록."""
    logs = CAP / "logs"
    out = {}
    if not logs.is_dir():
        return out
    for f in logs.glob("*.jsonl"):
        stem = f.name[:-len(".jsonl")]
        match = logs / f"{stem}.match.json"
        old = time.time() - f.stat().st_mtime > 7200
        if not (match.exists() or old) or "__vs_" in stem:
            continue
        files = [f] + [p for p in (match, logs / f"{stem}.timeline.json") if p.exists()]
        out[stem] = files
    return out


def run_once():
    if not enabled():
        STATUS.update(state="off", msg="이 PC는 꺼 둠 (no-upload.txt) — 경기가 끝나면 '기록 보내기'로 보내 주세요" if (CAP / "no-upload.txt").exists()
                      else "아직 설정 안 됨 — 경기가 끝나면 '기록 보내기'로 보내 주세요")
        return
    st = _load()
    sent = st.setdefault("sent", {})
    n_ok = n_fail = 0
    days = set()   # 이번에 보낸 경기의 날짜 폴더 (라인업 · 로스터도 같은 폴더에)
    for stem, files in _groups().items():
        for f in files:
            key = f"{f.name}:{f.stat().st_size}"
            if sent.get(f.name) == key or f.name in NEVER:
                continue
            try:
                if _put(f"{stem[:8]}/{_PC}/{f.name}", f.read_bytes()):
                    sent[f.name] = key
                    n_ok += 1
                    days.add(stem[:8])
            except Exception:
                n_fail += 1
    entry = CAP / "entry-today.json"   # 그날 라인업 (라운드 · 팀 · 세트 등급) — 결과를 리그 세트에 맞출 때 씀
    # 그날 라인업 · 포털 로스터(라이엇 ID → 리그 닉 · 팀): 리포트가 결과를 리그 세트에 맞출 때 씀. 덮어쓰기가 막혀 있어 내용별 이름으로
    for src, nm in ((entry, "entry"), (CAP / "roster.json", "roster")):
        for d in sorted(days):
            if not src.exists():
                continue
            try:
                b = src.read_bytes()
                _put(f"{d}/{_PC}/{nm}-{hashlib.sha1(b).hexdigest()[:8]}.json", b)
            except Exception:
                n_fail += 1
    _save(st)
    if n_ok:
        STATUS.update(last=time.strftime("%H:%M"), sent=STATUS["sent"] + n_ok)
    STATUS["fail"] = n_fail
    STATUS.update(state="warn" if n_fail else "ok",
                  msg=(f"켜짐 · 마지막 보낸 시각 {STATUS['last']}" if STATUS["last"] else "켜짐 · 경기가 끝나면 저절로 보냄")
                  + (f" · 못 보낸 파일 {n_fail}개 (다음에 다시)" if n_fail else ""))


def loop():
    while True:
        try:
            run_once()
        except Exception as e:
            STATUS.update(state="warn", msg=f"자동 보내기 잠깐 실패 ({type(e).__name__}) — 다음에 다시")
        time.sleep(60)


def start():
    threading.Thread(target=loop, daemon=True).start()


if __name__ == "__main__":
    run_once()
    print(STATUS)
