"""하단 HUD 시제품용 로컬 수집 서버.

매초: 관전 창 캡처 -> 골드 읽기(gold_reader) + Live Client API -> 하나의 상태(JSON)로 합침.

  http://127.0.0.1:8765/            HUD 화면 (OBS 브라우저 소스용, 배경 투명)
  http://127.0.0.1:8765/?bg=1       확인용: 최신 게임 화면 위에 HUD를 겹쳐 보여줌
  http://127.0.0.1:8765/state.json  현재 상태
  http://127.0.0.1:8765/frame.jpg   최신 게임 화면

실행: python hud_server.py
"""
import ctypes
import io
import os
import json
import ssl
import sys
import threading
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gold_reader as gr  # noqa: E402
import cs_reader as csr  # noqa: E402
import bounty_reader as brd  # noqa: E402
import game_logic as gl  # noqa: E402
import entry_parser as ep  # noqa: E402
import champ_facts as cfx  # noqa: E402
import roster_sync as rsync  # noqa: E402
ROSTER = None   # 포털 로스터 (라이엇 ID → 리그 닉 · 점수). 서버 켤 때 하루 한 번만 받음

# 당일 엔트리 (카톡 공지 붙여넣기) → 세트 선택 시 하단 HUD에 리그 닉네임 표시
ENTRY = {"parsed": None, "set": None, "swap": False}
ENTRY_FILE = Path(__file__).resolve().parent.parent / "captures" / "entry-today.json"   # 서버를 다시 켜도 유지
try:
    ENTRY.update(json.loads(ENTRY_FILE.read_text(encoding="utf-8")))
    if ENTRY.get("raw"):   # 원문이 있으면 최신 해석기로 다시 읽음 (해석기 개선이 바로 반영되게)
        ENTRY["parsed"] = ep.parse(ENTRY["raw"])
    for _k, _ps in (ENTRY.get("edits") or {}).items():   # 콘솔에서 수기로 바꾼 명단은 다시 덮어씀
        _i, _team = _k.split("|", 1)
        for _t in ENTRY["parsed"]["sets"][int(_i)]["teams"]:
            if _t["name"] == _team:
                _t["players"] = _ps
except Exception:
    pass


def match_text(lu):
    """경기 정보 배너 3줄: 날짜(작게) "11.7" / 큰 줄 "S10 R10" / 세트 줄 "3SET - 중간계(150)" (공지 글에서 자동)."""
    import re
    p = ENTRY.get("parsed") or {}
    main = " ".join(x for x in (f"S{p['season']}" if p.get("season") else "", p.get("label") or "") if x) or "ALT"
    st = (lu.get("stage") or "").strip()
    m = re.match(r"(천상|지상|중간|지하)\s*계?\s*[\(（]?\s*(\d+)?", st)
    grade = (f"{m.group(1)}계" + (f"({m.group(2)})" if m.group(2) else "")) if m else st
    sub = f"{lu['set']}SET" + (f" - {grade}" if grade else "")
    d = re.match(r"(\d+)월\s*(\d+)일", p.get("date") or "")
    date = f"{int(d.group(1))}.{int(d.group(2))}" if d else ""
    return main, sub, date


def majority_team(vs):
    from collections import Counter
    c = Counter(p.get("draftTeam") for p in vs if p.get("draftTeam"))
    return c.most_common(1)[0][0] if c and c.most_common(1)[0][1] >= 3 else None


def auto_pick_set(sig, blue_v, red_v):
    """새 경기가 시작되면 포털로 알아본 선수 이름과 라인업 세트별 명단을 맞춰서 세트·블루/레드를 자동 선택.
    경기당 한 번만 (중계자가 콘솔에서 바꾸면 그대로 둠). 10명 중 6명 이상 맞아야 선택."""
    p = ENTRY.get("parsed")
    if not p or ENTRY.get("autoFor") == sig or ENTRY.get("fromMatch"):
        return
    ENTRY["autoFor"] = sig
    low = lambda n: (n or "").replace(" ", "").lower()
    bnames = {low(x["portal"]) for x in blue_v if x.get("portal")}
    rnames = {low(x["portal"]) for x in red_v if x.get("portal")}
    if len(bnames) + len(rnames) < 6:
        return
    best = None
    for i, st in enumerate(p["sets"]):
        if len(st["teams"]) != 2:
            continue
        a, b = ({low(x["name"]) for x in t["players"]} for t in st["teams"])
        for sc, blue_team in ((len(bnames & a) + len(rnames & b), 0), (len(bnames & b) + len(rnames & a), 1)):
            if not best or sc > best[0]:
                best = (sc, i, blue_team)
    if not best or best[0] < 6:
        return
    _, i, blue_team = best
    ENTRY["set"] = i
    ENTRY["swap"] = False
    lu = active_lineup()
    if lu and lu["blue"]["name"] != p["sets"][i]["teams"][blue_team]["name"]:
        ENTRY["swap"] = True   # 공지의 홈/진영과 실제 진영이 다르면 뒤집음
        lu = active_lineup()
    if lu:
        ui["match"], ui["matchSub"], ui["matchDate"] = match_text(lu)
    save_entry()
    print(f"라인업 자동 선택: {p['sets'][i]['no']}세트 (명단 {best[0]}/10명 일치)", flush=True)


def series_bo():
    """3 또는 5. 콘솔에서 고른 값이 우선, 없으면 엔트리 글에 PO/결승이 있으면 5판."""
    if ENTRY.get("bo") in (3, 5):
        return ENTRY["bo"]
    import re
    return 5 if re.search(r"결승|플레이오프|playoff|final|\bPO\b|5판|bo5", ENTRY.get("raw") or "", re.I) else 3


def save_entry():
    try:
        ENTRY_FILE.write_text(json.dumps(ENTRY, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def active_lineup():
    p = ENTRY["parsed"]
    if not p or ENTRY["set"] is None or ENTRY["set"] >= len(p["sets"]):
        return None
    return ep.lineup(p, ENTRY["set"], ENTRY["swap"])


def entry_view():
    p = ENTRY["parsed"]
    if not p:
        return None
    lu = active_lineup()
    teams = p["teams"] or sorted({t["name"] for s in p["sets"] for t in s["teams"]})
    return {"round": p["round"], "season": p["season"], "teams": teams, "warnings": p["warnings"],
            "sets": [{"no": s["no"], "stage": s["stage"]} for s in p["sets"]],
            "active": ENTRY["set"], "swap": ENTRY["swap"], "lineup": lu,
            # 세트 승수 (팀 이름 기준 — 세트마다 진영이 바뀌어도 그대로). 노챗님 컨트롤러 연동 전까지 리모콘에서 입력
            "wins": ENTRY.get("wins") or {}, "nsets": len(p["sets"]),
            # 시리즈 방식: 정규 시즌 3판 2선(막대 2개), PO·결승 5판 3선(막대 3개)
            "bo": series_bo(), "need": series_bo() // 2 + 1}
MATCH_IN = {"t": None, "src": None, "mtime": 0, "err": None}   # 노챗님 프로그램에서 받은 경기 정보 (마지막으로 받은 때)


def apply_match(d, src="api"):
    """노챗님 프로그램이 세트 시작 전에 한 번 보내는 경기 정보를 라인업 · 세트 · 진영 · 스코어로 반영.
    규격: docs/노챗님-연동-규격.md  (POST /api/match 또는 captures/match.json 파일)"""
    import re
    def num(v):
        m = re.search(r"\d+", str(v if v is not None else ""))
        return int(m.group()) if m else None
    def side(k):
        t = d.get(k) or {}
        ps = [{"name": str(q.get("alt") or q.get("riotId") or "").strip(), "pts": num(q.get("level")), "note": None,
               "riotId": str(q.get("riotId") or "").strip()} for q in (t.get("players") or [])]
        return {"name": str(t.get("team") or "").strip() or k.upper(), "players": [p for p in ps if p["name"]]}
    blue, red = side("blue"), side("red")
    if not blue["players"] and not red["players"]:
        raise ValueError("blue/red players가 비어 있어요")
    rnd, md = str(d.get("round") or "").strip(), re.match(r"\s*(\d+)\s*[./-]\s*(\d+)", str(d.get("date") or ""))
    ENTRY["parsed"] = {"season": num(d.get("season")), "round": num(rnd), "label": (f"R{rnd}" if rnd.isdigit() else rnd),
                       "date": f"{int(md.group(1))}월 {int(md.group(2))}일" if md else "",
                       "teams": [blue["name"], red["name"]], "home_side": "blue", "warnings": [],
                       "sets": [{"no": num(d.get("set")) or 1, "stage": str(d.get("stage") or "").strip(), "home_side": "blue", "teams": [blue, red]}]}
    ENTRY.update(set=0, swap=False, raw="(노챗님 프로그램에서 받음)", fromMatch=True)
    ENTRY.pop("edits", None)
    if num(d.get("bo")) in (3, 5):
        ENTRY["bo"] = num(d.get("bo"))
    if isinstance(d.get("wins"), dict):
        ENTRY["wins"] = {str(k): num(v) or 0 for k, v in d["wins"].items()}
    lu = active_lineup()
    if lu:
        ui["match"], ui["matchSub"], ui["matchDate"] = match_text(lu)
    save_entry()
    MATCH_IN.update(t=time.strftime("%H:%M:%S"), src=src, err=None)
    return entry_view()


def poll_match_file():
    """captures/match.json 이 바뀌면 다시 읽음 (주소로 보내기 어려우면 파일로 남겨도 됨)."""
    f = ROOT / "captures" / "match.json"
    try:
        mt = f.stat().st_mtime
    except OSError:
        return
    if mt != MATCH_IN["mtime"]:
        MATCH_IN["mtime"] = mt
        try:
            apply_match(json.loads(f.read_text(encoding="utf-8-sig")), "파일")
        except Exception as e:
            MATCH_IN["err"] = f"match.json 못 읽음: {e}"


from live_gold import find_game_window, grab  # noqa: E402
try:  # 롤 관전 설정 자동 맞춤 (리플레이 기능 · 관전 미니맵 31 · 자동 카메라)
    import lol_setup  # noqa: E402
except Exception:
    lol_setup = None
LOL_SETUP = {"status": None, "changed": []}
try:  # OBS 'ALT 중계' 장면 모음 자동 추가 (형 11-21)
    import obs_setup  # noqa: E402
except Exception:
    obs_setup = None
OBS_SETUP = {"status": None}


KEEP_GAMES = 10   # 매초 원본 기록은 최근 10경기만 (경기당 1~2MB → 15MB 안팎). 경기 요약이 생기면 3으로 줄임


def tidy_captures():
    """최근 KEEP_GAMES 경기의 원본 기록만 남기고 나머지는 지움 (켤 때 · 새 경기 시작 때)."""
    try:
        logs = sorted((ROOT / "captures" / "logs").glob("*.jsonl"), key=lambda f: f.stat().st_mtime, reverse=True)
        for f in logs[KEEP_GAMES:]:
            f.unlink()
    except Exception:
        pass


def lol_setup_loop():
    """켤 때 한 번 맞추고, 관전 중이라 못 맞췄으면 1분마다 다시 (이미 맞으면 10분마다 확인만)."""
    while lol_setup:
        try:
            r = lol_setup.apply()
            if r["status"] == "changed" or LOL_SETUP["status"] != "changed":
                LOL_SETUP.update(r)
        except Exception:
            r = {"status": "later"}
        time.sleep(60 if r["status"] == "later" else 600)


try:  # 양옆 초상화 밑 체력 · 자원(마나 · 기력) 막대 읽기 — 없으면 하단표 막대만 빠짐
    import side_bars  # noqa: E402
except Exception:
    side_bars = None
try:  # 경기 끝나면 롤 클라이언트에서 결과 · 타임라인 받아 저장 (시험 기능, 실패해도 조용히)
    import postgame  # noqa: E402
except Exception:
    postgame = None
try:  # 경기 기록 자동 보내기 (형 11-23, 중계진과 얘기됨): 끝난 경기 기록을 리그 기록 보관함으로. 상태는 점검표에 늘 보임
    import log_upload  # noqa: E402
except Exception:
    log_upload = None
PG_T = {"last": 0}
try:  # 상단바(용·전령/바론·유충·포탑) 읽기 — 없으면 상단 오브젝트 정보만 빠짐
    import topbar_reader as tbr  # noqa: E402
except Exception:
    tbr = None
TOPBAR_T = None
try:  # 오브젝트 타이머 창(미니맵 위) 읽기 — 다음 바론/전령/용 등장까지 남은 시간. 없으면 타이머만 빠짐
    import timers_reader as tmr  # noqa: E402
except Exception:
    tmr = None
TIMERS_T = None
game = None   # 현재 경기 (gl.Game)


# ── 먹은 용 종류 안정화 ──
# 상단바 용 아이콘은 색으로 종류를 읽는데, 반짝임·배경 때문에 가끔 다른 색으로 읽힘.
# 한 번 먹은 용의 종류는 절대 안 바뀌므로 칸별로 투표해서 8번 이상 같은 값이면 고정.
from collections import Counter
DRG_LOCK_VOTES = 8
drg_mem = {"key": None, "t": 0, "blue": [], "red": []}   # 팀별 [{"votes": Counter, "lock": 종류|None}]


def soul_of(types):
    if len(types) < 4:
        return None
    for d in (types[3], types[2]):
        if d not in ("unknown", "elder"):
            return d
    return "unknown"


def stable_dragons(team, count, types, gt, key):
    if drg_mem["key"] != key or gt < drg_mem["t"] - 5:   # 다른 경기 / 되감기 → 처음부터
        drg_mem.update({"key": key, "blue": [], "red": []})
    drg_mem["t"] = gt
    slots = drg_mem[team]
    for i, d in enumerate(types or []):
        while len(slots) <= i:
            slots.append({"votes": Counter(), "lock": None})
        sl = slots[i]
        if sl["lock"] is None and d != "unknown":
            sl["votes"][d] += 1
            best, n = sl["votes"].most_common(1)[0]
            if n >= DRG_LOCK_VOTES:
                sl["lock"] = best
    n = count if count is not None else len(types or [])
    out = []
    for i in range(n):
        sl = slots[i] if i < len(slots) else None
        if sl and sl["lock"]:
            out.append(sl["lock"])
        elif sl and sl["votes"]:
            out.append(sl["votes"].most_common(1)[0][0])
        else:
            out.append("unknown")
    return out

PORT = 8765

# ── 폰으로 조작 (같은 와이파이) ──
# 게임을 전체화면으로 보면서 중계하면 PC에서 콘솔을 누를 수 없음 → 폰 브라우저로 콘솔을 염.
# 이 PC 밖(폰)에서 오는 요청은 연결 키가 있어야만 받음. 키는 QR 주소에 들어 있고, 한 번 들어오면 쿠키로 기억.
# OBS의 HUD(127.0.0.1)는 키 없이 그대로.
def _remote_key():
    f = Path(__file__).resolve().parent.parent / "captures" / "remote-key.txt"
    try:
        k = f.read_text(encoding="utf-8").strip()
        if len(k) >= 6:
            return k
    except Exception:
        pass
    import secrets
    k = secrets.token_urlsafe(6)
    try:
        f.write_text(k, encoding="utf-8")
    except Exception:
        pass
    return k


REMOTE_KEY = _remote_key()
SETTINGS_FILE = Path(__file__).resolve().parent.parent / "captures" / "settings.json"
LAN_ON = False   # 폰 연결: 켤 때만 공유기 쪽 주소로도 열림 (안 켜면 이 PC 안에서만 → 방화벽 창도 안 뜸)


def load_settings():
    try:
        return json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_settings(**kv):
    st = load_settings()
    st.update(kv)
    try:
        SETTINGS_FILE.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def start_lan():
    """폰 연결 켜기: 공유기 안 주소(예: 192.168.x.x:8765)로도 접속 받기 시작. 연결 키는 그대로 필요."""
    global LAN_ON
    if LAN_ON:
        return True
    ip = lan_ip()
    if not ip or not private_ip(ip):   # 공인 IP(PC방 등 인터넷에 바로 연결된 PC)면 열지 않음 — 인터넷 쪽에 HUD가 열리지 않게
        return False
    try:
        srv = ThreadingHTTPServer((ip, PORT), Handler)
    except OSError as e:
        print("폰 연결 열기 실패:", e, flush=True)
        return False
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    LAN_ON = True
    print(f"폰 연결 켜짐: http://{ip}:{PORT}", flush=True)
    return True


def private_ip(ip):
    """공유기 안 주소인지 (192.168.x · 10.x · 172.16~31.x)."""
    import ipaddress
    try:
        return ipaddress.ip_address(ip).is_private
    except ValueError:
        return False


def lan_ip():
    """이 PC의 공유기 안 주소 (폰이 접속할 주소). 실제로 패킷을 보내지는 않음."""
    import socket
    try:
        so = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        so.connect(("10.255.255.255", 1))
        ip = so.getsockname()[0]
        so.close()
        return ip
    except Exception:
        return None
ROOT = gr.ROOT
HUD_DIR = ROOT / "hud"
API = "https://127.0.0.1:2999/liveclientdata/allgamedata"
_ssl = ssl.create_default_context()
_ssl.check_hostname = False
_ssl.verify_mode = ssl.CERT_NONE

state = {"ok": False, "message": "시작 중"}
# ── 챔피언 기록 카드 (리그 시즌 픽 기록 → 리그 배너 자리에 잠깐) ──
CHAMP_SEC = 12          # 한 번 띄우면 보이는 시간(초)
CHAMP_AUTO_AT = (60, 150)   # 게임 초반 자동으로 띄우는 시점(게임 시간 초): 1:00, 2:30
CHAMP_AUTO_MIN = 10     # 이야깃거리 5가지(혼자 살린·저격밴 풀림·연승연패·팀 시그니처·밴만 당하던 첫 픽)는 전부 10 이상
champ = {"key": None, "facts": [], "idx": 0, "show": None, "until": 0, "auto_done": set()}
league_show = {"until": 0, "n": 0, "page": None}   # '리그 정보' 버튼 그래픽 (15초, 누를 때마다 다음 선수 스탯)
LEAGUE_SEC = 15
_feed = {"mtime": None, "data": None}


FEED_BASE = "https://altreport.github.io/hud/"   # 월요일 자동화가 올리는 공개 위치 (리그 데이터 · 누락 점검)


def fetch_feed():
    """서버 켤 때 한 번: 공개 사이트의 최신 리그 데이터를 받아서 더 새로우면 바꿔 끼움. 실패하면 있던 파일 그대로."""
    cap = Path(__file__).resolve().parent.parent / "captures"
    for name, local in (("league_feed.json", cap / "league_feed.json"), ("check.json", cap / "check.json")):
        try:
            with urllib.request.urlopen(FEED_BASE + name, timeout=8) as r:
                new = json.loads(r.read().decode("utf-8"))
            old = json.loads(local.read_text(encoding="utf-8")) if local.exists() else {}
            newer = (new.get("season") or 0, str(new.get("built") or new.get("today") or "")) >= (old.get("season") or 0, str(old.get("built") or old.get("today") or ""))
            if newer:
                local.write_text(json.dumps(new, ensure_ascii=False), encoding="utf-8")
                print(f"{name}: 공개 사이트 최신본으로 갱신", flush=True)
        except Exception as e:
            print(f"{name}: 새로 받지 못함 ({type(e).__name__}) — 있던 파일 사용", flush=True)


def league_feed():
    f = Path(__file__).resolve().parent.parent / "captures" / "league_feed.json"
    try:
        m = f.stat().st_mtime
        if m != _feed["mtime"]:
            _feed.update(mtime=m, data=json.loads(f.read_text(encoding="utf-8")))
    except Exception:
        pass
    return _feed["data"]


def update_champ_facts(sig, blue_v, red_v, gt):
    """이번 경기 카드 목록을 (경기·명단이 바뀔 때만) 다시 고르고, 초반 자동 표시 시점이면 띄움."""
    feed = league_feed()
    vs = [(p, "blue") for p in blue_v] + [(p, "red") for p in red_v]
    lu = active_lineup() or {}
    tname = {side: (lu.get(side) or {}).get("name") for side in ("blue", "red")}
    key = (sig, _feed["mtime"], tuple(p.get("display") or p["name"] for p, _ in vs))
    if key != champ["key"]:
        same_game = champ["key"] is not None and champ["key"][0] == sig
        champ.update(key=key, idx=0 if not same_game else champ["idx"],
                     facts=cfx.build(feed, [{"champ": p["championName"], "img": p["champion"], "side": side,
                                             "who": p.get("display") or p["name"], "team": tname[side]} for p, side in vs]))
        if not same_game:
            champ["auto_done"] = set()
    # 리그 데이터가 지난 시즌 것(S10 데이터로 S11 경기)이면 챔피언 기록을 저절로 띄우지 않음 — 버튼으로 누를 때만
    if ui.get("champAuto", False) and not prev_blocked() and gt is not None:
        for n, at in enumerate(CHAMP_AUTO_AT):
            if at <= gt < at + 40 and n not in champ["auto_done"]:
                champ["auto_done"].add(n)
                if n < len(champ["facts"]) and champ["facts"][n]["score"] >= CHAMP_AUTO_MIN and time.time() > champ["until"]:
                    show_champ(n)


def feed_old():
    """리그 데이터가 지난 시즌 것인지 (S11 드래프트는 있는데 경기 기록은 S10 → 시즌 초). 이때 챔피언 기록은 안 씀."""
    feed = league_feed() or {}
    return (feed.get("season") or 0) < ((feed.get("draft") or {}).get("season") or 0)


def prev_blocked():
    """지난 시즌 기록은 새 시즌 첫 라운드(R1) 동안만 '지난 시즌 기준'으로 보여 주고, R2부터는 숨김 (라운드는 라인업 공지 · 노챗님 경기 정보에서)."""
    return feed_old() and ((ENTRY.get("parsed") or {}).get("round") != 1)


def clear_cards(keep):
    """하단 카드는 한 번에 하나: keep 말고 다른 카드(누적 골드 · 리포트 · 룬 / 리그 정보 / 챔피언 기록 / 한타 리포트)를 내림."""
    if keep != "panel":
        ui["panel"], ui["panelUntil"] = None, None
    if keep != "league":
        league_show["until"] = 0
    if keep != "champ":
        champ["until"] = 0
    if keep != "fight" and game:
        game.hide("fight")


def show_champ(i=None):
    """i번째 카드를 띄움 (None이면 다음 차례 카드 — 콘솔 버튼)."""
    fs = champ["facts"]
    if not fs or prev_blocked():
        return False
    if i is None:
        i = champ["idx"] % len(fs)
        champ["idx"] = i + 1
    champ["show"] = dict(fs[i], id=f"cf-{i}-{int(time.time())}")
    champ["until"] = time.time() + CHAMP_SEC
    if game:
        game._write({"type": "champfact", "card": {k: v for k, v in fs[i].items() if k != "score"}})
    return True


def champ_view():
    if prev_blocked():   # 시즌 초 R2부터 (S11 기록이 생기기 전): 버튼도 꺼짐
        return {"now": None, "count": 0, "next": None}
    nxt = champ["facts"][champ["idx"] % len(champ["facts"])] if champ["facts"] else None
    return {"now": champ["show"] if time.time() < champ["until"] else None, "count": len(champ["facts"]),
            "next": f"{nxt['champ']} · {nxt['head']} · {nxt['big']}" if nxt else None}


ui = {"panel": None, "match": None, "mini": False, "banner": True, "autoDirect": False, "champAuto": False}   # 중계자 버튼으로 바뀌는 화면 상태 (자동으로 뜨는 그래픽은 기본 끔: S11 첫 방송 피드백 "쓸데없이 뜬다")
# banner: 왼쪽 아래 리그 배너(순위·상대 전적·주목 선수·포인트 캡) 순환 표시 (league_feed.py로 만든 captures/league_feed.json 사용)
# panel: None(기본) | "report"(ALT REPORT) | "gold"(누적 골드)
# mini: 왼쪽 아래 골드 흐름 미니 패널 상시 표시 여부 (기본 끔 — LCK/월즈처럼 게임 화면을 넓게)
REPLAY_RENDER = "https://127.0.0.1:2999/replay/render"
_hidden_ui_for = None  # 게임 프로세스별로 한 번만 원본 UI 정리
current_hwnd = None
stream_clients = 0      # /stream.mjpg 를 보고 있는 화면 수 (0이면 고속 캡처 안 함)
stream_jpg = b""
STREAM_FPS = 12
frame_jpg = b""
lock = threading.Lock()
last_game_time = None


def fetch_api():
    with urllib.request.urlopen(API, context=_ssl, timeout=2) as r:
        return json.loads(r.read().decode("utf-8"))


def checked_cs(cs_cell, cs_api):
    """화면 CS가 API(10 단위 내림) 값과 앞뒤가 맞을 때만 채택. API가 한 박자 늦을 수 있어 +19까지 허용."""
    v = cs_cell.get("cs")
    if v is not None and 0 <= v - cs_api <= 19:
        return v, True
    return cs_api, False


def set_render(values):
    """Replay API로 관전 화면 UI 켜기/끄기 (예: 오브젝트 타이머 창)"""
    try:
        req = urllib.request.Request(REPLAY_RENDER, data=json.dumps(values).encode(), headers={"Content-Type": "application/json"}, method="POST")
        urllib.request.urlopen(req, context=_ssl, timeout=1).read()
    except Exception:
        pass


def read_focus(players):
    """옵저버가 고른(카메라가 따라가는) 선수 번호 0~9. Replay API render의 selectionName으로 판단 (1초에 한 번, 로컬 요청).
    고른 선수가 없거나 Replay API가 꺼져 있으면 None. 두 번째 값은 확인용 원래 문자열."""
    if DEMO:
        return None, None
    global REPLAY_OK
    try:
        with urllib.request.urlopen(REPLAY_RENDER, context=_ssl, timeout=0.5) as r:
            render = json.loads(r.read().decode("utf-8"))
        sel = (render.get("selectionName") or "").strip()
        REPLAY_OK = True
        # 롤 오브젝트 타이머 창은 중계자 설정 그대로 둠 (꺼 두면 HUD가 처치 시각으로 계산해서 왼쪽 위에 보여 줌)
        global NEUTRAL_API
        NEUTRAL_API = render.get("interfaceNeutralTimers") is not None
        fix = {}
        if render.get("interfaceTimeline") is True:   # 관전 화면 가운데 아래 리플레이 타임라인 막대: 방송에 안 나오게 계속 숨김
            fix["interfaceTimeline"] = False
        if fix:
            set_render(fix)
    except Exception:
        REPLAY_OK = False
        return None, None
    if not sel:
        return None, ""
    low = sel.lower().split("#")[0]
    for i, p in enumerate(players):
        if low in (p["name"].lower().split("#")[0], p["champion"].lower(), (p.get("championName") or "").lower()):
            return i, sel
    return None, sel


FORM_BASE = {"GnarBig": "Gnar"}   # 경기 중 모습이 바뀌는 챔피언 → 원래 이름
CHAMPS = {"keys": set(), "lower": {}, "names": {}}   # ddragon 챔피언 목록 (그림 이름 확인용, 켤 때 한 번)
CHAMP_LOCK = {"ids": None, "t": 0, "map": {}}   # 선수별 이번 경기 챔피언 고정 (니코 변신 · 몰래 바뀌는 이름 방지)


def load_champs(ver):
    try:
        with urllib.request.urlopen(f"https://ddragon.leagueoflegends.com/cdn/{ver}/data/ko_KR/champion.json", timeout=10) as r:
            data = json.loads(r.read().decode("utf-8"))["data"]
        for key, c in data.items():
            CHAMPS["keys"].add(key)
            CHAMPS["lower"][key.lower()] = key
            CHAMPS["names"][c.get("name", "")] = key
    except Exception as e:
        print("챔피언 데이터 못 받음:", e, flush=True)


def champ_key(p):
    """초상화 그림 이름: 관전 데이터의 영어 이름이 ddragon과 다르면(대소문자 · 다른 표기) 한글 이름으로 다시 찾음."""
    raw = p["rawChampionName"].split("_")[-1]
    raw = FORM_BASE.get(raw, raw)
    if not CHAMPS["keys"] or raw in CHAMPS["keys"]:
        return raw
    return CHAMPS["lower"].get(raw.lower()) or CHAMPS["names"].get(p.get("championName") or "") or raw


def lock_champs(players, gt):
    """이번 경기에서 처음 본 챔피언으로 고정. 니코가 변신해도 초상화 · 경기 구분이 안 바뀜.
    선수 구성이 바뀌거나 게임 시간이 크게 되돌아가면(새 경기) 다시 잡음."""
    # 자리(블루1~5 · 레드1~5) + 이름으로 구분. 이름 숨김 선수 여럿이 같은 이름으로 들어와도 서로 안 섞이게
    keys = [f'{i}|{p.get("riotId") or p["name"]}' for i, p in enumerate(players)]
    ids = tuple(keys)
    if ids != CHAMP_LOCK["ids"] or gt < CHAMP_LOCK["t"] - 30:
        CHAMP_LOCK.update(ids=ids, map={}, items={})
    CHAMP_LOCK["t"] = gt
    held = CHAMP_LOCK.setdefault("items", {})
    for k, p in zip(keys, players):
        got = CHAMP_LOCK["map"].setdefault(k, (p["champion"], p["championName"]))
        changed = p["champion"] != got[0]   # 지금 다른 챔피언 모습 (비에고 빙의 · 니코 변신)
        p["champion"], p["championName"] = got
        # 비에고 빙의 중엔 관전 데이터가 아이템까지 빙의한 상대 것으로 줌 → 하단표에서 비에고 템이 10초쯤 '증발'
        # (S11 R1 GST 정글 비에고 실측: 노틸러스 · 자르반 템으로 바뀌었다 돌아옴). 빙의 중엔 직전 자기 템을 그대로 보여 줌
        # 관전 데이터가 이름은 그대로 두고 템만 바꿔 줄 때도 잡음: 비에고인데 장신구 빼고 겹치는 템이 하나도 없이 통째로 바뀜
        ids = lambda its: {i.get("itemID", i.get("id")) for i in its if (i.get("slot") or 0) != 6}
        if not changed and got[0] == "Viego" and k in held and len(ids(held[k])) >= 2 and not (ids(held[k]) & ids(p["items"])):
            changed = True
        if changed and k in held:
            p["items"] = held[k]
        else:
            held[k] = p["items"]


def player_view(p, gold, cs_cell, bounty):
    items = sorted(p["items"], key=lambda i: i["slot"])
    cs, cs_ok = checked_cs(cs_cell, p["scores"]["creepScore"])
    return {
        "name": p.get("riotIdGameName") or p.get("summonerName", ""),
        "riotId": p.get("riotId") or (f"{p.get('riotIdGameName')}#{p.get('riotIdTagLine')}" if p.get("riotIdGameName") else ""),
        # 변신 챔피언은 원래 이름으로 (GnarBig → Gnar). 안 그러면 다른 경기로 착각해 그래프 · 기록이 끊김
        "champion": champ_key(p),
        "championName": p["championName"],
        # 룬: 관전 데이터에는 핵심 룬 + 주 룬 트리 + 보조 룬 트리만 있음 (작은 룬·파편은 경기 후에만)
        "runes": {k: {"id": ((p.get("runes") or {}).get(src) or {}).get("id"), "name": ((p.get("runes") or {}).get(src) or {}).get("displayName")}
                  for k, src in (("key", "keystone"), ("pri", "primaryRuneTree"), ("sec", "secondaryRuneTree"))},
        "position": p["position"],
        "level": p["level"],
        "dead": p["isDead"],
        "respawn": round(p["respawnTimer"]),
        "k": p["scores"]["kills"], "d": p["scores"]["deaths"], "a": p["scores"]["assists"],
        "ward": round(p["scores"].get("wardScore") or 0),   # 시야 점수
        "cs_api": p["scores"]["creepScore"],  # API는 10 단위로 끊김
        "cs": cs,                             # 화면에서 읽은 정확한 CS (검산 실패 시 API 값)
        "cs_screen": cs_ok,
        # 현상금: None=없음, 0=있지만 숫자를 못 읽음(처음 보는 숫자), 그 외=금액
        "bounty": None if bounty is None else (bounty["bounty"] or 0),
        "items": [{"id": i["itemID"], "slot": i["slot"], "count": i["count"]} for i in items],
        # 소환사 주문 종류 (아이콘용, 쿨타임은 데이터 없음): "SummonerFlash" 등
        "spells": [((p.get("summonerSpells") or {}).get(k) or {}).get("rawDisplayName", "").replace("GeneratedTip_SummonerSpell_", "").replace("_DisplayName", "")
                   for k in ("summonerSpellOne", "summonerSpellTwo")],
        "gold_total": gold.get("total") if gold.get("ok") else None,
        "gold_current": gold.get("current") if gold.get("ok") else None,
        "gold_raw": gold.get("raw"),
    }


def hide_spectator_timeline(hwnd):
    """Replay API로 원본 관전 타임라인 바를 숨긴다 (HUD 바로 위에 겹쳐 보이므로). 게임마다 한 번."""
    global _hidden_ui_for
    if _hidden_ui_for == hwnd:
        return
    try:
        req = urllib.request.Request(REPLAY_RENDER, data=json.dumps({"interfaceTimeline": False}).encode(),
                                     headers={"Content-Type": "application/json"}, method="POST")
        urllib.request.urlopen(req, context=_ssl, timeout=2).read()
        _hidden_ui_for = hwnd
    except Exception:
        pass  # Replay API가 꺼져 있으면 그냥 둔다


def read_topbar(img):
    if tbr is None or TOPBAR_T is None:
        return None
    try:
        return tbr.read_image(img, TOPBAR_T, save_unknown=True)
    except Exception:
        return None


TM_STATE = {"miss_since": None, "last_kick": 0}
TOP_HOLD = {"sig": None, "t": 0, "vals": {"blue": {}, "red": {}}}
GAME_CLOCK = {"gt": None, "since": 0}   # 마지막으로 경기 시간이 바뀐 때   # 상단바 숫자 마지막 확실한 값
NEUTRAL_API = True   # 리플레이 기능으로 오브젝트 타이머 창을 켤 수 있는 관전인지 (read_focus가 갱신)
FIRST_SPAWN = {"dragon": 300, "baron": 1200}   # 첫 등장 (게임 시간 초)
RESPAWN = {"dragon": 300, "baron": 360}        # 처치 후 다시 등장 (장로는 360)


def timers_with_fallback(img, gt, top):
    """스폰 타이머: 롤 오브젝트 타이머 창이 켜져 있으면 읽고, 꺼져 있으면(중계자가 관전 설정에서 끔)
    HUD가 감지한 용·바론 처치 시각으로 남은 시간을 계산 (calc: True). 처음부터 본 경기면 계산값도 정확함."""
    tm = read_timers(img) or {}
    if any(v is not None for v in tm.values()) or gt is None or gt < 90:
        TM_STATE["miss_since"] = None
        return tm or None
    now = time.time()
    TM_STATE["miss_since"] = TM_STATE["miss_since"] or now
    return calc_timers(gt, top, game.timeline if game else [], bool(game and game.soul_claimed))


def calc_timers(gt, top, timeline, soul_claimed=False):
    """처치 시각으로 다음 등장까지 계산 (타이머 창이 안 보일 때 대신). 마지막 처치를 봤으면 그 기준,
    한 번도 못 봤는데 이미 먹힌 게 있으면(관전 시작 전) 모르므로 None."""
    out = {"herald": None, "calc": True}
    for kind, kinds, count_key in (("dragon", ("dragon", "soul", "elder"), "dragons"), ("baron", ("baron",), "obj2")):
        kills = [e["t"] for e in timeline if e["kind"] in kinds and e["t"] <= gt]
        taken = sum(int(((top or {}).get(sd) or {}).get(count_key) or 0) for sd in ("blue", "red")
                    if kind == "dragon" or ((top or {}).get(sd) or {}).get("obj2_kind") == "baron")
        if taken and not kills:
            out[kind] = None
            continue
        resp = 360 if kind == "dragon" and soul_claimed else RESPAWN[kind]
        nxt = max(kills) + resp if kills else FIRST_SPAWN[kind]
        rem = nxt - gt
        out[kind] = {"up": rem <= 0, "remaining": None if rem <= 0 else round(rem), "calc": True}
    return out


def read_timers(img):
    if tmr is None or TIMERS_T is None:
        return None
    try:
        return tmr.read_image(img, TIMERS_T, save_unknown=True)
    except Exception:
        return None


def towers_from_events(events):
    """포탑 이벤트로 팀별 파괴 포탑 수 (관전을 경기 시작부터 했을 때 정확)."""
    out = {"blue": 0, "red": 0}
    for e in events:
        if e.get("EventName") == "TurretKilled":
            name = e.get("TurretKilled", "")
            if "TChaos" in name:
                out["blue"] += 1      # 레드 포탑이 깨짐 → 블루 득점
            elif "TOrder" in name:
                out["red"] += 1
    return out


PATCH_LABEL = None
DEMO = None   # 시연 모드: (png 경로) — 관전 없이 저장된 장면 + 같은 시점 API 데이터로 HUD를 돌림


def tick(hwnd, templates, cs_templates):
    if DEMO:
        import numpy as np
        img = np.asarray(Image.open(DEMO).convert("RGB"))
        data = json.loads(Path(DEMO).with_suffix(".json").read_text(encoding="utf-8"))
        data["gameData"]["gameTime"] += time.time() - DEMO_T0   # 시간은 흐르게
        return build_state(img, data, templates, cs_templates)
    hide_spectator_timeline(hwnd)
    if not ctypes.windll.user32.IsWindow(hwnd) or ctypes.windll.user32.IsIconic(hwnd):
        raise SystemExit("롤 관전 창을 다시 찾는 중이에요")   # 경기가 바뀌어 창이 새로 생겼거나 최소화 → 다음 순간 다시 찾음
    img = grab(hwnd)
    if img.shape[:2] != (1080, 1920):
        # SystemExit → 다음 순간 창을 처음부터 다시 찾음 (옛 창을 붙잡고 있지 않게)
        raise SystemExit(f"게임 창 크기가 {img.shape[1]}x{img.shape[0]}입니다. 1920x1080이어야 합니다 (롤 설정 → 해상도 1920x1080 · 테두리 없음)")
    return build_state(img, None, templates, cs_templates)


MM_HIST = []   # 최근 미니맵 왼쪽 끝 (흔들림 방지: 가운데 값)


def minimap_left(img):
    """미니맵 왼쪽 끝 x: 미니맵 왼쪽 위 구석의 맵 밖 순검정 칸이 시작하는 곳 (줄 여러 개 중 가장 왼쪽).
    미니맵 31 기준 1628~1632, 에일형 PC 1605 무렵. 못 찾으면 None."""
    band = img[700:1050:10, 1400:1800].astype(np.int16)
    black = band.max(axis=2) <= 10
    c = np.cumsum(np.pad(black, ((0, 0), (1, 0))).astype(np.int32), axis=1)
    full = (c[:, 16:] - c[:, :-16]) == 16
    xs = [int(np.argmax(r)) + 1400 for r in full if r.any()]
    if not xs:
        return None
    x = min(xs)
    # 미니맵 바깥 금색 테두리: 지도 시작점 왼쪽 30px 안에 금빛(R 높고 B 낮음) 세로줄이 있으면 그 바깥이 진짜 끝
    #   (에일형 PC: 테두리 1602~1606, 지도 1618 / 이 PC: 테두리 거의 없음)
    rows = img[860:1060:20, max(0, x - 30):x].astype(np.int16)
    gold = (rows[..., 0] >= 60) & (rows[..., 0] > rows[..., 2] + 25) & (rows[..., 0] >= rows[..., 1])
    cols = np.where(gold.mean(axis=0) >= 0.6)[0]
    return int(max(0, x - 30) + cols.min()) if cols.size else x


def minimap_fit(img):
    x = minimap_left(img)
    if x:
        MM_HIST.append(x)
        del MM_HIST[:-9]
    if len(MM_HIST) < 3:
        return None
    return sorted(MM_HIST)[len(MM_HIST) // 2]


AT15 = {"sig": None, "snap": None}


def build_state(img, data, templates, cs_templates):
    global frame_jpg, last_game_time, game
    mm = minimap_fit(img)
    gold = gr.read_image(img, templates)
    cs = csr.read_image(img, cs_templates)
    bounty = brd.read_image(img, BOUNTY_T, save_unknown=True)
    buf = io.BytesIO()
    Image.fromarray(img).save(buf, "JPEG", quality=70)
    with lock:
        frame_jpg = buf.getvalue()

    data = data or fetch_api()
    gt = data["gameData"]["gameTime"]
    order = data["allPlayers"]
    blue = [p for p in order if p["team"] == "ORDER"]
    red = [p for p in order if p["team"] == "CHAOS"]
    # 화면 하단표 행 순서 = API 팀별 순서 (실측 확인). 포지션 순으로 정렬돼 있음.
    blue_v = [player_view(p, g, c, b) for p, g, c, b in zip(blue, gold["blue"], cs["blue"], bounty["blue"])]
    red_v = [player_view(p, g, c, b) for p, g, c, b in zip(red, gold["red"], cs["red"], bounty["red"])]
    if side_bars:   # 체력 · 자원 막대 (화면에서 읽음, 하단표 닉네임 밑에 표시)
        try:
            bars = side_bars.read_image(img)
            cds = side_bars.read_cooldowns(img) if bars and bars[0]["hp"] is not None else [{"spells": [None, None], "ult": None}] * 10
            for p, bar, cd in zip(blue_v + red_v, bars, cds):
                p["hp"], p["res"], p["resKind"] = bar["hp"], bar["res"], bar["kind"]
                p["spellReady"], p["ultReady"] = cd["spells"], cd["ult"]
        except Exception:
            pass
    lock_champs(blue_v + red_v, gt)

    # 화면 표시용 리그 닉네임 (기록·킬 판정은 계속 인게임 닉 "name"으로)
    # 1) 포털 로스터로 라이엇 ID → 리그 닉 자동 인식  2) 새 경기면 라인업에서 맞는 세트·진영을 자동 선택
    draft = ((league_feed() or {}).get("draft") or {}).get("players") or {}
    for p in blue_v + red_v:
        r = rsync.lookup(ROSTER, p["riotId"], p["name"])
        p["portal"] = r["alt"] if r else None
        dr = draft.get((p["portal"] or "").replace(" ", "").lower())   # 팀 · 점수는 시즌 드래프트 기준 (포털 팀 정보는 아직 부정확)
        p["draftTeam"], p["draftPts"] = (dr[1], dr[2]) if dr else (None, (r or {}).get("pts"))
    auto_pick_set(gl.signature(blue_v, red_v), blue_v, red_v)
    lu = active_lineup()
    nid = lambda x: (x or "").replace(" ", "").lower()
    by_riot = {nid(x["riotId"]): x for t in ("blue", "red") for x in (lu or {}).get(t, {}).get("players", []) if x.get("riotId")}
    for team, vs in (("blue", blue_v), ("red", red_v)):
        roster = (lu or {}).get(team, {}).get("players", [])
        for i, p in enumerate(vs):
            e = by_riot.get(nid(p["riotId"])) if by_riot else None
            if e:
                p["display"], p["pts"] = e["name"], e["pts"]
            elif not by_riot and i < len(roster):
                p["display"], p["pts"] = roster[i]["name"], roster[i]["pts"]
            elif p["portal"]:   # 라인업이 없으면 포털 로스터 닉 + 드래프트 점수
                p["display"], p["pts"] = p["portal"], p["draftPts"]

    focus = read_focus(blue_v + red_v)
    read_ok = sum(1 for g in gold["blue"] + gold["red"] if g["ok"])
    lanes = []
    for b, r in zip(blue_v, red_v):
        diff = b["gold_total"] - r["gold_total"] if b["gold_total"] is not None and r["gold_total"] is not None else None
        lanes.append({"position": b["position"], "diff": diff})

    team_diff = None
    if read_ok == 10:
        bt = sum(p["gold_total"] for p in blue_v)
        rt = sum(p["gold_total"] for p in red_v)
        team_diff = bt - rt
    else:
        bt = rt = None

    # 경기 로직 (자동 기록 / 한타 / 역전 / 오브젝트 / 버프)
    sig = gl.signature(blue_v, red_v)
    if game is None or game.sig != sig:
        if game:
            game.close()
        game = gl.Game(sig, [{"name": p["name"], "champion": p["champion"], "team": t, "position": p["position"]}
                             for t, vs in (("ORDER", blue_v), ("CHAOS", red_v)) for p in vs])
        tidy_captures()   # 새 경기 시작 → 오래된 원본 기록 정리
    # 15분 스냅샷 (ALT REPORT '라인 맞대결'): 15:00~15:30 사이 처음 본 값. 그 뒤에 관전을 시작하면 없음(None)
    if AT15["sig"] != sig:
        AT15.update(sig=sig, snap=None)
    if AT15["snap"] is None and 900 <= gt < 930:
        AT15["snap"] = [{"gold": p.get("gold_total"), "cs": p.get("cs") if p.get("cs") is not None else p.get("cs_api"), "lvl": p.get("level")}
                        for p in blue_v + red_v]
    if postgame and game and time.time() - PG_T["last"] > 30:   # 30초마다 한 번만 롤 클라이언트에 경기 번호 확인
        PG_T["last"] = time.time()
        try:
            postgame.watch(getattr(game, "log_path", None))
        except Exception:
            pass
    events = data.get("events", {}).get("Events", [])
    top = read_topbar(img)
    dtypes = {tm: stable_dragons(tm, ((top or {}).get(tm) or {}).get("dragons"),
                                 [str(d) for d in (((top or {}).get(tm) or {}).get("dragon_types") or [])], gt, sig)
              for tm in ("blue", "red")}
    for tm in ("blue", "red"):   # 대형 오브젝트 판정도 안정화된 용 종류로
        if top and top.get(tm):
            top[tm]["dragon_types"] = dtypes[tm]
    game.update(gt, blue_v, red_v, events, top)
    try:
        check_items(sig, blue_v + red_v, gt)
        check_levels(sig, blue_v + red_v, gt)
        check_stacks(sig, blue_v + red_v, img, focus[0], gt)
        auto_direct(gt)
    except Exception:
        pass
    # 경기 시간이 멈췄는지 (일시정지 · 경기 끝 결과 화면) — 점검표에서 판독 경고 대신 이걸 보여줌
    if GAME_CLOCK["gt"] != gt:
        GAME_CLOCK.update(gt=gt, since=time.time())
    try:
        update_champ_facts(sig, blue_v, red_v, gt)
    except Exception:
        pass

    ev_towers = towers_from_events(events)
    joined_late = next((e["EventTime"] for e in events if e.get("EventName") == "GameStart"), 0) > 30
    top_view = {}
    # 상단바 숫자 표시 유지: 잠깐 안 읽히면(오브젝트 현상금 글씨가 걸치는 등) 마지막으로 확실히 읽은 값 그대로.
    # 이 숫자들은 경기 중 줄지 않으므로 안전. 새 경기 · 되감기면 초기화
    if TOP_HOLD["sig"] != sig or gt < TOP_HOLD["t"] - 5:
        TOP_HOLD.update(sig=sig, vals={"blue": {}, "red": {}})
    TOP_HOLD["t"] = gt
    for team in ("blue", "red"):
        tb0 = (top or {}).get(team) or {}
        for k in ("towers", "grubs", "dragons", "obj2", "obj2_kind"):
            if tb0.get(k) is not None:
                TOP_HOLD["vals"][team][k] = tb0[k]
    for team, vs, tg in (("blue", blue_v, bt), ("red", red_v, rt)):
        tb = dict((top or {}).get(team) or {})
        for k, v in TOP_HOLD["vals"][team].items():
            if tb.get(k) is None:
                tb[k] = v
        towers = tb.get("towers")
        top_view[team] = {
            "kills": sum(p["k"] for p in vs),
            "gold": tg,
            "towers": towers if towers is not None else (None if joined_late else ev_towers[team]),
            "grubs": tb.get("grubs"),
            "dragons": tb.get("dragons"),
            "dragon_types": dtypes[team],
            # 용의 영혼: 4번째 용을 먹은 팀. 영혼 종류 = 3·4번째 용(협곡이 바뀐 뒤의 용) 종류
            "soul": soul_of(dtypes[team]),
            "obj2": tb.get("obj2"),
            "obj2_kind": None if tb.get("obj2_kind") is None else str(tb.get("obj2_kind")),
        }

    return {
        "ok": True,
        "message": "" if read_ok == 10 else f"골드 {read_ok}/10칸만 읽힘 — 관전 화면 하단표가 X(골드) 모드인지 확인",
        "gameTime": gt,
        "patch": PATCH,
        "mapNumber": data["gameData"].get("mapNumber"),   # 11 = 소환사의 협곡
        "frozen": gt > 60 and time.time() - GAME_CLOCK["since"] > 8,   # 경기 시간이 8초 넘게 멈춤 (일시정지 · 경기 끝)
        "patchLabel": ui.get("patch") or PATCH_LABEL,   # 콘솔에서 직접 적은 값이 우선
        "mmLeft": mm,   # 미니맵 왼쪽 끝 → HUD가 선수표 폭을 맞춤
        "goldRead": read_ok,
        "csRead": sum(1 for p in blue_v + red_v if p["cs_screen"]),
        "teamGold": {"blue": bt, "red": rt, "diff": team_diff},
        "lanes": lanes,
        "blue": blue_v,
        "red": red_v,
        "history": game.history,
        "top": top_view,
        "topbarReader": tbr is not None and TOPBAR_T is not None,
        # 다음 대형 오브젝트 등장까지 남은 초 (관전 클라이언트 타이머 창): {"baron": {"up", "remaining"}|None, "herald": ..., "dragon": ...}
        "timers": timers_with_fallback(img, gt, top) if data["gameData"].get("mapNumber", 11) == 11 else None,
        "buffs": game.buff_view(gt),
        # 옵저버가 고른 선수 (0~9) → 왼쪽 리그 배너에 그 선수 주요 스탯 고정
        "focus": focus[0], "focusRaw": focus[1],
        "champFacts": champ_view(),   # 챔피언 기록 카드 (지금 띄운 것 + 다음 차례)
        "kills": getattr(game, "kill_log", [])[-80:],   # 킬 기록 (ALT REPORT '킬 관여' 카드)
        "timeline": game.timeline[-12:],          # 경기 기록 (골드 그래프 옆)
        "coreItems": game.core_items[-6:],        # 첫 코어 아이템 (중계 콘솔에만)
        "coreTimes": {str(k): v[:3] for k, v in ITEM_SEEN["times"].items()},
        "at15": AT15["snap"],   # 15분 시점 선수별 골드 · CS · 레벨 (없으면 None)   # ALT REPORT '아이템 타이밍'
        "laneHist": lane_hist(gt, lanes),                                     # ALT REPORT '라인별 골드 흐름'
        "itemPops": [{k: v for k, v in x.items() if k != "at"} for x in ITEM_POPS if time.time() - x["at"] < ITEM_POP_SEC],
        "momentum": game.recent_gains(gt),       # 최근 3분 팀별 번 골드
        # 팀명: 라인업 → 없으면 드래프트 기준 그 진영 선수 다수의 팀 (3명 이상)
        "teams": {t: ((active_lineup() or {}).get(t) or {}).get("name") or majority_team(vs) for t, vs in (("blue", blue_v), ("red", red_v))},
        "alerts": game.active_alerts(),
        "recent": game.recent_view(),   # 버튼으로 띄울 수 있는 대기 알림 (한타 결과 등)
        "joinedLate": joined_late,
        "log": game.log_path.name,
        "updatedAt": time.time(),
    }


RUNES_SEC = 15
AUTO = {"sig": None, "fight": None, "runes": False, "obj": set(), "gold_t": 0, "manual": 0, "suggest": None}
AUTO_PANEL_SEC = {"report": 12, "gold": 10}
REPORT_PAGES = ["gold", "team", "lane", "gshare", "kp", "permin"]   # ALT REPORT 장 순서 (경기 흐름 · 라인별 골드 흐름은 뺌: 하단표 · TOTAL GOLD와 겹치고 뭘 봐야 할지 모름 — S11 첫 방송 피드백)
QUIET_ROTATION = ["totalgold", "permin", "team"]       # 조용할 때 자동으로 돌아가며
MANUAL_HOLD = 20   # 중계자가 버튼을 누른 뒤 이만큼은 자동으로 안 띄움 (중계자 우선)


def auto_direct(t):
    """자동 연출: 중계자가 안 눌러도 알맞은 때 그래픽을 띄움. 규칙 —
    싸움 중엔 안 띄움 · 한 번에 하나 · 중계자 버튼 우선(누른 뒤 20초 쉼) · 콘솔에서 끌 수 있음(끄면 '추천'만 표시).
      한타 끝 → 팀파이트 리포트 / 경기 시작 50초~2분 → 선수별 룬 / 바론·장로 15초 뒤 → 골드 그래프(ALT REPORT)
      / 6분 이후 45초 넘게 킬이 없고 4분 반 지났으면 → TOTAL GOLD"""
    if not game:
        return
    now = time.time()
    if AUTO["sig"] != game.sig:
        AUTO.update(sig=game.sig, fight=None, runes=False, obj=set(), gold_t=0, suggest=None)
    # 할 만한 것 고르기
    cand = None
    f = game.recent.get("fight")
    if f and f["id"] != AUTO["fight"] and 0 <= t - f["t"] < 40:
        cand = ("fight", f["id"])
    elif not AUTO["runes"] and 50 <= t <= 120:
        cand = ("runes", None)
    else:
        obj = next((e for e in reversed(game.timeline) if e["kind"] in ("baron", "elder") and 15 <= t - e["t"] <= 60
                    and (e["kind"], e["t"]) not in AUTO["obj"]), None)
        if obj:
            cand = ("report", (obj["kind"], obj["t"]))   # 바론·장로 뒤 → 골드 그래프
        elif t > 360 and t - AUTO["gold_t"] > 270 and t - (getattr(game, "last_kill_t", 0) or 0) > 45:
            cand = ("gold", None)
    AUTO["suggest"] = cand[0] if cand else None
    # 지금 띄워도 되나
    fighting = game.fight is not None
    shown = ui.get("panel") or any(a["kind"] == "fight" or a.get("big") for a in game.active_alerts()) \
        or now < champ["until"] or now < league_show["until"]
    if not cand or not ui.get("autoDirect", False) or fighting or shown or now - AUTO["manual"] < MANUAL_HOLD:
        return
    kind, key = cand
    if kind == "fight":
        game.show("fight")
        AUTO["fight"] = key
    elif kind == "runes":
        ui["panel"], ui["panelUntil"] = "runes", now + RUNES_SEC
        AUTO["runes"] = True
    elif kind == "report":
        ui["panel"], ui["panelUntil"], ui["reportPage"] = "report", now + AUTO_PANEL_SEC["report"], "gold"
        AUTO["obj"].add(key)
    else:   # 조용할 때: TOTAL GOLD → 라인별 흐름 → 분당 지표 → 팀 비교 → 아이템 타이밍 차례로
        pick = QUIET_ROTATION[AUTO.get("quiet_i", 0) % len(QUIET_ROTATION)]
        AUTO["quiet_i"] = AUTO.get("quiet_i", 0) + 1
        if pick == "totalgold":
            ui["panel"], ui["panelUntil"] = "gold", now + AUTO_PANEL_SEC["gold"]
        else:
            ui["panel"], ui["panelUntil"], ui["reportPage"] = "report", now + AUTO_PANEL_SEC["report"], pick
        AUTO["gold_t"] = t
    AUTO["suggest"] = None
    print(f"자동 연출: {kind} ({round(t)}초)", flush=True)
REPLAY_OK = None   # 리플레이 기능(Replay API) 응답 여부 — read_focus가 매초 갱신


def health_checks(st):
    """중계 전 점검 (콘솔 '방송 전 준비'). 각 항목: [이름, 상태 ok|warn|off, 설명]. 고치는 법은 docs/화면읽기-가이드.md"""
    out = []
    ok = st.get("ok")
    if ok and st.get("mapNumber") not in (None, 11):
        out.append(["맵", "warn", "소환사의 협곡이 아니에요 — 용 · 바론 · 타이머 · 상단바 기능은 협곡 기준이라 맞지 않아요"])
    if ok and st.get("frozen"):
        out.append(["경기 시간", "off", "8초 넘게 멈춤 — 일시정지거나 경기가 끝난 결과 화면이에요. 이때 판독 경고는 무시해도 돼요"])
    out.append(["관전 화면", "ok" if ok else "warn", "관전 창을 찾아서 읽는 중" if ok else (st.get("message") or "롤 관전을 켜 주세요")])
    if ok:
        g, c = st.get("goldRead", 0), st.get("csRead", 0)
        out.append(["하단표 골드", "ok" if g == 10 else "warn",
                    "10명 모두 읽힘" if g == 10 else f"{g}/10명만 읽힘 — 관전 하단표를 X(골드) 모드로, 하단표를 가리는 창이 없는지"])
        out.append(["CS", "ok" if c >= 8 else "warn", f"{c}/10명 화면에서 읽힘" + ("" if c >= 8 else " — 해상도 1920×1080 · 하단표 확인")])
        out.append(["상단바", "ok" if st.get("topbarReader") else "warn", "포탑 · 용 · 유충 · 바론 수 읽는 중" if st.get("topbarReader") else "상단바 읽기 꺼짐 — 템플릿 파일 확인"])
        tm = st.get("timers") or {}
        tm_ok = (not tm.get("calc") and any(v is not None for k, v in tm.items() if k != "calc")) or (st.get("gameTime") or 0) < 90
        out.append(["스폰 타이머", "ok" if tm_ok or not st.get("joinedLate") else "warn",
                    "롤 타이머 창을 읽는 중" if tm_ok else ("롤 타이머 창 꺼짐 — 용 · 바론 처치 시각으로 계산해서 보여 줘요" if not st.get("joinedLate") else
                     "경기 도중부터 봐서 계산이 틀릴 수 있어요 — 정확히 하려면 관전 설정에서 오브젝트 타이머를 켜 주세요")])
        out.append(["리플레이 기능", "ok" if REPLAY_OK else "warn",
                    "선택 선수 · 타임라인 숨김 사용 가능" if REPLAY_OK else "game.cfg에 EnableReplayApi=1이 없음 — 옵저버 선택 선수 배너가 안 됨 (가이드 2번)"])
    lu = active_lineup()
    # 라인업 세트가 실제 경기와 다른지: 포털로 알아본 선수 이름과 화면에 나가는 리그 닉이 3명 이상 다르면 경고
    if lu and ok:
        low = lambda n: (n or "").replace(" ", "").lower()
        diff = [p for p in (st.get("blue") or []) + (st.get("red") or []) if p.get("portal") and low(p["portal"]) != low(p.get("display"))]
        if len(diff) >= 3:
            out.append(["라인업 확인", "warn", f"화면 이름과 실제 선수가 {len(diff)}명 달라요 (예: {diff[0].get('display')} 자리에 {diff[0]['portal']}) — 세트·블루/레드를 확인하세요"])
    ls = LOL_SETUP.get("status")
    if ls:
        out.append(["롤 설정 자동", "warn" if ls == "nolol" else "ok", {
            "changed": "맞췄어요: " + " · ".join(LOL_SETUP["changed"]) + " (다음 관전부터 적용)",
            "ok": "리플레이 기능 · 관전 미니맵 31 · 자동 카메라 · 해상도 이미 맞음",
            "later": "관전 중이라 끝나면 맞출게요",
            "nolol": "롤 설치 위치를 못 찾았어요 — 가이드 3번(리플레이 기능)·5번(미니맵 31)을 직접 맞춰 주세요"}[ls]])
        if LOL_SETUP.get("small"):
            out.append(["모니터 크기", "warn", "모니터가 1920x1080보다 작아서 화면 읽기가 안 돼요 — 1920x1080 이상 모니터가 필요해요"])
    os_ = OBS_SETUP.get("status")
    if os_:
        out.append(["OBS 장면", "warn" if os_ in ("noobs", "error") else "ok", {
            "added": "OBS에 'ALT 중계' 장면 모음을 넣었어요 — OBS 위 메뉴 '장면 모음' → 'ALT 중계' (OBS가 켜져 있었으면 껐다 켜기)",
            "exists": "OBS 장면 모음 'ALT 중계' 있음 — OBS 위 메뉴 '장면 모음'에서 고르면 돼요",
            "noobs": "이 PC에서 OBS를 못 찾았어요 — OBS를 한 번 켰다 끈 뒤 HUD를 다시 켜 주세요",
            "error": "OBS 장면 모음을 못 넣었어요 — 매뉴얼 B(OBS 직접 세팅)대로 해 주세요"}[os_]])
        if os_ in ("added", "exists"):
            cur = obs_setup.current()
            out.append(["OBS 장면 선택", "ok" if cur == obs_setup.NAME else "warn",
                        f"OBS에서 '{obs_setup.NAME}' 사용 중" if cur == obs_setup.NAME else
                        f"OBS 위 메뉴 '장면 모음' → '{obs_setup.NAME}' 을 골라 주세요" + (f" (지금: {cur})" if cur else "")])
    if MATCH_IN["t"] or MATCH_IN["err"]:
        out.append(["노챗님 연동", "warn" if MATCH_IN["err"] else "ok", MATCH_IN["err"] or f"{MATCH_IN['src']}로 받음 · {MATCH_IN['t']}"])
    if postgame and postgame.STATUS.get("state"):
        st_ = postgame.STATUS["state"]
        out.append(["경기 후 기록", "ok" if st_ in ("ok", "watching", "waiting") else "warn", postgame.STATUS.get("msg") or ""])
    if log_upload:
        lst = log_upload.STATUS
        out.append(["기록 자동 보내기", "ok" if lst.get("state") == "ok" else "warn" if lst.get("state") else "mid",
                    lst.get("msg") or "켜는 중 — 경기가 끝나면 저절로 리그 기록 보관함에 보내요"])
    out.append(["라인업", "ok" if lu else "warn", f"{lu['blue']['name']} vs {lu['red']['name']} · {lu['set']}세트" if lu else "공지를 붙여넣고 세트를 골라 주세요 (안 하면 인게임 닉으로 나와요)"])
    out.append(["포털 로스터", "ok" if ROSTER else "warn",
                f"S{ROSTER['season']} · 라이엇 ID {len(ROSTER['byId'])}개 ({ROSTER['fetched']} 받음)" if ROSTER else "포털에서 못 받음 — 라인업 공지로만 이름이 바뀌어요"])
    feed = league_feed()
    out.append(["리그 데이터", "ok" if feed else "warn", f"S{feed.get('season')} · {str(feed.get('built') or '')[:10]} 빌드" if feed else "captures/league_feed.json 없음 — 리그 배너 · 챔피언 기록이 안 나와요"])
    try:
        ck = json.loads((Path(__file__).resolve().parent.parent / "captures" / "check.json").read_text(encoding="utf-8"))
        warn_n = sum(1 for x in ck.get("issues", []) if x.get("level") == "경고")
        out.append(["리그 기록 점검", "ok" if not warn_n else "off",
                    f"S{ck.get('season')} {ck.get('today')} 기준 확인할 기록 {warn_n}건 (리그리포트 누락 점검)" if warn_n else f"S{ck.get('season')} 누락·오타 없음"])
    except Exception:
        pass
    ip = lan_ip()
    out.append(["폰 연결", "ok" if LAN_ON else "off", f"켜짐 · 같은 와이파이에서 {ip}:{PORT}" if LAN_ON else (
        "못 켬 — 이 PC는 인터넷에 바로 연결돼 있어서(PC방 등) 보안상 폰 연결을 열지 않아요. PC에서는 그대로 사용 가능" if ip and not private_ip(ip)
        else "꺼짐 — 필요하면 아래 '폰으로 조작'에서 켜기" if ip else "와이파이/랜 주소를 못 찾음 — PC에서는 그대로 사용 가능")])
    return out


try:
    HUD_VERSION = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
except Exception:
    HUD_VERSION = None   # 개발 폴더


def with_ui(s):
    poll_match_file()
    if ui.get("panel") and ui.get("panelUntil") and time.time() > ui["panelUntil"]:
        ui["panel"], ui["panelUntil"] = None, None
    s = dict(s)
    s["ui"] = dict(ui)
    s["checks"] = health_checks(s)
    s["entry"] = entry_view()
    s["hudVersion"], s["appDir"] = HUD_VERSION, str(ROOT)
    s["leagueShow"] = {"on": time.time() < league_show["until"], "n": league_show["n"], "page": league_show.get("page")}
    s["suggest"] = AUTO["suggest"]   # 중계 화면: '지금 띄울 만한 것' 버튼 반짝임
    if ui.get("match"):
        s["match"] = ui["match"]
        s["matchSub"] = ui.get("matchSub") or ""
        s["matchDate"] = ui.get("matchDate") or ""
    return s


def stream_loop():
    """확인/녹화용: 누군가 /stream.mjpg 를 보고 있을 때만 게임 화면을 초당 STREAM_FPS장 캡처."""
    global stream_jpg
    while True:
        t0 = time.time()
        if stream_clients > 0 and current_hwnd:
            try:
                img = grab(current_hwnd)
                buf = io.BytesIO()
                Image.fromarray(img).save(buf, "JPEG", quality=80)
                with lock:
                    stream_jpg = buf.getvalue()
            except Exception:
                pass
            time.sleep(max(0.005, 1 / STREAM_FPS - (time.time() - t0)))
        else:
            time.sleep(0.2)


def loop():
    global state, current_hwnd
    global BOUNTY_T, TOPBAR_T, TIMERS_T
    templates = gr.load_templates()
    cs_templates = csr.load_templates()
    BOUNTY_T = brd.load_templates()
    if tbr is not None:
        try:
            TOPBAR_T = tbr.load_templates()
        except Exception:
            TOPBAR_T = None
    if tmr is not None:
        try:
            TIMERS_T = tmr.load_templates()
        except Exception:
            TIMERS_T = None
    hwnd = None
    while True:
        t0 = time.time()
        try:
            hwnd = hwnd or (1 if DEMO else find_game_window())
            current_hwnd = None if DEMO else hwnd
            s = tick(hwnd, templates, cs_templates)
        except SystemExit as e:
            hwnd, s = None, {"ok": False, "message": str(e)}
        except Exception as e:  # 게임 종료/API 끊김 등
            hwnd, s = None, {"ok": False, "message": f"{type(e).__name__}: {e}"}
        with lock:
            state = s
        try:
            auto_gold_view(hwnd, s)
        except Exception:
            pass
        time.sleep(max(0.05, 1.0 - (time.time() - t0)))


LANE_HIST = {"sig": None, "rows": []}


def lane_hist(t, lanes):
    """라인별 골드차를 15초마다 기록 [[게임 초, TOP, JGL, MID, BOT, SUP], ...] (경기마다 새로)."""
    sig = game.sig if game else None
    if LANE_HIST["sig"] != sig:
        LANE_HIST.update(sig=sig, rows=[])
    rows = LANE_HIST["rows"]
    if t is not None and lanes and (not rows or t - rows[-1][0] >= 15 or t < rows[-1][0]):
        if rows and t < rows[-1][0]:   # 되감기
            del rows[:]
        rows.append([round(t)] + [l.get("diff") for l in lanes])
    return rows


GV = {"sig": None, "bad": None, "last": 0, "n": 0}   # 골드 보기 자동 누르기 상태 (경기마다 초기화)


def auto_gold_view(hwnd, s):
    """관전 하단표가 '아이템 보기'면 골드를 못 읽음 → X(골드 보기)를 대신 눌러 줌.
    조건: CS는 8명 이상 읽히는데 골드는 2명 이하로 3초 넘게 · 롤 창이 맨 앞 · 경기당 최대 2번 · 누른 뒤 8초는 기다림."""
    if DEMO or not hwnd or not s.get("ok"):
        return
    sig = tuple(p.get("champion") for p in (s.get("blue") or []) + (s.get("red") or []))
    if GV["sig"] != sig:
        GV.update(sig=sig, bad=None, last=0, n=0)
    if not (s.get("csRead", 0) >= 8 and s.get("goldRead", 0) <= 2):
        GV["bad"] = None
        return
    now = time.time()
    GV["bad"] = GV["bad"] or now
    if now - GV["bad"] < 3 or now - GV["last"] < 8 or GV["n"] >= 2:
        return
    u = ctypes.windll.user32
    if u.GetForegroundWindow() != hwnd:
        return
    u.keybd_event(0, 0x2D, 0x0008, 0)            # X 누름 (스캔코드)
    time.sleep(0.05)
    u.keybd_event(0, 0x2D, 0x0008 | 0x0002, 0)   # X 뗌
    GV["last"], GV["n"] = now, GV["n"] + 1
    print("골드 보기(X) 자동으로 누름", flush=True)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _allowed(self):
        """이 PC에서 온 요청은 통과. 폰(다른 기기)은 연결 키(쿠키 또는 ?k=)가 맞아야 통과."""
        if self.client_address[0] in ("127.0.0.1", "::1"):
            return True
        from urllib.parse import parse_qs, urlparse
        k = (parse_qs(urlparse(self.path).query).get("k") or [""])[0]
        cookie = self.headers.get("Cookie") or ""
        ck = next((c.split("=", 1)[1] for c in cookie.split(";") if c.strip().startswith("altkey=")), "")
        if REMOTE_KEY in (k, ck.strip()):
            if self.path.split("?")[0] == "/m":   # QR 주소: 키를 쿠키로 저장하고 콘솔로
                self.send_response(302)
                self.send_header("Set-Cookie", f"altkey={REMOTE_KEY}; Path=/; Max-Age=31536000; SameSite=Lax")
                self.send_header("Location", "/control.html")
                self.end_headers()
                return False
            return True
        self._send(403, "<meta name=viewport content='width=device-width'><p style='font:18px sans-serif;padding:24px'>"
                   "연결 키가 없어요. PC 중계 콘솔의 <b>폰으로 조작</b> QR을 다시 찍어 주세요.</p>".encode("utf-8"), "text/html; charset=utf-8")
        return False

    def _send(self, code, body, ctype):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _stream(self):
        global stream_clients
        self.send_response(200)
        self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        stream_clients += 1
        last = None
        try:
            while True:
                with lock:
                    jpg = stream_jpg or frame_jpg
                if jpg and jpg is not last:
                    self.wfile.write(b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: " + str(len(jpg)).encode() + b"\r\n\r\n" + jpg + b"\r\n")
                    last = jpg
                time.sleep(1 / (STREAM_FPS * 2))
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
            pass
        finally:
            stream_clients -= 1

    def do_POST(self):
        if not self._allowed():
            return
        if self.path.split("?")[0] == "/api/entry/edit":   # 당일 인원 변경: 한 세트 한 팀 명단을 수기로 바꿈
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
            p = ENTRY.get("parsed")
            i, team = int(body.get("set", -1)), body.get("team")
            if not p or not (0 <= i < len(p["sets"])):
                return self._send(400, b'{"ok":false}', "application/json")
            edits = ENTRY.setdefault("edits", {})
            key = f"{i}|{team}"
            if body.get("reset"):   # 공지 원문대로 되돌리기
                edits.pop(key, None)
                orig = next((t for t in ep.parse(ENTRY.get("raw") or "")["sets"][i]["teams"] if t["name"] == team), None)
                new_ps = orig["players"] if orig else None
            else:
                new_ps = []
                for q in body.get("players") or []:
                    name = str(q.get("name") or "").strip()
                    if not name:
                        continue
                    pts = q.get("pts")
                    try:
                        pts = int(pts) if pts not in (None, "") else None
                    except (TypeError, ValueError):
                        pts = None
                    new_ps.append({"name": name, "pts": pts, "note": q.get("note") or None, "edited": bool(q.get("edited"))})
                edits[key] = new_ps
            for t in p["sets"][i]["teams"]:
                if t["name"] == team and new_ps is not None:
                    t["players"] = new_ps
            save_entry()
            return self._send(200, json.dumps(entry_view(), ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
        if self.path.split("?")[0] == "/api/match":   # 노챗님 프로그램: 세트 시작 전 경기 정보 한 번
            n = int(self.headers.get("Content-Length") or 0)
            try:
                body = apply_match(json.loads(self.rfile.read(n).decode("utf-8-sig") or "{}"), "주소")
                return self._send(200, json.dumps({"ok": True, "entry": body}, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
            except Exception as e:
                MATCH_IN["err"] = f"받은 값 오류: {e}"
                return self._send(400, json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
        if self.path.split("?")[0] == "/api/entry":   # 카톡 엔트리 글 붙여넣기
            n = int(self.headers.get("Content-Length") or 0)
            text = self.rfile.read(n).decode("utf-8", "replace")
            ENTRY["parsed"], ENTRY["set"], ENTRY["swap"], ENTRY["raw"] = ep.parse(text), None, False, text
            ENTRY.pop("bo", None)   # 새 엔트리: 시리즈 방식은 글 내용으로 다시 추정
            ENTRY.pop("edits", None)   # 새 엔트리: 수기 수정 기록도 비움
            ENTRY.pop("fromMatch", None)   # 손으로 붙여넣으면 노챗님 값 대신 이걸 씀
            save_entry()
            return self._send(200, json.dumps(entry_view(), ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
        self._send(404, b"not found", "text/plain")

    def do_GET(self):
        if not self._allowed():
            return
        path = self.path.split("?")[0]
        if path == "/api/pilotdata" and self.client_address[0] in ("127.0.0.1", "::1"):   # 시연판 재료: 버튼으로 띄울 실제 데이터
            t = game.last_t if game else 0
            fight = (game.recent.get("fight") if game else None)
            if fight:
                fight = {k: v for k, v in fight.items() if k != "until"}
            elif game:   # 아직 한타가 없으면: 최근 30초 실제 골드 획득으로 시연용 한타 결과
                fight = {"id": "pilot-fight", "kind": "fight", "team": "blue", "title": "한타 결과", "sub": "", "t": round(t),
                         "kills": [3, 1], "swing": None, "gains": game.gains_between(t - 30, t),
                         "deaths": [0, 1, 0, 0, 0, 1, 0, 1, 1, 0], "fkills": [1, 0, 2, 0, 0, 0, 0, 0, 1, 0]}
            body = {"fight": fight, "champFacts": champ["facts"], "history": game.history if game else []}
            return self._send(200, json.dumps(body, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
        if path == "/api/quit" and self.client_address[0] in ("127.0.0.1", "::1"):   # 'ALT HUD 끄기'
            self._send(200, b'{"ok":true}', "application/json")
            threading.Timer(0.3, lambda: os._exit(0)).start()
            return
        if path == "/api/remote" and self.client_address[0] in ("127.0.0.1", "::1"):   # PC 콘솔에만: 폰 연결 주소 / 켜기
            from urllib.parse import parse_qs, urlparse
            if (parse_qs(urlparse(self.path).query).get("on") or [""])[0] == "1":
                if start_lan():
                    save_settings(phone=True)   # 다음에 켤 때도 자동으로 폰 연결
            ip = lan_ip()
            return self._send(200, json.dumps({"on": LAN_ON, "url": f"http://{ip}:{PORT}/m?k={REMOTE_KEY}" if ip else None, "ip": ip}).encode(),
                              "application/json")
        if path == "/state.json":
            with lock:
                body = json.dumps(with_ui(state), ensure_ascii=False).encode("utf-8")
            return self._send(200, body, "application/json; charset=utf-8")
        if path == "/api/entry":  # 세트 선택: /api/entry?set=0&swap=0  (set=none 이면 인게임 닉으로)
            from urllib.parse import parse_qs, urlparse
            q = parse_qs(urlparse(self.path).query)
            sv = (q.get("set") or ["none"])[0]
            ENTRY["set"] = None if sv == "none" else int(sv)
            ENTRY["swap"] = (q.get("swap") or ["0"])[0] == "1"
            save_entry()
            lu = active_lineup()
            if lu and ENTRY["parsed"]:
                ui["match"], ui["matchSub"], ui["matchDate"] = match_text(lu)
            return self._send(200, json.dumps(entry_view(), ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
        if path == "/api/score":  # 세트 승수: /api/score?team=ZRN&d=1  (d=-1 빼기, reset=1 전부 0)
            from urllib.parse import parse_qs, urlparse
            q = parse_qs(urlparse(self.path).query)
            wins = ENTRY.setdefault("wins", {})
            if q.get("reset"):
                wins.clear()
            if (q.get("bo") or [""])[0] in ("3", "5"):
                ENTRY["bo"] = int(q["bo"][0])
                need = ENTRY["bo"] // 2 + 1
                for t in wins:
                    wins[t] = min(wins[t], need)
            team = (q.get("team") or [None])[0]
            if team:
                nmax = series_bo() // 2 + 1   # 이긴 세트 수는 2(3판 2선) / 3(5판 3선)까지
                wins[team] = max(0, min(nmax, wins.get(team, 0) + int((q.get("d") or ["1"])[0])))
            save_entry()
            return self._send(200, json.dumps(entry_view(), ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
        if path == "/api/show":  # 중계자 버튼: /api/show?kind=fight
            from urllib.parse import parse_qs, urlparse
            q = parse_qs(urlparse(self.path).query)
            kind = (q.get("kind") or ["fight"])[0]
            AUTO["manual"] = time.time()
            if kind == "fight" and game and game.recent.get("fight"):
                AUTO["fight"] = game.recent["fight"]["id"]   # 직접 띄운 한타는 자동으로 또 안 띄움
            # 떠 있는 중에 같은 버튼을 다시 누르면 내림 (잘못 눌렀을 때 바로 끄기)
            if kind == "league":   # 리그 정보: 떠 있으면 내림, 아니면 15초 띄움. page=standings|h2h|cap|stats 면 그 장 (같은 장이 떠 있으면 내림)
                pg = (q.get("page") or [None])[0]
                if pg:
                    if time.time() < league_show["until"] and league_show.get("page") == pg:
                        league_show["until"] = 0
                        return self._send(200, b'{"ok":true,"hidden":true}', "application/json")
                    clear_cards("league")
                    league_show.update(until=time.time() + LEAGUE_SEC, page=pg, n=league_show["n"] + 1)
                    return self._send(200, b'{"ok":true}', "application/json")
                league_show["page"] = None
                if time.time() < league_show["until"]:
                    league_show["until"] = 0
                    return self._send(200, b'{"ok":true,"hidden":true}', "application/json")
                clear_cards("league")
                league_show["until"] = time.time() + LEAGUE_SEC
                league_show["n"] += 1
                return self._send(200, b'{"ok":true}', "application/json")
            if kind == "champ" and time.time() < champ["until"]:
                champ["until"] = 0
                return self._send(200, b'{"ok":true,"hidden":true}', "application/json")
            if kind != "champ" and game and any(x["kind"] == kind and x["until"] > time.time() for x in game.alerts):
                game.hide(kind)
                return self._send(200, b'{"ok":true,"hidden":true}', "application/json")
            if kind in ("champ", "fight"):
                clear_cards(kind)
            ok = show_champ() if kind == "champ" else bool(game and game.show(kind))
            return self._send(200, json.dumps({"ok": ok}).encode(), "application/json")
        if path == "/api/demo":  # 시연용: /api/demo?kind=baron&team=blue
            from urllib.parse import parse_qs, urlparse
            q = parse_qs(urlparse(self.path).query)
            kind, team = (q.get("kind") or ["baron"])[0], (q.get("team") or ["blue"])[0]
            if game:
                t = game.last_t or 0
                label = "BLUE" if team == "blue" else "RED"
                demo = {
                    "baron": ("내셔 남작 처치", label, True), "elder": ("장로 드래곤 처치", label, True),
                    "dragon": ("화학공학 드래곤 처치", f"{label} · 2번째", True), "soul": ("바다 드래곤의 영혼", label, True),
                    "herald": ("협곡의 전령 처치", label, True), "grubs": ("공허 유충 +3", f"{label} · 총 3마리", False),
                    "fight": (f"한타 결과  BLUE {'3 : 1' if team == 'blue' else '1 : 3'} RED", f"골드 +1.2K {label}", False),
                    "reversal": ("골드 역전!", f"{label} 0.8K 우세", False), "ace": ("ACE", f"{label} 전멸시킴", False),
                }.get(kind)
                if demo:
                    extra = {"dtype": "hextech" if kind == "dragon" else "ocean"} if kind in ("dragon", "soul") else {}
                    if kind == "fight":   # 시연용 가짜 획득량
                        extra = {"kills": [3, 1], "swing": 1240, "gains": [612, 845, 410, 1120, 380, 150, 300, 95, 410, 60],
                                 "start": round(t) - 25, "end": round(t),
                                 "deaths": [0, 1, 0, 0, 0, 1, 0, 1, 1, 0], "fkills": [1, 0, 2, 0, 0, 0, 0, 0, 1, 0]}
                    # 시연: 자동 알림은 바로 뜨고, 한타 결과 같은 버튼용 알림은 대기열에만 들어감
                    game.alert(kind, team, demo[0], demo[1], t, big=demo[2], **extra)
                    if kind in ("baron", "elder"):
                        game.start_buff(team, kind, t)
                        # 시연: 바론은 +850(처치 골드)에서 시작
                elif kind == "powerplay":
                    game.alert("powerplay", team, "BARON POWER PLAY", "+3,240 GOLD", t, big=True)
            return self._send(200, b'{"ok":true}', "application/json")
        if path == "/api/panel":  # /api/panel?name=report  |  /api/panel?name=none
            from urllib.parse import parse_qs, urlparse
            q = parse_qs(urlparse(self.path).query, keep_blank_values=True)
            name = (q.get("name") or ["none"])[0]
            if (None if name == "none" else name) != ui.get("panel"):
                AUTO["manual"] = time.time()   # 하단 화면을 직접 바꿈 → 20초 자동 쉼
            if name == "report" and ui.get("panel") != "report":
                ui["reportPage"] = REPORT_PAGES[(REPORT_PAGES.index(ui.get("reportPage", REPORT_PAGES[-1])) + 1) % len(REPORT_PAGES)] \
                    if ui.get("reportPage") in REPORT_PAGES else REPORT_PAGES[0]
            if "page" in q and q["page"][0] in REPORT_PAGES:
                ui["reportPage"] = q["page"][0]
            if "lane" in q:   # 라인 맞대결: auto = 골드 차가 가장 큰 라인, 0~4 = 탑~서폿 직접 고름
                v = q["lane"][0]
                ui["lanePick"] = int(v) if v.isdigit() and 0 <= int(v) <= 4 else None
            if "autoDirect" in q:   # 자동 연출 켜기/끄기 (끄면 '추천' 반짝임만)
                ui["autoDirect"] = q["autoDirect"][0] == "1"
            settings = {"mini", "banner", "hudOff", "hide", "champAuto", "coverChat", "layout", "autoDirect", "match", "patch", "chatUrl", "chatPlate"} & set(q)
            if name in ("gold", "runes", "report") or (name == "none" and "name" in q and not settings):   # '기본 화면' 버튼이면 다른 카드도 다 내림 (설정만 바꿀 때는 그대로)
                clear_cards("panel")
            ui["panel"] = None if name == "none" else name
            # 선수별 룬은 잠깐 보여주는 그래픽 → 15초 뒤 기본 화면으로 저절로 돌아감
            ui["panelUntil"] = time.time() + RUNES_SEC if name == "runes" else None
            if "match" in q:
                ui["match"] = q["match"][0]
            if "patch" in q:   # 패치 표기 직접 입력 (빈 값이면 게임 파일 버전으로 되돌림)
                ui["patch"] = q["patch"][0].strip().upper().replace("PATCH", "").strip() or None
            if "mini" in q:
                ui["mini"] = q["mini"][0] == "1"
            if "banner" in q:
                ui["banner"] = q["banner"][0] == "1"
            if "hudOff" in q:   # HUD 전체 끄기 (힘든 중계자는 노챗님 화면만 쓰게)
                ui["hudOff"] = q["hudOff"][0] == "1"
            if "hide" in q:     # 부분별로 숨기기: top,board,info,timers,alerts (노챗님 화면과 겹치는 부분 고르기)
                ui["hide"] = [x for x in q["hide"][0].split(",") if x in ("top", "board", "info", "timers", "alerts")]
            if "champAuto" in q:   # 챔피언 기록 게임 초반 자동 표시
                ui["champAuto"] = q["champAuto"][0] == "1"
            if "layout" in q:   # 하단 HUD 배치: board(기본 선수표) / compact(간단 줄: 롤 관전 간단 모드 배치)
                ui["layout"] = "compact" if q["layout"][0] == "compact" else "board"
            if "chatUrl" in q:   # 숲 채팅 위젯 주소 (중계자마다 다름) → HUD 왼쪽 아래 채팅 자리에 띄움. 빈 값이면 끔. 다음 실행에도 유지
                v = q["chatUrl"][0].strip()
                ui["chatUrl"] = v if v.startswith(("http://", "https://")) else None
                save_settings(chatUrl=ui["chatUrl"])
            if "chatPlate" in q:   # 채팅 자리 가리기 (형 11-21): 채팅을 안 띄울 때 왼쪽 아래를 검은 판으로. 다음 실행에도 유지
                ui["chatPlate"] = q["chatPlate"][0] == "1"
                save_settings(chatPlate=ui["chatPlate"])
            if "coverChat" in q:   # 버튼 그래픽: 기본은 채팅 자리를 남김, 1이면 왼쪽 끝(채팅)까지 덮음
                ui["coverChat"] = q["coverChat"][0] == "1"
            return self._send(200, json.dumps(ui, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
        if path == "/league.json":   # 리그 배너용 요약 (없으면 빈 값)
            f = ROOT / "captures" / "league_feed.json"
            body = f.read_bytes() if f.exists() else b"null"
            return self._send(200, body, "application/json; charset=utf-8")
        if path == "/stream.mjpg":
            return self._stream()
        if path == "/frame.jpg":
            with lock:
                body = frame_jpg
            return self._send(200 if body else 404, body, "image/jpeg")
        f = HUD_DIR / ("index.html" if path == "/" else path.lstrip("/"))
        if f.is_file() and HUD_DIR in f.resolve().parents:
            ctype = {"html": "text/html; charset=utf-8", "js": "text/javascript", "css": "text/css",
                     "png": "image/png", "svg": "image/svg+xml", "json": "application/manifest+json"}.get(f.suffix[1:], "application/octet-stream")
            return self._send(200, f.read_bytes(), ctype)
        self._send(404, b"not found", "text/plain")


GAME_EXE = r"C:\Riot Games\League of Legends\Game\League of Legends.exe"


def game_patch_label():
    """이 PC에 깔린 게임 파일 버전(예: 16.23.839) → 라이엇 패치 표기 "26.23" (버전 16 = 2026년 패치).
    파일을 못 읽으면 None."""
    try:
        import ctypes
        from ctypes import wintypes
        ver = ctypes.windll.version
        size = ver.GetFileVersionInfoSizeW(GAME_EXE, None)
        if not size:
            return None
        buf = ctypes.create_string_buffer(size)
        ver.GetFileVersionInfoW(GAME_EXE, 0, size, buf)
        ptr, ln = ctypes.c_void_p(), wintypes.UINT()
        ver.VerQueryValueW(buf, "\\", ctypes.byref(ptr), ctypes.byref(ln))
        ms = ctypes.cast(ptr, ctypes.POINTER(wintypes.DWORD))[2]   # VS_FIXEDFILEINFO.dwFileVersionMS
        major, minor = ms >> 16, ms & 0xFFFF
        return f"{major + 10}.{minor}" if major >= 15 else f"{major}.{minor}"
    except Exception:
        return None


ITEMS = {}   # 아이템 id → {name, core}  (ddragon item.json, 서버 켤 때 한 번)
ITEM_SEEN = {"sig": None, "seen": {}, "core": set(), "ncore": {}, "times": {}}   # times: 선수 번호 → [[게임 초, 아이템], ...]
ITEM_POPS = []   # 코어 아이템 완성 효과 (롤드컵식: 초상화 옆에 아이템 아이콘이 잠깐 뜸) — {idx, item, n, at}
ITEM_POP_SEC = 6   # 이번 경기 선수별 본 아이템 / 첫 코어 완성한 선수


def load_items(ver):
    """완성(전설) 아이템 = 더 올라가는 아이템이 없고(into 없음) 2200골드 이상, 소모품 · 장신구 아님."""
    try:
        with urllib.request.urlopen(f"https://ddragon.leagueoflegends.com/cdn/{ver}/data/ko_KR/item.json", timeout=10) as r:
            data = json.loads(r.read().decode("utf-8"))["data"]
        for iid, it in data.items():
            tags = set(it.get("tags") or [])
            core = (not it.get("into")) and (it.get("gold") or {}).get("total", 0) >= 2200 and not tags & {"Consumable", "Trinket"}
            ITEMS[int(iid)] = {"name": it.get("name", ""), "core": core}
    except Exception as e:
        print("아이템 데이터 못 받음:", e, flush=True)


# 레벨 달성 순간 (이름 칸 슬라이드로 잠깐 보여 줌) — 정해 둔 챔피언의 분기 레벨만
LEVEL_MOMENTS = {"Kassadin": {16}, "Kayle": {6, 11, 16}}   # 띠: [챔피언 얼굴] Lv16 달성
LV_SEEN = {"sig": None, "lv": {}, "first": set()}


def check_levels(sig, players, t):
    if LV_SEEN["sig"] != sig:   # 새 경기: 지금 레벨을 기준으로 (들어온 순간 이미 넘은 건 안 띄움)
        LV_SEEN.update(sig=sig, lv={i: p.get("level") or 1 for i, p in enumerate(players)}, first=set())
        if any((p.get("level") or 1) >= 6 for p in players):
            LV_SEEN["first"].add(6)
        if any((p.get("level") or 1) >= 18 for p in players):
            LV_SEEN["first"].add(18)
        return
    for i, p in enumerate(players):
        old, new = LV_SEEN["lv"].get(i, 1), p.get("level") or 1
        LV_SEEN["lv"][i] = new
        if new <= old:
            continue
        name = p.get("championName") or p["champion"]
        for lv in range(old + 1, new + 1):
            text = f"Lv{lv} 달성" if lv in LEVEL_MOMENTS.get(p["champion"], ()) else None   # 정해 둔 챔피언 · 레벨만
            if lv in (6, 18):
                LV_SEEN["first"].add(lv)
            if text:
                ITEM_POPS.append({"idx": i, "kind": "lv", "champ": p["champion"], "name": text, "n": lv, "at": time.time()})


# 스택 챔피언 분기점 (옵저버가 그 챔피언을 골라 둔 동안 화면 왼쪽 아래 버프 숫자를 읽음 — 관전 데이터엔 스택이 없음)
#   나서스: 흡수의 일격 100 · 200 · 300 …  /  스몰더: 초강력 화염 숨결 25 · 125 · 225
STACK_CHAMPS = {"Nasus": ("NasusQ", "흡수의 일격", lambda v: v // 100 * 100 if v >= 100 else None),
                "Smolder": ("SmolderQ", "초강력 화염 숨결", lambda v: max((m for m in (25, 125, 225) if v >= m), default=None))}
STACK_SEEN = {"sig": None, "p": {}}
STACK_T = None
STACK_CROPS = ROOT / "captures" / "stacks" / "seen"   # 숫자 모양 표본 모으기 (3 · 9 아직 없음) — 작은 조각만, 최대 80장


def check_stacks(sig, players, img, idx, t):
    global STACK_T
    if STACK_SEEN["sig"] != sig:
        STACK_SEEN.update(sig=sig, p={})
    if idx is None or not (0 <= idx < len(players)) or players[idx]["champion"] not in STACK_CHAMPS:
        return
    if STACK_T is None:
        import stack_reader
        STACK_T = (stack_reader, stack_reader.load_templates())
    sr, tpl = STACK_T
    champ = players[idx]["champion"]
    v = sr.read_slot(img, 0, tpl)
    me = STACK_SEEN["p"].setdefault(idx, {"base": None, "bt": t, "pend": None, "cnt": 0, "low": 0, "crop": 0})
    if time.time() - me["crop"] > 20:   # 표본 조각 저장 (읽은 값이 파일 이름)
        me["crop"] = time.time()
        try:
            STACK_CROPS.mkdir(parents=True, exist_ok=True)
            old = sorted(STACK_CROPS.glob("*.png"), key=lambda f: f.stat().st_mtime)
            for f in old[:-79]:
                f.unlink()
            Image.fromarray(img[800:840, 0:90]).save(STACK_CROPS / f"{champ}_{int(t)}_{v if v is not None else 'x'}.png")
        except Exception:
            pass
    if v is None or v < 10:   # 한 자리 숫자는 분기점과 무관 + 잡음과 헷갈려서 안 씀
        return
    me["cnt"] = me["cnt"] + 1 if me["pend"] == v else 1
    me["pend"] = v
    if me["cnt"] < 2:   # 같은 값이 두 번 연속 읽혀야 믿음
        return
    base = me["base"]
    if base is None:   # 처음 본 값 = 기준 (이미 넘은 분기점은 안 띄움)
        me.update(base=v, bt=t)
        return
    if v < base:   # 스택은 줄지 않음 → 잘못 읽은 것. 다만 계속 그 값이면 기준이 틀렸던 것
        me["low"] += 1
        if me["low"] >= 5:
            me.update(base=v, bt=t, low=0)
        return
    me["low"] = 0
    if v - base > 30 + 25 * max(0.0, t - me["bt"]) / 60:   # 그 시간에 쌓을 수 없는 양 → 잘못 읽은 것
        return
    spell, sname, mark = STACK_CHAMPS[champ]
    m_old, m_new = mark(base), mark(v)
    me.update(base=v, bt=t)
    if m_new is not None and m_new != m_old:   # 분기점을 넘음 (여러 개를 한꺼번에 넘었으면 가장 높은 것만)
        ITEM_POPS.append({"idx": idx, "kind": "stack", "champ": champ, "spell": spell, "name": sname, "n": m_new, "at": time.time()})


def check_items(sig, players, t):
    """선수별 첫 코어 아이템 완성을 경기 기록에 남김 (자동 알림 아님 — 버튼용 대기 · 기록만)."""
    if not ITEMS or not game:
        return
    if ITEM_SEEN["sig"] != sig:
        ITEM_SEEN.update(sig=sig, seen={}, core=set(), ncore={}, times={})
        ITEM_POPS.clear()
        for p in players:   # 경기에 들어온 순간 이미 가진 아이템은 '방금 완성'이 아님
            ITEM_SEEN["seen"][p["name"]] = {i["id"] for i in p["items"]}
            n = sum(1 for i in p["items"] if ITEMS.get(i["id"], {}).get("core"))
            ITEM_SEEN["ncore"][p["name"]] = n
            if n:
                ITEM_SEEN["core"].add(p["name"])
        return
    for i, p in enumerate(players):
        ids = {x["id"] for x in p["items"]}
        new = ids - ITEM_SEEN["seen"].get(p["name"], set())
        ITEM_SEEN["seen"][p["name"]] = ids | ITEM_SEEN["seen"].get(p["name"], set())
        cores = [x for x in new if ITEMS.get(x, {}).get("core")]
        for c in cores:   # 코어 완성마다 화면 효과 (몇 번째 코어인지 함께)
            ITEM_SEEN["ncore"][p["name"]] = ITEM_SEEN["ncore"].get(p["name"], 0) + 1
            ITEM_POPS.append({"idx": i, "item": c, "n": ITEM_SEEN["ncore"][p["name"]], "name": ITEMS.get(c, {}).get("name", ""), "at": time.time()})
            ITEM_SEEN["times"].setdefault(i, []).append([round(t), c])
        del ITEM_POPS[:-20]
        if cores and p["name"] not in ITEM_SEEN["core"]:
            ITEM_SEEN["core"].add(p["name"])
            who = p.get("display") or p["name"]
            game.alert("item", "blue" if i < 5 else "red", f"{p.get('championName') or p['champion']} {ITEMS[cores[0]]['name']}",
                       f"{who} 첫 코어 완성", t, item=cores[0])


def detect_patch():
    try:
        with urllib.request.urlopen("https://ddragon.leagueoflegends.com/api/versions.json", timeout=5) as r:
            return json.loads(r.read())[0]
    except Exception:
        return None


if __name__ == "__main__":
    # 시연 모드: python hud_server.py --demo captures/set-.../01.png  (같은 이름의 .json 필요)
    if "--demo" in sys.argv:
        DEMO = sys.argv[sys.argv.index("--demo") + 1]
        DEMO_T0 = time.time()
        gl.LOG_DIR = gl.LOG_DIR.parent / "logs-demo"   # 실제 경기 기록과 섞이지 않게
    # 포털 로스터: 하루 한 번만 받음 (시즌 = 라인업 공지의 시즌, 없으면 11). 네트워크라 따로 돌림
    def _load_roster():
        global ROSTER
        # 시즌: 리그 데이터의 드래프트 시즌(진행 중 시즌) → 라인업 공지 시즌 → 11
        ROSTER = rsync.load(((league_feed() or {}).get("draft") or {}).get("season") or ((ENTRY.get("parsed") or {}).get("season")) or 11)
    threading.Thread(target=_load_roster, daemon=True).start()
    threading.Thread(target=fetch_feed, daemon=True).start()   # 리그 데이터 자동 갱신 (하루 한 번 켤 때)
    if log_upload:
        log_upload.start()   # 끝난 경기 기록 자동 보내기 (1분마다 확인)
    PATCH = detect_patch()            # 챔피언·아이템 그림용 (ddragon 최신 버전)
    threading.Thread(target=lol_setup_loop, daemon=True).start()   # 롤 관전 설정 자동 맞춤
    if obs_setup:
        OBS_SETUP["status"] = obs_setup.install()   # OBS 장면 모음 'ALT 중계' (없을 때만 새로 넣음)
    tidy_captures()   # 오래된 원본 기록 정리 (최근 10경기만)
    threading.Thread(target=load_items, args=(PATCH or "16.23.1",), daemon=True).start()   # 첫 코어 아이템 판단용
    threading.Thread(target=load_champs, args=(PATCH or "16.23.1",), daemon=True).start()   # 초상화 그림 이름 확인용
    PATCH_LABEL = game_patch_label()  # 배너 표기용 (실제 게임 파일 버전 → "26.23")
    _lu = active_lineup()   # 서버를 다시 켜도 고른 세트의 배너 문구 유지
    if _lu and ENTRY["parsed"]:
        ui["match"], ui["matchSub"], ui["matchDate"] = match_text(_lu)
    threading.Thread(target=loop, daemon=True).start()
    threading.Thread(target=stream_loop, daemon=True).start()
    print(f"HUD 서버: http://127.0.0.1:{PORT}/?bg=1  (패치 {PATCH})", flush=True)
    # 기본은 이 PC 안에서만. 콘솔에서 '폰 연결 켜기'를 한 번 누르면 그때부터(다음 실행도) 같은 와이파이의 폰에서 접속 가능 (연결 키 필수)
    if load_settings().get("phone"):
        start_lan()
    ui["chatUrl"] = load_settings().get("chatUrl")   # 지난번에 넣은 숲 채팅 위젯 주소
    ui["chatPlate"] = bool(load_settings().get("chatPlate"))   # 채팅 자리 가리기
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
