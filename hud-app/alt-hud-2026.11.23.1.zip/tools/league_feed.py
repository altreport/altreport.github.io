"""리그리포트 시즌 데이터(ALT/out/season_s<시즌>.json) → HUD 왼쪽 배너용 요약 파일.

  python league_feed.py 10     → captures/league_feed.json

담는 것 (전부 리그리포트에 이미 있는 값만, 새로 계산하는 건 승패 집계뿐):
  standings  정규 시즌(1~12라운드) 세트 승패 순위
  h2h        팀 대 팀 시즌 세트 전적
  h2hLog     팀 대 팀 만난 기록 (지난 시즌 포함, 라운드마다 세트 스코어) — 상대 전적 카드용
  teamBadges 팀 딱지 [이름, 설명]
  players    선수별 공개 딱지 [이름, 설명] + 리그 점수

방송은 공개라서, 리그리포트 공유판(share.html)과 똑같이 인게임 이벤트 딱지(비공개용)는 뺀다.
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ALT = ROOT / "ALT"                                   # 리그리포트 저장소 위치 (--alt 로 바꿈)
OUT = ROOT / "captures" / "league_feed.json"         # 결과 파일 (--out 으로 바꿈)
# ALT/scripts/build_season.py 의 IG_LABELS 와 같은 목록 (공유판에서 빼는 딱지)
IG_LABELS = {"갱면역", "맛집", "퍼블 메이커", "솔킬머신", "갱갱갱", "용기사", "막타 장인"}
# 부정적인 딱지: 방송 선수 카드에서 뺌 (리그리포트 template_season.html의 NEG와 같은 목록)
import re
NEG_RE = re.compile(r"^(밴픽분탕러|골드 블랙홀|기부천사|버스 승객|연패 머신|맛집|하마|첫판 징크스|.+ 유망주)$")
REGULAR_ROUNDS = 12


# ── 팔각 지표: 리그리포트(scripts/template_season.html)의 agg/axesFor/pctl과 같은 계산 ──
POS = ["탑", "정글", "미드", "원딜", "서폿"]
AX_DEF = [("kda", "KDA"), ("kp", "킬관여"), ("dpm", "분당 딜"), ("cspm", "분당 CS"), ("gpm", "분당 골드"), ("gd", "골드차"), ("share", "딜 비중"), ("d", "데스")]
AX_SUP = [("kda", "KDA"), ("kp", "킬관여"), ("apm", "분당 어시"), ("wpm", "시야"), ("tkpm", "받은 피해"), ("gd", "골드차"), ("gpm", "분당 골드"), ("d", "데스")]
AX_DEF2 = [("kda", "KDA"), ("kp", "킬관여"), ("ksh", "킬 비중"), ("cspm", "분당 CS"), ("gpm", "분당 골드"), ("gd", "골드차"), ("gsh", "골드 비중"), ("d", "데스")]
AX_SUP2 = [("kda", "KDA"), ("kp", "킬관여"), ("apm", "분당 어시"), ("act", "교전"), ("gsh", "골드 비중"), ("gd", "골드차"), ("gpm", "분당 골드"), ("d", "데스")]
INV = {"d"}   # 낮을수록 좋은 축
MIN_GAMES = 3  # 시즌 전체 비교 대상: 경기 기록 3판 이상 (리포트와 같음)


def radar_data(d):
    """선수별 시즌 팔각 지표 (같은 포지션 안 백분위 0~1) + 축 이름. 리포트의 시즌 전체 보기와 같은 값."""
    keys = d["keys"]
    nk = len(keys)
    acc = {}
    rows_by_pos = defaultdict(list)
    for a in d["rows"]:
        name, pos = a[1], POS[a[3]]
        p = acc.setdefault(name, {"posc": defaultdict(int), "ing": 0, "K": 0, "D": 0, "A": 0, "s": defaultdict(float), "n": defaultdict(int)})
        p["posc"][pos] += 1
        if len(a) <= 7:
            continue
        r = dict(zip(keys, a[7:7 + nk]))
        rows_by_pos[pos].append(r)
        p["ing"] += 1
        p["K"] += r["k"] or 0; p["D"] += r["d"] or 0; p["A"] += r["a"] or 0
        for k in ("kp", "share", "gd", "wpm", "tkpm", "ksh", "gsh"):
            if r.get(k) is not None:
                p["s"][k] += r[k]; p["n"][k] += 1
        if r.get("mins"):
            for src, num, den in (("cs", "csN", "csM"), ("gold", "gN", "gM"), ("dmg", "dN", "dM")):
                if r.get(src) is not None:
                    p["s"][num] += r[src]; p["s"][den] += r["mins"]; p["n"][num] += 1
            p["s"]["aN"] += r["a"] or 0; p["s"]["aM"] += r["mins"]
            p["s"]["actN"] += (r["k"] or 0) + (r["d"] or 0) + (r["a"] or 0)
    players = {}
    for name, p in acc.items():
        if not p["ing"]:
            continue
        s, n, g = p["s"], p["n"], p["ing"]
        avg = lambda k: s[k] / n[k] if n[k] else None
        div = lambda a, b: s[a] / s[b] if s[b] else None
        v = {"kda": (p["K"] + p["A"]) / max(p["D"], 1), "d": p["D"] / g, "kp": avg("kp"), "share": avg("share"), "gd": avg("gd"),
             "wpm": avg("wpm"), "tkpm": avg("tkpm"), "ksh": avg("ksh"), "gsh": avg("gsh"),
             "cspm": div("csN", "csM"), "gpm": div("gN", "gM"), "dpm": div("dN", "dM"), "apm": div("aN", "aM"),
             "act": s["actN"] / s["aM"] * 10 if s["aM"] else None}
        pos = max(p["posc"].items(), key=lambda x: x[1])[0]
        players[name] = {"pos": pos, "ing": g, "v": v}
    # 축 선택: 딜(서폿은 시야) 기록이 그 포지션 경기의 60% 이상이면 기본 축, 아니면 스크린샷으로도 채워지는 축
    axes = {}
    for pos in POS:
        rs = rows_by_pos[pos]
        key = "wpm" if pos == "서폿" else "share"
        cov = sum(1 for r in rs if r.get(key) is not None) / len(rs) if rs else 0
        axes[pos] = (AX_SUP if cov >= 0.6 else AX_SUP2) if pos == "서폿" else (AX_DEF if cov >= 0.6 else AX_DEF2)
    out = {}
    for name, p in players.items():
        pos, ax = p["pos"], axes[p["pos"]]
        pool = [q for q in players.values() if q["pos"] == pos and q["ing"] >= MIN_GAMES]
        qs = []
        for k, _ in ax:
            val = p["v"].get(k)
            arr = [q["v"][k] for q in pool if q["v"].get(k) is not None]
            if val is None or not arr:
                qs.append(None); continue
            below = sum(1 for x in arr if (x > val if k in INV else x < val))
            eq = sum(1 for x in arr if x == val)
            qs.append(round((below + eq / 2) / len(arr), 3))
        out[name] = {"pos": pos, "n": p["ing"], "q": qs, "ax": [lab for _, lab in ax],
                     "raw": [None if p["v"].get(k) is None else round(p["v"][k], 3) for k, _ in ax]}
    return out


# ── S11~ 주 스탯 (형 11-22): 리포트 선수 카드 팔각형과 같은 계산 ──
#   자리마다 뜻이 같음: 라인전 · 성장 · 맵 영향 · 운영 · 한타 · 캐리 · 생존 · 딜 (지표는 라인마다 다름)
#   값 = 같은 라인 선수(그 시즌 경기 기록 1판 이상) 사이 백분위. 묶음 지표는 구성 지표 백분위 평균을 다시 백분위로
AXK11 = {"탑": ["c_lane", "cspm", "c_sinv", "objfight", "c_fight", "c_carry", "surv", "share"],
         "정글": ["c_early", "c_grow", "kp", "c_obj", "c_fight", "c_carry", "surv", "share"],
         "미드": ["c_lane", "cspm", "c_sinv", "c_vis", "c_fight", "c_carry", "surv", "share"],
         "원딜": ["c_lane", "cspm", "kp", "objfight", "c_fight", "c_carry", "surv", "share"],
         "서폿": ["c_lane", "apm", "c_sinv", "c_vis", "c_fight", "kp", "surv", "goldeff"]}
CARRY11 = ["share", "goldeff", "tfks", "surv", "oppperf", "closer", "turn", "dmgeff", "dpg", "aiscore", "pogr", "shutdown", "decisive", "cartarget", "multik", "latekp", "topgoldwin"]
COMP11 = {"c_lane": {p: (["early", "gd15", "lvd15"] if p == "정글" else ["gd15", "lvd15"] if p == "서폿" else ["gd15", "csd15", "lvd15"]) for p in POS},
          "c_fight": {p: (["tfks", "tfsurv", "tfkp"] if p == "원딜" else ["tfkp", "tfsurv"]) for p in POS},
          "c_obj": {"정글": ["objctl", "objfight", "obj"]}, "c_carry": {p: CARRY11 for p in POS},
          "c_early": {"정글": ["early", "fb", "roam"]}, "c_sinv": {p: ["early", "fb", "roam"] for p in ("탑", "미드", "서폿")},
          "c_grow": {"정글": ["gd15", "lvd15"]}, "c_vis": {"정글": ["vspm", "wkpm"], "미드": ["vspm", "vshare"], "서폿": ["vspm", "wkpm"]}}
LAB11 = {"c_lane": "라인압박", "c_early": "교전", "c_grow": "성장", "c_sinv": "합류", "c_obj": "오브젝트", "c_vis": "시야", "c_fight": "한타력", "c_carry": "캐리력",
         "cspm": "분당 CS", "apm": "분당 어시", "kp": "킬관여", "objfight": "오브젝트 교전", "surv": "생존", "share": "딜 비중", "goldeff": "골드 효율"}
INV11 = {"firstga", "gankav", "nochain", "surv", "deathball"}
RAW11 = {"cspm", "apm", "kp", "share"}   # 중계 '주요 스탯' 숫자 줄에 그대로 보여 줄 값 (나머지는 모양으로만)


def radar_data_s11(d):
    keys, mk = d["keys"], d.get("mkeys") or []
    nk = len(keys)
    acc = {}
    for a in d["rows"]:
        name, pos = a[1], POS[a[3]]
        p = acc.setdefault((name, pos), {"name": name, "pos": pos, "n": 0, "pog": 0, "ing": 0, "s": defaultdict(float), "c": defaultdict(int)})
        p["n"] += 1; p["pog"] += a[6] if len(a) > 6 else 0
        if len(a) <= 7:
            continue
        r = dict(zip(keys, a[7:7 + nk]))
        p["ing"] += 1
        for k in ["kp", "share"] + mk:
            if r.get(k) is not None:
                p["s"][k] += r[k]; p["c"][k] += 1
        if r.get("mins"):
            if r.get("cs") is not None: p["s"]["csN"] += r["cs"]; p["s"]["csM"] += r["mins"]
            p["s"]["aN"] += r.get("a") or 0; p["s"]["aM"] += r["mins"]
        if r.get("dmg") is not None and r.get("gold"): p["s"]["dgD"] += r["dmg"]; p["s"]["dgG"] += r["gold"]
    pl = []
    for p in acc.values():
        if not p["ing"]:
            continue
        s, c = p["s"], p["c"]
        v = {k: s[k] / c[k] for k in c}
        v["cspm"] = s["csN"] / s["csM"] if s["csM"] else None
        if "apm" not in mk: v["apm"] = s["aN"] / s["aM"] if s["aM"] else None   # 리포트도 판별 기록(mkeys)이 있으면 그 평균을 씀
        v["dpg"] = s["dgD"] / s["dgG"] if s["dgG"] else None
        v["pogr"] = p["pog"] / p["n"] if p["n"] else None
        pl.append({"name": p["name"], "pos": p["pos"], "n": p["n"], "ing": p["ing"], "v": v})

    def pct(pos, k, val):
        if val is None:
            return None
        arr = [q["v"][k] for q in pl if q["pos"] == pos and q["v"].get(k) is not None]
        if not arr:
            return None
        inv = k in INV11
        return (sum(1 for x in arr if (x > val if inv else x < val)) + sum(1 for x in arr if x == val) / 2) / len(arr)
    for q in pl:   # 묶음 지표 = 구성 지표 백분위 평균 (리포트 addComposites)
        for ck, by in COMP11.items():
            qs = [x for x in (pct(q["pos"], k, q["v"].get(k)) for k in by.get(q["pos"], [])) if x is not None]
            q.setdefault("cv", {})[ck] = sum(qs) / len(qs) if qs else None
    for q in pl:
        q["v"].update(q["cv"])
    main = {}
    for q in pl:   # 선수당 가장 많이 뛴 라인 하나
        if q["name"] not in main or q["n"] > main[q["name"]]["n"]:
            main[q["name"]] = q
    out = {}
    for name, q in main.items():
        ax = AXK11[q["pos"]]
        qs = [None if (x := pct(q["pos"], k, q["v"].get(k))) is None else round(x, 3) for k in ax]
        out[name] = {"pos": q["pos"], "n": q["ing"], "q": qs,
                     "ax": [("교전" if (q["pos"] == "서폿" and k == "kp") else LAB11[k]) for k in ax],
                     "raw": [round(q["v"][k], 3) if (k in RAW11 and q["v"].get(k) is not None and not (q["pos"] == "서폿" and k == "kp")) else None for k in ax]}
    return out


def champ_data(d):
    """챔피언별 시즌 기록 (중계 '챔피언 기록'용). 이름은 띄어쓰기 없앤 정식 이름으로 맞춤.
      w·l 픽 승패 / ban 밴 수 / by 선수별 [승,패] / team 팀별 [승,패]
      streak 리그 전체 지금 연속 기록 (+3 = 3연승, -4 = 4연패, 세트 순서 = 시간 순서)
      bannedVs 팀별로 '그 팀을 상대할 때' 밴당한 수 (저격밴 판단용)"""
    alias = {}
    cf = ALT / "data" / "champions.json"
    if cf.exists():
        alias = json.loads(cf.read_text(encoding="utf-8")).get("alias", {})
    key = lambda n: (alias.get(n, n) or "").replace(" ", "")
    new = lambda n: {"name": alias.get(n, n), "w": 0, "l": 0, "ban": 0, "by": {}, "team": {}, "streak": 0, "bannedVs": {}}
    out = {}
    for a in sorted(d["rows"], key=lambda r: r[0]):
        c = key(a[4])
        if not c or c == "?":
            continue
        e = out.setdefault(c, new(a[4]))
        win = bool(a[5])
        e["w" if win else "l"] += 1
        e["by"].setdefault(a[1], [0, 0])[0 if win else 1] += 1
        e["team"].setdefault(a[2], [0, 0])[0 if win else 1] += 1
        e["streak"] = (e["streak"] + 1 if e["streak"] >= 0 else 1) if win else (e["streak"] - 1 if e["streak"] <= 0 else -1)
    for st in d["sets"]:
        h, aw = st.get("h"), st.get("a")
        for t, bans in (st.get("bans") or {}).items():
            opp = aw if t == h else h      # 밴한 팀의 상대 = 이 밴을 당한 팀
            for c in bans or []:
                if c:
                    e = out.setdefault(key(c), new(c))
                    e["ban"] += 1
                    if opp:
                        e["bannedVs"][opp] = e["bannedVs"].get(opp, 0) + 1
    return out


def draft_data(season):
    """ALT/data/s<시즌>/draft.json — 다음 시즌이 있으면 그걸, 없으면 이번 시즌. {season, teams:{팀:{color,fg}}, players:{선수 소문자:[이름,팀,점수]}}"""
    for sn in (season + 1, season):
        f = ALT / "data" / f"s{sn}" / "draft.json"
        if f.exists():
            d = json.loads(f.read_text(encoding="utf-8"))
            players = {}
            for t, info in d.get("teams", {}).items():
                for pl in info.get("players", []):
                    players[pl[0].replace(" ", "").lower()] = [pl[0], t, pl[1]]
            return {"season": sn, "teams": {t: {"color": i.get("color"), "fg": i.get("fg")} for t, i in d.get("teams", {}).items()},
                    "players": players}
    return None


def team_sets(d):
    """팀별 시즌 세트 수 (저격밴 비율 계산용)"""
    n = defaultdict(int)
    for st in d["sets"]:
        for t in (st.get("h"), st.get("a")):
            if t:
                n[t] += 1
    return dict(n)


def h2h_log(season):
    """팀 대 팀 만난 기록: 이 시즌까지 있는 모든 시즌 파일(season_s*.json)에서 라운드마다 세트 스코어.
    {"FB|SSG": [["S10 R1", {"FB": 2, "SSG": 1}], ...]}  (오래된 것부터)"""
    log = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))
    for f in sorted((ALT / "out").glob("season_s*.json"), key=lambda p: int(re.sub(r"\D", "", p.stem) or 0)):
        sn = int(re.sub(r"\D", "", f.stem) or 0)
        if not sn or sn > season:
            continue
        for s in json.loads(f.read_text(encoding="utf-8")).get("sets", []):
            h, a, w = s.get("h"), s.get("a"), s.get("w")
            if not (h and a and w):
                continue
            r = s.get("r") or 0
            log[f"{min(h, a)}|{max(h, a)}"][(sn, r)][w] += 1
    out = {}
    for k, rs in log.items():
        out[k] = [[f"S{sn} " + (f"R{r}" if 0 < r <= REGULAR_ROUNDS else "PO"), dict(v)] for (sn, r), v in sorted(rs.items())]
    return out


def build(season):
    src = ALT / "out" / f"season_s{season}.json"
    d = json.loads(src.read_text(encoding="utf-8"))

    wins, losses = defaultdict(int), defaultdict(int)
    h2h = defaultdict(lambda: defaultdict(int))
    for s in d["sets"]:
        h, a, w = s.get("h"), s.get("a"), s.get("w")
        if not (h and a and w):
            continue
        loser = a if w == h else h
        h2h[f"{min(h, a)}|{max(h, a)}"][w] += 1
        if (s.get("r") or 99) <= REGULAR_ROUNDS:
            wins[w] += 1
            losses[loser] += 1
    for f in d.get("forfeits") or []:   # 기권승·패도 순위표에 (정규 시즌만)
        if (f.get("round") or 99) <= REGULAR_ROUNDS and f.get("winner") and f.get("forfeit_team"):
            wins[f["winner"]] += 1
            losses[f["forfeit_team"]] += 1
    teams = sorted(set(wins) | set(losses), key=lambda t: (-wins[t], losses[t], t))
    standings = [{"team": t, "w": wins[t], "l": losses[t],
                  "pct": round(wins[t] / max(1, wins[t] + losses[t]) * 100)} for t in teams]

    players = {}
    for name, bs in d.get("badges", {}).items():
        pub = [[b[0], b[3] if len(b) > 3 else ""] for b in bs if b and b[0] not in IG_LABELS and not NEG_RE.match(b[0])]
        if pub:
            players[name] = {"badges": pub[:4]}
    for name, pts in d.get("roster", {}).items():
        players.setdefault(name, {})["pts"] = pts
    for name, r in (radar_data_s11(d) if season >= 11 and d.get("mkeys") else radar_data(d)).items():   # 팔각 지표 (리포트와 같은 계산, S11~ 주 스탯)
        players.setdefault(name, {})["radar"] = r

    feed = {"season": season, "built": d.get("built"), "source": src.name,
            "standings": standings, "h2h": {k: dict(v) for k, v in h2h.items()}, "h2hLog": h2h_log(season),
            "teamBadges": {t: [[b[0], b[1]] for b in bs] for t, bs in d.get("teamBadges", {}).items()},
            "players": players,
            # 챔피언 기록 (중계 '챔피언 기록' 카드용): 시즌 세트 수 + 챔피언별 승패·밴·선수별 승패
            "nsets": len(d["sets"]), "teamSets": team_sets(d), "champs": champ_data(d),
            # 다음(진행 중) 시즌 드래프트: 선수 → 팀 · 점수, 팀 색 (리그리포트 시즌 프리뷰와 같은 원본)
            "draft": draft_data(season)}
    out = OUT
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(feed, ensure_ascii=False), encoding="utf-8")
    print(f"시즌 S{season}: 팀 {len(standings)} · 선수 {len(players)} · 상대 전적 {len(feed['h2h'])}쌍 → {out}")
    for r in standings:
        print(f"  {r['team']:5} {r['w']}승 {r['l']}패 ({r['pct']}%)")


if __name__ == "__main__":
    # 같은 파일을 리그리포트 저장소(ALT/scripts/hud_feed.py)에도 둠 → 월요일 자동화가
    #   python3 scripts/hud_feed.py 11 --alt . --out out/hud/league_feed.json  으로 만들어 공개 사이트에 올림
    args = sys.argv[1:]
    if "--alt" in args:
        ALT = Path(args[args.index("--alt") + 1]).resolve()
    if "--out" in args:
        OUT = Path(args[args.index("--out") + 1]).resolve()
    nums = [a for a in args if a.isdigit()]
    build(int(nums[0]) if nums else 10)
